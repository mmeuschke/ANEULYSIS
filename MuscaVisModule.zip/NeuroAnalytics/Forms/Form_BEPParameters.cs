﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NeuroAnalytics
{
    public partial class Form_BEPParameters : Form
    {
        #region - Private Variables -

        private List<string> scalar_fields;

        private Control_Risk_Analysis parent_control;

        private List<float> parameter_thresholds;

        private List<int> invert_values;

        #endregion

        #region - Constructors -

        public Form_BEPParameters()
        {
            this.InitializeComponent();

            this.scalar_fields = new List<string>();

            this.parameter_thresholds = new List<float>();

            this.invert_values = new List<int>();
        }

        #endregion

        #region - Properties -

        public List<string> Scalar_Fields
        {
            get { return this.scalar_fields; }
            set { this.scalar_fields = value; }
        }

        public Control_Risk_Analysis Parent_Control
        {
            get { return this.parent_control; }
            set { this.parent_control = value; }
        }

        public List<float> Thresholds
        {
            get { return this.parameter_thresholds; }
            set { this.parameter_thresholds = value; }
        }

        public List<int> InvertValues
        {
            get { return this.invert_values; }
            set { this.invert_values = value; }
        }

        #endregion

        #region - Methods -

        private void Form_BEPParameters_Load(object sender, EventArgs e)
        {
            if (this.parameter_thresholds.Count < 1)
            {
                this.Init_Weight_Form();
            }
        }

        private void Init_Weight_Form()
        {
            int longest_name = 0;

            for (int i = 0; i < this.scalar_fields.Count; i++)
            {
                if (this.scalar_fields[i].Length > longest_name)
                {
                    longest_name = this.scalar_fields[i].Length;
                }
            }

            int last_label_ypos = 10;

            int last_trbar_xpos = 15 + longest_name * 10;

            float val = 0;

            for (int i = 0; i < this.scalar_fields.Count; i++)
            {
                GradientControls.ColorTrackBar trckbar = new GradientControls.ColorTrackBar();

                trckbar.BarOrientation = GradientControls.Orientations.Horizontal;
                trckbar.Minimum = 0;
                trckbar.Maximum = 100;
                trckbar.Tag = i;
                trckbar.Value = 30;
                trckbar.Size = new Size(250, 20);
                trckbar.TrackerSize = 10;
                trckbar.Location = new Point(last_trbar_xpos, last_label_ypos);
                trckbar.MaximumValueSide = GradientControls.Poles.Right;
                trckbar.Scroll += new GradientControls.ColorTrackBar.ScrollEventHandler(this.TrckBr_ValueSlider_Scroll);
                trckbar.BringToFront();

                this.Controls.Add(trckbar);

                Label act_name = new Label();

                act_name.Text = this.scalar_fields[i] + ":";
                act_name.Location = new Point(10, last_label_ypos);
                act_name.Size = new Size((this.scalar_fields[i].Length * 15), 20);

                this.Controls.Add(act_name);

                Label low_name = new Label();
                Label top_name = new Label();
                Label value = new Label();
                Label inv_val = new Label();
                CheckBox invert_val_check = new CheckBox();

                low_name.Text = String.Format("{0:F2}", Utility.norm_values[this.scalar_fields[i]].X);
                low_name.Location = new Point(last_trbar_xpos - 10, last_label_ypos + 30);

                top_name.Text = String.Format("{0:F2}", Utility.norm_values[this.scalar_fields[i]].Y);
                top_name.Location = new Point(last_trbar_xpos + trckbar.Size.Width-20, last_label_ypos + 30);

                val = trckbar.Value / 100.0f;
                val = val * (Utility.norm_values[this.scalar_fields[i]].Y - Utility.norm_values[this.scalar_fields[i]].X) + Utility.norm_values[this.scalar_fields[i]].X;

                inv_val.Text = "Invert";
                inv_val.Location = new Point(top_name.Location.X+25, last_label_ypos);
                //inv_val.BackColor = Color.Red;
                inv_val.Size = new Size(40, 25);

                invert_val_check.Tag = i;
                invert_val_check.Location = new Point(inv_val.Location.X + 50, last_label_ypos);
                invert_val_check.CheckedChanged += new EventHandler(this.Chck_Bx_InvertVal_CheckedChanged);

                this.parameter_thresholds.Add(val);
                this.invert_values.Add(0);

                value.Text = "Value:" + String.Format("{0:F2}", val);
                value.Location = new Point(last_trbar_xpos + 80, last_label_ypos + 30);
                value.Tag = i;
                value.Size = new Size(100, 25);
                value.BringToFront();

                this.Controls.Add(value);
                this.Controls.Add(low_name);
                this.Controls.Add(top_name);
                this.Controls.Add(inv_val);
                this.Controls.Add(invert_val_check);

                last_label_ypos = last_label_ypos + 60;
            }

            int x_size = last_trbar_xpos + 400;
            int y_size = last_label_ypos + 30;

            this.Size = new Size(x_size, y_size);
        }

        private void TrckBr_ValueSlider_Scroll(object sender, EventArgs e)
        {
            try
            {
                GradientControls.ColorTrackBar act_trckbar = (GradientControls.ColorTrackBar)sender;

                string tag = act_trckbar.Tag.ToString();

                float norm_value = ((float)act_trckbar.Value / 100.0f);

                for (int i = 0; i < this.Controls.Count; i++)
                {
                    if (this.Controls[i] is Label)
                    {
                        if (this.Controls[i].Tag != null)
                        {
                            if (this.Controls[i].Tag.ToString() == tag)
                            {
                                int position = Int32.Parse(tag);

                                float val = norm_value * (Utility.norm_values[this.scalar_fields[position]].Y - Utility.norm_values[this.scalar_fields[position]].X) + Utility.norm_values[this.scalar_fields[position]].X;

                                if (this.parameter_thresholds[position] != val)
                                {
                                    this.parameter_thresholds[position] = val;

                                    this.parent_control.Update_BEP_Plot();
                                }

                                this.Controls[i].Text = "Value: " + String.Format("{0:F2}", val);
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        private void Chck_Bx_InvertVal_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                CheckBox act_chbx = (CheckBox)sender;

                int val = 0;

                if (act_chbx.Checked)
                {
                    val = 1;
                }

                string tag = act_chbx.Tag.ToString();

                int position = Int32.Parse(tag);

                if (this.invert_values[position] != val)
                {
                    this.invert_values[position] = val;

                    this.parent_control.Update_BEP_Plot();
                }  
            }
            catch (Exception)
            {
                Console.WriteLine("Exception in CheckBox changed for BEPPlot");
            }
        }

        #endregion
    }
}
