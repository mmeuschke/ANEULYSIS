﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NeuroAnalytics
{
    public partial class Form_Clustering : Form
    {
        #region - Private Variables -

        private List<string> scalar_fields;

        private List<float> weights;
        private List<int> norm_v;
        private List<int> invert_v;

        private Control_Risk_Analysis parent_control;

        private bool has_changed;

        #endregion

        #region - Constructors -

        public Form_Clustering()
        {
            this.InitializeComponent();

            this.scalar_fields = new List<string>();
            this.weights = new List<float>();
            this.norm_v = new List<int>();
            this.invert_v = new List<int>();
            this.has_changed = false;
        }

        #endregion

        #region - Properties -

        public List<float> Weights
        {
            get { return this.weights; }
            set { this.weights = value; }
        }

        public List<int> Norm_Val
        {
            get { return this.norm_v; }
            set { this.norm_v = value; }
        }

        public List<int> Invert_Val
        {
            get { return this.invert_v; }
            set { this.invert_v = value; }
        }

        public List<string> Scalar_Fields
        {
            get { return this.scalar_fields; }
            set { this.scalar_fields = value; }
        }

        public Control_Risk_Analysis Parent_Control
        {
            get { return this.parent_control; }
            set { this.parent_control = value; }
        }

        public bool Has_Changed
        {
            get { return this.has_changed; }
            set { this.has_changed = value; }
        }

        #endregion

        #region - Methods -

        private void Form_Clustering_Load(object sender, EventArgs e)
        {
            if (this.weights.Count < 1)
            {
                this.Init_Weight_Form();
            }

            this.has_changed = false;
        }

        private void Init_Weight_Form()
        {
            int last_label_xpos = 10;
            int last_trbar_xpos = 10;

            for (int i = 0; i < this.scalar_fields.Count; i++)
            {
                this.weights.Add(100 / this.scalar_fields.Count);
                this.norm_v.Add(1);
                this.invert_v.Add(0);

                Label act_name = new Label();

                act_name.Text = this.scalar_fields[i];
                act_name.Location = new Point(last_label_xpos, 10);
                act_name.Size = new Size((this.scalar_fields[i].Length * 11), 20);

                this.Controls.Add(act_name);

                GradientControls.ColorTrackBar trckbar = new GradientControls.ColorTrackBar();

                last_trbar_xpos = last_label_xpos + this.scalar_fields[i].Length * 3;

                trckbar.BarOrientation = GradientControls.Orientations.Vertical;
                trckbar.Minimum = 0;
                trckbar.Maximum = 100;
                trckbar.Tag = i;
                trckbar.Value = 100 / this.scalar_fields.Count;
                trckbar.Size = new Size(23, 243);
                trckbar.TrackerSize = 10;
                trckbar.Location = new Point(last_trbar_xpos, 50);
                trckbar.MaximumValueSide = GradientControls.Poles.Top;
                trckbar.Scroll += new GradientControls.ColorTrackBar.ScrollEventHandler(this.TrckBr_ValueSlider_Scroll);

                Label low_name = new Label();
                Label top_name = new Label();
                Label value = new Label();

                CheckBox norm_val = new CheckBox();
                CheckBox invert_val = new CheckBox();

                low_name.Text = "0 %";
                low_name.Location = new Point(last_trbar_xpos, 293);

                top_name.Text = "100 %";
                top_name.Location = new Point(last_trbar_xpos - 8, 33);

                value.Text = trckbar.Value.ToString() + " %"; 
                value.Location = new Point(last_trbar_xpos + 30, 146);
                value.Tag = i;
                value.Size = new Size(60, 25);

                norm_val.Text = "Normalize";
                norm_val.Location = new Point(last_trbar_xpos + 30, 166);
                norm_val.Tag = i;
                norm_val.Size = new Size(100, norm_val.Height);
                norm_val.Checked = true;
                norm_val.CheckedChanged += new EventHandler(Chck_Bx_CheckedChanged);

                invert_val.Text = "Invert";
                invert_val.Location = new Point(last_trbar_xpos + 30, 186);
                invert_val.Tag = i;
                invert_val.Size = new Size(70, invert_val.Height);
                invert_val.CheckedChanged += new EventHandler(Chck_Bx_CheckedChanged);

                this.Controls.Add(trckbar);
                this.Controls.Add(low_name);
                this.Controls.Add(top_name);
                this.Controls.Add(value);
                this.Controls.Add(norm_val);
                this.Controls.Add(invert_val);

                //last_label_xpos = last_label_xpos + this.scalar_fields[i].Length * 8;
                last_label_xpos = last_trbar_xpos + 60 + norm_val.Text.Length *9;
            }

            int x_size = last_label_xpos + this.scalar_fields.Last().Length + 30;

            this.Size = new Size(x_size, 350);
        }

        private void TrckBr_ValueSlider_Scroll(object sender, EventArgs e)
        {
            try
            {
                GradientControls.ColorTrackBar act_trckbar = (GradientControls.ColorTrackBar)sender;

                string tag = act_trckbar.Tag.ToString();

                float norm_value = ((float)act_trckbar.Value / 100.0f);

                for (int i = 0; i < this.Controls.Count; i++)
                {
                    if (this.Controls[i] is Label)
                    {
                        if (this.Controls[i].Tag != null)
                        {
                            if (this.Controls[i].Tag.ToString() == tag)
                            {
                                int position = Int32.Parse(tag);

                                this.weights[position] = norm_value;

                                if (norm_value > 0)
                                {
                                    this.has_changed = true;
                                }

                                this.Controls[i].Text = act_trckbar.Value.ToString() + " %";
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        private void Form_Clustering_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.parent_control.Start_Mesh_Clustering();
        }

        private void Chck_Bx_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                CheckBox act_chckbx = (CheckBox)sender;

                int tag = Int32.Parse(act_chckbx.Tag.ToString());

                if (act_chckbx.Checked)
                {
                    if (act_chckbx.Text == "Normalize")
                    {
                        this.norm_v[tag] = 1;
                    }
                    else if (act_chckbx.Text == "Invert")
                    {
                        this.invert_v[tag] = 1;
                    }

                    this.has_changed = true;
                }
                else
                {
                    if (act_chckbx.Text == "Normalize")
                    {
                        this.norm_v[tag] = 0;
                    }
                    else if (act_chckbx.Text == "Invert")
                    {
                        this.invert_v[tag] = 0;
                    }

                    this.has_changed = true;
                }
            }
            catch (Exception)
            {

            }
        }

        #endregion
    }
}
