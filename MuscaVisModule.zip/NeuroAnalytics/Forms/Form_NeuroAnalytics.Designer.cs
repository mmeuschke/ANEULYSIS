﻿namespace NeuroAnalytics
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MnStrp_Main = new System.Windows.Forms.MenuStrip();
            this.Tl_Strp_Mn_Im_Load_Data = new System.Windows.Forms.ToolStripMenuItem();
            this.Load_Dataset_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Tl_Strp_Mn_Im_Export_Data = new System.Windows.Forms.ToolStripMenuItem();
            this.meshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oBJToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vTKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oBJToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Export_Ostium_ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Export_DomeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scatterplotToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aneurysmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataProcessingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculateMapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculateOstiumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateQuadshapedRegionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.generateCircularshapedRegionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Tb_Cntrl_Main = new System.Windows.Forms.TabControl();
            this.TbPg_Risk_Analysis = new System.Windows.Forms.TabPage();
            this.control_Risk_Analysis1 = new NeuroAnalytics.Control_Risk_Analysis();
            this.Fldr_Brwsr_Load_Dataset = new System.Windows.Forms.FolderBrowserDialog();
            this.MnStrp_Main.SuspendLayout();
            this.Tb_Cntrl_Main.SuspendLayout();
            this.TbPg_Risk_Analysis.SuspendLayout();
            this.SuspendLayout();
            // 
            // MnStrp_Main
            // 
            this.MnStrp_Main.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tl_Strp_Mn_Im_Load_Data,
            this.Tl_Strp_Mn_Im_Export_Data,
            this.dataProcessingToolStripMenuItem});
            this.MnStrp_Main.Location = new System.Drawing.Point(0, 0);
            this.MnStrp_Main.Name = "MnStrp_Main";
            this.MnStrp_Main.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.MnStrp_Main.Size = new System.Drawing.Size(1904, 25);
            this.MnStrp_Main.TabIndex = 0;
            this.MnStrp_Main.Text = "menuStrip1";
            // 
            // Tl_Strp_Mn_Im_Load_Data
            // 
            this.Tl_Strp_Mn_Im_Load_Data.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Load_Dataset_ToolStripMenuItem});
            this.Tl_Strp_Mn_Im_Load_Data.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tl_Strp_Mn_Im_Load_Data.Name = "Tl_Strp_Mn_Im_Load_Data";
            this.Tl_Strp_Mn_Im_Load_Data.Size = new System.Drawing.Size(49, 21);
            this.Tl_Strp_Mn_Im_Load_Data.Text = "Load";
            // 
            // Load_Dataset_ToolStripMenuItem
            // 
            this.Load_Dataset_ToolStripMenuItem.Name = "Load_Dataset_ToolStripMenuItem";
            this.Load_Dataset_ToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.Load_Dataset_ToolStripMenuItem.Text = "Dataset";
            this.Load_Dataset_ToolStripMenuItem.Click += new System.EventHandler(this.Load_Dataset_ToolStripMenuItem_Click);
            // 
            // Tl_Strp_Mn_Im_Export_Data
            // 
            this.Tl_Strp_Mn_Im_Export_Data.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.meshToolStripMenuItem,
            this.mapToolStripMenuItem,
            this.Export_Ostium_ToolStripMenuItem,
            this.Export_DomeToolStripMenuItem,
            this.scatterplotToolStripMenuItem,
            this.aneurysmToolStripMenuItem});
            this.Tl_Strp_Mn_Im_Export_Data.Name = "Tl_Strp_Mn_Im_Export_Data";
            this.Tl_Strp_Mn_Im_Export_Data.Size = new System.Drawing.Size(52, 21);
            this.Tl_Strp_Mn_Im_Export_Data.Text = "Export";
            // 
            // meshToolStripMenuItem
            // 
            this.meshToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oBJToolStripMenuItem1});
            this.meshToolStripMenuItem.Name = "meshToolStripMenuItem";
            this.meshToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.meshToolStripMenuItem.Text = "Mesh";
            // 
            // oBJToolStripMenuItem1
            // 
            this.oBJToolStripMenuItem1.Name = "oBJToolStripMenuItem1";
            this.oBJToolStripMenuItem1.Size = new System.Drawing.Size(94, 22);
            this.oBJToolStripMenuItem1.Text = "OBJ";
            this.oBJToolStripMenuItem1.Click += new System.EventHandler(this.Export_Mesh_OBJ_ToolStripMenuItem_Click);
            // 
            // mapToolStripMenuItem
            // 
            this.mapToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vTKToolStripMenuItem,
            this.oBJToolStripMenuItem});
            this.mapToolStripMenuItem.Name = "mapToolStripMenuItem";
            this.mapToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.mapToolStripMenuItem.Text = "Map";
            // 
            // vTKToolStripMenuItem
            // 
            this.vTKToolStripMenuItem.Name = "vTKToolStripMenuItem";
            this.vTKToolStripMenuItem.Size = new System.Drawing.Size(95, 22);
            this.vTKToolStripMenuItem.Text = "VTP";
            this.vTKToolStripMenuItem.Click += new System.EventHandler(this.Export_Map_VTKToolStripMenuItem_Click);
            // 
            // oBJToolStripMenuItem
            // 
            this.oBJToolStripMenuItem.Name = "oBJToolStripMenuItem";
            this.oBJToolStripMenuItem.Size = new System.Drawing.Size(95, 22);
            this.oBJToolStripMenuItem.Text = "OBJ";
            this.oBJToolStripMenuItem.Click += new System.EventHandler(this.Export_Map_OBJToolStripMenuItem_Click);
            // 
            // Export_Ostium_ToolStripMenuItem
            // 
            this.Export_Ostium_ToolStripMenuItem.Name = "Export_Ostium_ToolStripMenuItem";
            this.Export_Ostium_ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.Export_Ostium_ToolStripMenuItem.Text = "Ostium";
            this.Export_Ostium_ToolStripMenuItem.Click += new System.EventHandler(this.Export_Ostium_ToolStripMenuItem_Click);
            // 
            // Export_DomeToolStripMenuItem
            // 
            this.Export_DomeToolStripMenuItem.Name = "Export_DomeToolStripMenuItem";
            this.Export_DomeToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.Export_DomeToolStripMenuItem.Text = "Dome";
            this.Export_DomeToolStripMenuItem.Click += new System.EventHandler(this.Export_Dome_ToolStripMenuItem_Click);
            // 
            // scatterplotToolStripMenuItem
            // 
            this.scatterplotToolStripMenuItem.Name = "scatterplotToolStripMenuItem";
            this.scatterplotToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.scatterplotToolStripMenuItem.Text = "Scatterplot";
            this.scatterplotToolStripMenuItem.Click += new System.EventHandler(this.Export_Scatterplot_ToolStripMenuItem_Click);
            // 
            // aneurysmToolStripMenuItem
            // 
            this.aneurysmToolStripMenuItem.Name = "aneurysmToolStripMenuItem";
            this.aneurysmToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.aneurysmToolStripMenuItem.Text = "Aneurysm";
            this.aneurysmToolStripMenuItem.Click += new System.EventHandler(this.Export_Aneurysm_ToolStripMenuItem_Click);
            // 
            // dataProcessingToolStripMenuItem
            // 
            this.dataProcessingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculateMapToolStripMenuItem,
            this.calculateOstiumToolStripMenuItem,
            this.generateQuadshapedRegionsToolStripMenuItem,
            this.generateCircularshapedRegionsToolStripMenuItem});
            this.dataProcessingToolStripMenuItem.Name = "dataProcessingToolStripMenuItem";
            this.dataProcessingToolStripMenuItem.Size = new System.Drawing.Size(103, 21);
            this.dataProcessingToolStripMenuItem.Text = "Data Processing";
            // 
            // calculateMapToolStripMenuItem
            // 
            this.calculateMapToolStripMenuItem.Name = "calculateMapToolStripMenuItem";
            this.calculateMapToolStripMenuItem.Size = new System.Drawing.Size(248, 22);
            this.calculateMapToolStripMenuItem.Text = "Calculate Map";
            this.calculateMapToolStripMenuItem.Click += new System.EventHandler(this.Calculate_Map_ToolStripMenuItem_Click);
            // 
            // calculateOstiumToolStripMenuItem
            // 
            this.calculateOstiumToolStripMenuItem.Name = "calculateOstiumToolStripMenuItem";
            this.calculateOstiumToolStripMenuItem.Size = new System.Drawing.Size(248, 22);
            this.calculateOstiumToolStripMenuItem.Text = "Calculate Fusiform Ostium";
            this.calculateOstiumToolStripMenuItem.Click += new System.EventHandler(this.Calculate_Ostium_ToolStripMenuItem_Click);
            // 
            // generateQuadshapedRegionsToolStripMenuItem
            // 
            this.generateQuadshapedRegionsToolStripMenuItem.Name = "generateQuadshapedRegionsToolStripMenuItem";
            this.generateQuadshapedRegionsToolStripMenuItem.Size = new System.Drawing.Size(248, 22);
            this.generateQuadshapedRegionsToolStripMenuItem.Text = "Generate Quadshaped Regions";
            this.generateQuadshapedRegionsToolStripMenuItem.Click += new System.EventHandler(this.Generate_Quadshaped_Regions_ToolStripMenuItem_Click);
            // 
            // generateCircularshapedRegionsToolStripMenuItem
            // 
            this.generateCircularshapedRegionsToolStripMenuItem.Name = "generateCircularshapedRegionsToolStripMenuItem";
            this.generateCircularshapedRegionsToolStripMenuItem.Size = new System.Drawing.Size(248, 22);
            this.generateCircularshapedRegionsToolStripMenuItem.Text = "Generate Circularshaped Regions";
            this.generateCircularshapedRegionsToolStripMenuItem.Click += new System.EventHandler(this.Generate_Circularshaped_Regions_ToolStripMenuItem_Click);
            // 
            // Tb_Cntrl_Main
            // 
            this.Tb_Cntrl_Main.Controls.Add(this.TbPg_Risk_Analysis);
            this.Tb_Cntrl_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Tb_Cntrl_Main.Location = new System.Drawing.Point(0, 25);
            this.Tb_Cntrl_Main.Name = "Tb_Cntrl_Main";
            this.Tb_Cntrl_Main.SelectedIndex = 0;
            this.Tb_Cntrl_Main.Size = new System.Drawing.Size(1904, 1351);
            this.Tb_Cntrl_Main.TabIndex = 1;
            // 
            // TbPg_Risk_Analysis
            // 
            this.TbPg_Risk_Analysis.Controls.Add(this.control_Risk_Analysis1);
            this.TbPg_Risk_Analysis.Location = new System.Drawing.Point(4, 25);
            this.TbPg_Risk_Analysis.Name = "TbPg_Risk_Analysis";
            this.TbPg_Risk_Analysis.Size = new System.Drawing.Size(1896, 1322);
            this.TbPg_Risk_Analysis.TabIndex = 0;
            this.TbPg_Risk_Analysis.Text = "Analysis";
            // 
            // control_Risk_Analysis1
            // 
            this.control_Risk_Analysis1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.control_Risk_Analysis1.Location = new System.Drawing.Point(0, 0);
            this.control_Risk_Analysis1.Margin = new System.Windows.Forms.Padding(4);
            this.control_Risk_Analysis1.Name = "control_Risk_Analysis1";
            this.control_Risk_Analysis1.RenderData = null;
            this.control_Risk_Analysis1.Selected_Dataset_Path = "";
            this.control_Risk_Analysis1.Size = new System.Drawing.Size(1896, 1322);
            this.control_Risk_Analysis1.TabIndex = 0;
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1904, 1376);
            this.Controls.Add(this.Tb_Cntrl_Main);
            this.Controls.Add(this.MnStrp_Main);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.MnStrp_Main;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form_Main";
            this.Text = "Neuro Analytics";
            this.MnStrp_Main.ResumeLayout(false);
            this.MnStrp_Main.PerformLayout();
            this.Tb_Cntrl_Main.ResumeLayout(false);
            this.TbPg_Risk_Analysis.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MnStrp_Main;
        private System.Windows.Forms.ToolStripMenuItem Tl_Strp_Mn_Im_Load_Data;
        private System.Windows.Forms.ToolStripMenuItem Tl_Strp_Mn_Im_Export_Data;
        private System.Windows.Forms.TabControl Tb_Cntrl_Main;
        private System.Windows.Forms.TabPage TbPg_Risk_Analysis;
        private System.Windows.Forms.ToolStripMenuItem Load_Dataset_ToolStripMenuItem;
        private System.Windows.Forms.FolderBrowserDialog Fldr_Brwsr_Load_Dataset;
        private System.Windows.Forms.ToolStripMenuItem dataProcessingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculateMapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vTKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Export_Ostium_ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Export_DomeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scatterplotToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aneurysmToolStripMenuItem;
        private Control_Risk_Analysis Control_Risk_Analysis;
        private System.Windows.Forms.ToolStripMenuItem oBJToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem meshToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oBJToolStripMenuItem1;
        private Control_Risk_Analysis control_Risk_Analysis1;
        private System.Windows.Forms.ToolStripMenuItem calculateOstiumToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generateQuadshapedRegionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem generateCircularshapedRegionsToolStripMenuItem;
    }
}

