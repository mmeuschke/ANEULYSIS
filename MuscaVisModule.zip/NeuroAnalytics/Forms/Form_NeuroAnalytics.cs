﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using NeuroAnalytics.Properties;
using OpenTK;

namespace NeuroAnalytics
{
    public partial class Form_Main : Form
    {
        #region - Private Variables -

        // Data
        private RenderCollection renderdata;

        private string selected_dataset_path;

        private Reader reader;

        #endregion

        #region - Constructors -

        public Form_Main()
        {
            this.InitializeComponent();

            this.selected_dataset_path = "";

            this.renderdata = new RenderCollection();

            this.control_Risk_Analysis1.RenderData = this.renderdata;
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        #region - Load -

        private void Load_Dataset_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Fldr_Brwsr_Load_Dataset.Description = "Select Data Directory";

            string path = @"C:\Temp\";

            this.Fldr_Brwsr_Load_Dataset.SelectedPath = path;

            DialogResult res = this.Fldr_Brwsr_Load_Dataset.ShowDialog();

            //string selected_path;
            string[] subdirectories = new string[] { };

            if (res == DialogResult.OK)
            {
                this.selected_dataset_path = this.Fldr_Brwsr_Load_Dataset.SelectedPath;

                this.control_Risk_Analysis1.Selected_Dataset_Path = this.selected_dataset_path;

                subdirectories = Directory.GetDirectories(this.selected_dataset_path);
            }

            // clear existent render objects
            if (this.renderdata.Render_Meshes_3D.Count > 0)
            {
                this.renderdata.Render_Meshes_3D.Clear();
            }

            // read time information
            this.Read_Meta_Information(this.selected_dataset_path);

            int index = 0;
            int startindex = 0;
            int length = 0;
            int stringlen = 0;

            for (int i = 0; i < subdirectories.Length; i++)
            {
                index = subdirectories[i].LastIndexOf(@"\");

                startindex = index + 1;

                length = subdirectories[i].Length;

                stringlen = length - index - 1;

                this.Load_Data_Items(subdirectories[i].Substring(index + 1, stringlen), subdirectories[i]);
            }

            this.Set_Norm_Values();

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Sampled_Maps_2D)
            {
                item.Value.Sample_Map();
            }

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                item.Value.Calculate_Scalar_Histograms();
            }

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                item.Value.Normalize_Histogram_Values();
            }

            this.control_Risk_Analysis1.Init_Histogram_Rendering();

            this.control_Risk_Analysis1.Update_Scatter_Plot_Size();

            this.control_Risk_Analysis1.Update_Matrix_Gui();

            this.control_Risk_Analysis1.Init_Time_Plot();
        }

        private void Set_Norm_Values()
        {
            if (Utility.norm_values.Count > 0)
            {
                return;
            }

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in item.Value.Scalar_Data)
                {
                    Vector2 nomval = new Vector2(kvp.Value.Min_Value, kvp.Value.Max_Value);

                    if (Utility.norm_values.ContainsKey(kvp.Key))
                    {
                        if (Utility.norm_values[kvp.Key].X > nomval.X)
                        {
                            Utility.norm_values[kvp.Key] = new Vector2(nomval.X, Utility.norm_values[kvp.Key].Y);
                        }

                        if (Utility.norm_values[kvp.Key].Y < nomval.Y)
                        {
                            Utility.norm_values[kvp.Key] = new Vector2(Utility.norm_values[kvp.Key].X, nomval.Y);
                        }
                    }
                    else
                    {
                        Utility.norm_values.Add(kvp.Key, nomval);
                    }
                }
            }
        }

        /// <summary>
        /// Reads the number of timesteps and cycle time
        /// </summary>
        private void Read_Meta_Information(string path)
        {
            XmlDocument doc = new XmlDocument();

            try
            {
                doc.Load(path + @"\Case.xml");

                XmlNode startNode = doc.SelectSingleNode("/Case/Study[@ID = '" + Utility.Study_ID + "']/Reconstruction_Data/Vessel-Mesh/InnerMesh");

                XmlAttributeCollection attribs = startNode.Attributes;

                // Read time information

                Utility.Num_Timesteps = int.Parse(attribs["NumSteps"].Value, Utility.NumberFormat);

                if (!(Utility.Num_Timesteps > 1))
                {
                    Utility.Animation_On = false;
                }

                Utility.Timespan = float.Parse(attribs["Time"].Value, Utility.NumberFormat);

                Utility.Cycle_Time = (Utility.Num_Timesteps - 1) * Utility.Timespan;

                Utility.Systolic_Peak_Time = float.Parse(attribs["Systole"].Value, Utility.NumberFormat);

                // Read stent information
                startNode = doc.SelectSingleNode("/Case/Study[@ID = '" + Utility.Study_ID + "']/Reconstruction_Data/Implantat-Mesh");

                if (startNode.HasChildNodes)
                {
                    XmlNodeList stents = startNode.ChildNodes;

                    for (int i = 0; i < stents.Count; i++)
                    {
                        attribs = stents[i].Attributes;

                        if (attribs != null)
                        {
                            Utility.Stents.Add(attribs["Name"].Value);
                        }
                    }
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Fail to load Case.xml file to read mesh time information");
            }
        }

        private void Load_Data_Items(string name, string datapath)
        {
            switch (name)
            {
                case "MeshInner": this.Read_Data_Mesh(datapath, Settings.Default.MeshInnerName);
                    this.Read_Aneurysm_Map(this.selected_dataset_path, Settings.Default.MeshInnerName);
                    break;

                case "Stents": this.Read_Stent_Configurations(datapath);
                    break;

                default:
                    break;
            }
        }

        private void Read_Data_Mesh(string path, string key)
        {
            string[] mesh_files = Directory.GetFiles(path);

            if (mesh_files.Length > 0)
            {
                string[] file_names = this.Read_File_Order(path);

                List<Vector3> positions;
                List<Vector3> normals;
                List<Triangle> triangles;

                Dictionary<string, Unsteady_Datafield<float>> mesh_scalar_info = new Dictionary<string, Unsteady_Datafield<float>>();
                Dictionary<string, Unsteady_Datafield<Vector3>> mesh_vector_info = new Dictionary<string, Unsteady_Datafield<Vector3>>();

                if (file_names[0].EndsWith("vtp") || file_names[0].EndsWith("vtu"))
                {
                    this.reader = new VTKReader();

                    this.reader.Load(path + @"\" + file_names[0], true, file_names.Length, 0);

                    positions = this.reader.Positions;
                    normals = this.reader.Normals;
                    triangles = this.reader.Triangles;

                    for (int i = 1; i < file_names.Length; i++)
                    {
                        this.reader.Load(path + @"\" + file_names[i], false, file_names.Length, i);
                    }

                    mesh_scalar_info = this.reader.Scalar_Data;
                    mesh_vector_info = this.reader.Vector_Data;

                    string subpath = path.Substring(0, path.LastIndexOf(@"\") + 1);

                    int num_regions = 0;

                    List<int> initial_vertex_regions = this.Read_Plot_Segments(subpath + Settings.Default.BrushedRegionsName, out num_regions);

                    Utility.Num_Regions = num_regions;

                    Mesh_Inner act_mesh = new Mesh_Inner(triangles, positions, normals, mesh_scalar_info, mesh_vector_info, initial_vertex_regions);

                    if (key == Settings.Default.MeshInnerName)
                    {
                        act_mesh.AneurysmPart = this.Read_Aneurysm_Data(this.selected_dataset_path + Settings.Default.AneurysmMeshPath);

                        this.renderdata.Render_Meshes_3D.Add(key, act_mesh);

                        Utility.Stents.Add(Settings.Default.AneurysmNoStentName);
                    }
                    else
                    {
                        act_mesh.AneurysmPart = this.Read_Aneurysm_Data(this.selected_dataset_path + Settings.Default.AneurysmMeshPath);

                        this.renderdata.Render_Meshes_3D.Add(key, act_mesh);
                    }
                }
            }
        }

        private string[] Read_File_Order(string path)
        {
            string[] files = new string[] { };

            string[] all_files = Directory.GetFiles(path);

            for (int i = 0; i < all_files.Length; i++)
            {
                if (all_files[i].EndsWith("mesh_info.txt"))
                {
                    files = System.IO.File.ReadAllLines(all_files[i]);
                }
            }

            return files;
        }

        private AneurysmMesh Read_Aneurysm_Data(string path)
        {
            AneurysmMesh aneurysm = new AneurysmMesh();

            if (!(Directory.Exists(path)))
            {
                return aneurysm;
            }

            try
            {
                string[] aneurysm_files = Directory.GetFiles(path);

                if (aneurysm_files.Length > 0)
                {
                    string[] file_names = this.Read_File_Order(path);

                    Dictionary<string, Unsteady_Datafield<float>> aneurysm_scalar_info = new Dictionary<string, Unsteady_Datafield<float>>();
                    Dictionary<string, Unsteady_Datafield<Vector3>> aneurysm_vector_info = new Dictionary<string, Unsteady_Datafield<Vector3>>();

                    List<Triangle> triangles = new List<Triangle>();

                    if (file_names[0].EndsWith("vtp"))
                    {
                        this.reader = new VTKReader();

                        this.reader.Load(path + @"\" + file_names[0], true, file_names.Length, 0);

                        triangles = this.reader.Triangles;

                        Parallel.For(1, file_names.Length, i =>
                        {
                            this.reader.Load(path + @"\" + file_names[i], false, file_names.Length, i);
                        });

                        aneurysm_scalar_info = this.reader.Scalar_Data;
                        aneurysm_vector_info = this.reader.Vector_Data;

                        aneurysm = new AneurysmMesh(this.reader.Triangles, this.reader.Positions, this.reader.Normals, this.reader.Scalar_Data, this.reader.Vector_Data);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error loading obj file of aneurysm: " + e);
            }

            return aneurysm;
        }

        private List<int> Read_Indices(string path)
        {
            List<int> values = new List<int>();

            if (!(Directory.Exists(path)))
            {
                return values;
            }

            try
            {
                string[] files = Directory.GetFiles(path);

                if (files.Length > 0)
                {
                    for (int i = 0; i < files.Length; i++)
                    {
                        if (files[i].EndsWith("txt"))
                        {
                            this.reader = new TXTReader();

                            this.reader.Load(files[i], true);

                            values = this.reader.Line_Indices;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }

            return values;
        }

        private void Read_Aneurysm_Map(string path, string key)
        {
            string map_path = path + @"\" + Settings.Default.MapName;

            if (!Directory.Exists(map_path))
            {
                return;
            }

            try
            {
                string[] map_files = Directory.GetFiles(map_path);

                if (map_files.Length > 0)
                {
                    string[] file_names = this.Read_File_Order(map_path);

                    Dictionary<string, Unsteady_Datafield<float>> map_scalar_info = new Dictionary<string, Unsteady_Datafield<float>>();
                    Dictionary<string, Unsteady_Datafield<Vector3>> map_vector_info = new Dictionary<string, Unsteady_Datafield<Vector3>>();

                    List<Vector3> positions;
                    List<Triangle> triangles;

                    if (file_names[0].EndsWith("vtp"))
                    {
                        this.reader = new VTKReader();

                        this.reader.Load(map_path + @"\" + file_names[0], true, file_names.Length, 0);

                        triangles = this.reader.Triangles;
                        positions = this.reader.Positions;

                        Parallel.For(1, file_names.Length, i =>
                        {
                            this.reader.Load(map_path + @"\" + file_names[i], false, file_names.Length, i);
                        });

                        map_scalar_info = this.reader.Scalar_Data;
                        map_vector_info = this.reader.Vector_Data;

                        if (this.renderdata.Render_Meshes_3D.ContainsKey(key))
                        {
                            Mesh_Inner act_mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[key];

                            act_mesh.Ostium_Indices = this.Read_Indices(path + @"\" + Settings.Default.OstiumName);

                            act_mesh.Construct_Aneurysm_Ostium();

                            act_mesh.Dome_Indices = this.Read_Indices(path + @"\" + Settings.Default.DomeName);

                            act_mesh.Get_Aneurysm_Part_From_Map(triangles);

                            act_mesh.Rescale_Scalar_Data_To_Aneurysm_Part();

                            foreach (KeyValuePair<string, Unsteady_Datafield<float>> item in act_mesh.Scalar_Data)
                            {
                                Vector2 nomval = new Vector2(item.Value.Min_Value, item.Value.Max_Value);

                                if (Utility.norm_values.ContainsKey(item.Key))
                                {
                                    if (Utility.norm_values[item.Key].X > nomval.X)
                                    {
                                        Utility.norm_values[item.Key] = new Vector2(nomval.X, Utility.norm_values[item.Key].Y);
                                    }

                                    if (Utility.norm_values[item.Key].Y < nomval.Y)
                                    {
                                        Utility.norm_values[item.Key] = new Vector2(Utility.norm_values[item.Key].X, nomval.Y);
                                    }
                                }
                                else
                                {
                                    Utility.norm_values.Add(item.Key, nomval);
                                }
                            }
                            int num_regions = 0;

                            //List<int> initial_vertex_regions = this.Read_Plot_Segments(this.selected_dataset_path + @"\" + Settings.Default.BrushedRegionsName, out num_regions);
                            List<int> initial_vertex_regions = this.Read_Plot_Segments(path + @"\" + Settings.Default.BrushedRegionsName, out num_regions);

                            if (initial_vertex_regions.Count < 1)
                            {
                                initial_vertex_regions = this.Generate_Random_Vertex_Ids();

                                num_regions = initial_vertex_regions.Max() + 1;

                                act_mesh.Inital_Vertex_Region_IDs = initial_vertex_regions.ToArray();

                                act_mesh.Init_Vertex_Region_Colors();
                            }

                            Utility.Num_Regions = num_regions;

                            Map actmapsamp = new Map(act_mesh.Triangles, act_mesh.Positions, act_mesh.Normals, act_mesh.Scalar_Data, triangles, positions, act_mesh.Dome_Indices, act_mesh.Ostium_Indices, true, initial_vertex_regions);

                            actmapsamp.Is_Aneurys_Index = act_mesh.Is_Aneurys_Index;

                            act_mesh.Map_Positions = positions;
                            act_mesh.Map_Triangles = triangles;

                            string texture_path = path + @"\" + Settings.Default.TextureName;

                            VesselPlot act_mesh_plot = new VesselPlot(act_mesh.Scalar_Data, act_mesh.Is_Aneurys_Index, texture_path, num_regions, initial_vertex_regions.ToArray());

                            this.renderdata.Render_Meshes_3D[key] = act_mesh;

                            if (key == Settings.Default.MeshInnerName)
                            {
                                this.renderdata.Render_Sampled_Maps_2D.Add(Settings.Default.SampledAneurysmMapName, actmapsamp);

                                this.renderdata.Aneurysm_Plots.Add(key, act_mesh_plot);
                            }
                            else
                            {
                                this.renderdata.Render_Sampled_Maps_2D.Add(key, actmapsamp);

                                this.renderdata.Aneurysm_Plots.Add(key, act_mesh_plot);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error loading vtp file of aneurysm map: " + e);
            }
        }

        private void Read_Stent_Configurations(string path)
        {
            //string selected_path;
            string[] subdirectories = new string[] { };

            subdirectories = Directory.GetDirectories(path);

            if (subdirectories.Length > 0)
            {
                List<string> dic_names = this.Get_Directory_Names(subdirectories);

                for (int i = 0; i < dic_names.Count; i++)
                {
                    if (Utility.Stents.Contains(dic_names[i]))
                    {
                        this.Read_Stent_Data(path + @"\" + dic_names[i], dic_names[i]);
                    }
                }
            }
        }

        private void Read_Stent_Data(string path, string stentname)
        {
            //string selected_path;
            string[] subdirectories = new string[] { };

            subdirectories = Directory.GetDirectories(path);

            if (subdirectories.Length > 0)
            {
                List<string> dic_names = this.Get_Directory_Names(subdirectories);

                for (int i = 0; i < dic_names.Count; i++)
                {
                    switch (dic_names[i])
                    {
                        case "MeshInner": this.Read_Data_Mesh(subdirectories[i], stentname);
                            this.Read_Aneurysm_Map(path, stentname);
                            break;
                        case "Stent": this.Read_Stent_Mesh(subdirectories[i], stentname);
                            break;

                        default:
                            break;
                    }
                }
            }
        }

        private List<string> Get_Directory_Names(string[] subdirectories)
        {
            List<string> names = new List<string>();
 
            int index = 0;
            int startindex = 0;
            int length = 0;
            int stringlen = 0;

            for (int i = 0; i < subdirectories.Length; i++)
            {
                index = subdirectories[i].LastIndexOf(@"\");

                startindex = index + 1;

                length = subdirectories[i].Length;

                stringlen = length - index - 1;

                names.Add(subdirectories[i].Substring(index + 1, stringlen));
            }

            return names;
        }

        private void Read_Stent_Mesh(string path, string key)
        {
            string[] mesh_files = Directory.GetFiles(path);

            if (mesh_files.Length > 0)
            {
                string[] file_names = this.Read_File_Order(path);

                List<RenderItem> stents = new List<RenderItem>();

                for (int i = 0; i < file_names.Length; i++)
                {
                    List<Vector3> positions;
                    List<Vector3> normals;
                    List<Triangle> triangles;

                    if (file_names[i].EndsWith("vtp") || file_names[i].EndsWith("vtu"))
                    {
                        this.reader = new VTKReader();

                        this.reader.Load(path + @"\" + file_names[i], true, file_names.Length, 0);

                        positions = this.reader.Positions;
                        normals = this.reader.Normals;
                        triangles = this.reader.Triangles;

                        Stent_Mesh act_stent = new Stent_Mesh(triangles, positions, normals);

                        stents.Add(act_stent);
                    }
                }

                this.renderdata.Render_Stents_3D.Add(key, stents);
            }
        }

        private List<int> Read_Plot_Segments(string path, out int max_index)
        {
            List<int> indices = new List<int>();

            if (!(Directory.Exists(path)))
            {
                max_index = 0;

                return indices;
            }

            try
            {
                string[] region_files = Directory.GetFiles(path);

                if (region_files.Length > 0)
                {
                    if (region_files[0].EndsWith("txt"))
                    {
                        this.reader = new TXTReader();

                        this.reader.Load(region_files[0], true);

                        indices = this.reader.Line_Indices;
                    }
                }
            }
            catch (Exception)
            {
            }

            max_index = indices.Max() + 1;

            return indices;
        }

        private List<int> Generate_Random_Vertex_Ids()
        {
            string path = "";

            List<int> vertex_regions = new List<int>();

            string key = "";

           if (this.renderdata.Render_Meshes_3D.ContainsKey(Settings.Default.MeshInnerName))
            {
                key = Settings.Default.MeshInnerName;
            }
            else if (Utility.Stents.Count > 0)
            {
                key = Utility.Stents.First();
            }
            else
            {
                return vertex_regions;
            }
       
            Mesh_Inner actmesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[key];

            path = this.selected_dataset_path + @"\BrushRegions";

            DirectoryInfo di = Directory.CreateDirectory(path);

            string file_dir = path + @"\Indices.txt";

            string lineindex;

            Random rnd = new Random();

            int val = 0;

            using (StreamWriter sw = File.CreateText(file_dir))
            {
                for (int i = 0; i < actmesh.Is_Aneurys_Index.Length; i++)
                {
                    if (actmesh.Is_Aneurys_Index[i] > 0)
                    {
                        val = rnd.Next(0, 5);

                        vertex_regions.Add(val);
                    }
                    else
                    {
                        val = -1;

                        vertex_regions.Add(val);
                    }

                    lineindex = val.ToString();

                    sw.WriteLine(lineindex);
                }

                sw.Flush();

                sw.Close();
            }

            return vertex_regions;
        }

        #endregion

        #region - Data Processing -

        private void Calculate_Map_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.control_Risk_Analysis1.Create_Aneurysm_Map();
        }

        private void Calculate_Ostium_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.control_Risk_Analysis1 != null)
            {
                this.control_Risk_Analysis1.Calculate_Fusiform_Aneurysm_Ostium();
            }
        }

        private void Generate_Quadshaped_Regions_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = this.selected_dataset_path + @"\BrushRegions";

            List<int> vertex_regions = new List<int>();

            if (this.control_Risk_Analysis1 != null)
            {
                vertex_regions = this.control_Risk_Analysis1.Generate_Quad_Shaped_Regions();
            }

            DirectoryInfo di = Directory.CreateDirectory(path);

            string file_dir = path + @"\Indices.txt";

            string lineindex;

            using (StreamWriter sw = File.CreateText(file_dir))
            {
                for (int i = 0; i < vertex_regions.Count; i++)
                {
                    lineindex = vertex_regions[i].ToString();

                    sw.WriteLine(lineindex);
                }

                sw.Flush();

                sw.Close();
            }
        }

        private void Generate_Circularshaped_Regions_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = this.selected_dataset_path + @"\BrushRegions";

            List<int> vertex_regions = new List<int>();

            if (this.control_Risk_Analysis1 != null)
            {
                vertex_regions = this.control_Risk_Analysis1.Generate_Circular_Shaped_Regions();
            }

            DirectoryInfo di = Directory.CreateDirectory(path);

            string file_dir = path + @"\Indices.txt";

            string lineindex;

            using (StreamWriter sw = File.CreateText(file_dir))
            {
                for (int i = 0; i < vertex_regions.Count; i++)
                {
                    lineindex = vertex_regions[i].ToString();

                    sw.WriteLine(lineindex);
                }

                sw.Flush();

                sw.Close();
            }
        }
        #endregion

        #region - Export Data -

        private void Export_Mesh_OBJ_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
             this.Fldr_Brwsr_Load_Dataset.Description = "Select Saving Directory";

            this.Fldr_Brwsr_Load_Dataset.SelectedPath = this.selected_dataset_path;

            DialogResult res = this.Fldr_Brwsr_Load_Dataset.ShowDialog();

            string exported_dataset = "";

            if (res == DialogResult.OK)
            {
                exported_dataset = this.Fldr_Brwsr_Load_Dataset.SelectedPath;
            }
            else
            {
                return;
            }

            foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Meshes_3D)
            {
                Mesh_Inner actmesh = (Mesh_Inner)kvp.Value;

                if (kvp.Key == Settings.Default.MeshInnerName)
                    {
                        string path = exported_dataset + @"\MeshInner";

                        DirectoryInfo di = Directory.CreateDirectory(path);

                        actmesh.Export_to_OBJ(path);
                    }
                    else
                    {
                        string path = exported_dataset + @"\Stents\" + kvp.Key + @"\MeshInner";

                        DirectoryInfo di = Directory.CreateDirectory(path);

                        actmesh.Export_to_OBJ(path);
                    }
            }
        }

        private void Export_Map_VTKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Fldr_Brwsr_Load_Dataset.Description = "Select Saving Directory";

            this.Fldr_Brwsr_Load_Dataset.SelectedPath = this.selected_dataset_path;

            DialogResult res = this.Fldr_Brwsr_Load_Dataset.ShowDialog();

            if (res == DialogResult.OK)
            {
               string exported_dataset = this.Fldr_Brwsr_Load_Dataset.SelectedPath;

               this.Export_Aneurysm_Map_AS_VTP(exported_dataset);
            }

            this.Export_Ostium_ToolStripMenuItem_Click(sender, e);
            this.Export_Dome_ToolStripMenuItem_Click(sender, e);
        }

        private void Export_Map_OBJToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Fldr_Brwsr_Load_Dataset.Description = "Select Saving Directory";

            this.Fldr_Brwsr_Load_Dataset.SelectedPath = this.selected_dataset_path;

            DialogResult res = this.Fldr_Brwsr_Load_Dataset.ShowDialog();

            if (res == DialogResult.OK)
            {
                string exported_dataset = this.Fldr_Brwsr_Load_Dataset.SelectedPath;

                this.Export_Aneurysm_Map_AS_OBJ(exported_dataset);
            }

            this.Export_Ostium_ToolStripMenuItem_Click(sender, e);
            this.Export_Dome_ToolStripMenuItem_Click(sender, e);
        }

        private void Export_Aneurysm_Map_AS_VTP(string exported_dataset)
        {
            string path = "";

            //foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Maps_2D)
            foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Sampled_Maps_2D)
            {
                Map actmap = (Map)kvp.Value;

                if (kvp.Key == Settings.Default.MapName)
                {
                    path = exported_dataset + @"\" + Settings.Default.MapName;

                    DirectoryInfo di = Directory.CreateDirectory(path);

                    actmap.Export_to_VTP(path);
                }
                else
                {
                    path = exported_dataset + @"\Stents\" + kvp.Key + @"\Map";

                    DirectoryInfo di = Directory.CreateDirectory(path);

                    actmap.Export_to_VTP(path);
                }
            }
        }

        private void Export_Aneurysm_Map_AS_OBJ(string exported_dataset)
        {
            string path = "";

            //foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Maps_2D)
            foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Sampled_Maps_2D)
            {
                Map actmap = (Map)kvp.Value;

                if (kvp.Key == Settings.Default.MapName)
                {
                    path = exported_dataset + @"\" + Settings.Default.MapName;

                    DirectoryInfo di = Directory.CreateDirectory(path);

                    actmap.Export_to_OBJ(path);
                }
                else
                {
                    path = exported_dataset + @"\Stents\" + kvp.Key + @"\Map";

                    DirectoryInfo di = Directory.CreateDirectory(path);

                    actmap.Export_to_OBJ(path);
                }
            }
        }

        private void Export_Ostium_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = "";

            foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Meshes_3D)
            {
                Mesh_Inner actmesh = (Mesh_Inner)kvp.Value;

                if (kvp.Key == Settings.Default.MeshInnerName)
                {
                    path = this.selected_dataset_path + @"\Ostium";

                    DirectoryInfo di = Directory.CreateDirectory(path);
                }
                else
                {
                    path = this.selected_dataset_path + @"\Stents\" + kvp.Key + @"\Ostium";

                    DirectoryInfo di = Directory.CreateDirectory(path);
                }

                string file_dir = path + @"\Indices.txt";

                string lineindex;

                using (StreamWriter sw = File.CreateText(file_dir))
                {
                    for (int i = 0; i < actmesh.Ostium_Indices.Count; i++)
                    {
                        lineindex = actmesh.Ostium_Indices[i].ToString();

                        sw.WriteLine(lineindex);
                    }

                    sw.Flush();

                    sw.Close();
                }
            }
        }

        private void Export_Dome_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string path = "";

            foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Meshes_3D)
            {
                Mesh_Inner actmesh = (Mesh_Inner)kvp.Value;

                if (kvp.Key == Settings.Default.MeshInnerName)
                {
                    path = this.selected_dataset_path + @"\Dome";

                    DirectoryInfo di = Directory.CreateDirectory(path);
                }
                else
                {
                    path = this.selected_dataset_path + @"\Stents\" + kvp.Key + @"\Ostium";

                    DirectoryInfo di = Directory.CreateDirectory(path);
                }

                string file_dir = path + @"\Indices.txt";

                string lineindex;

                using (StreamWriter sw = File.CreateText(file_dir))
                {
                    for (int i = 0; i < actmesh.Dome_Indices.Count; i++)
                    {
                        lineindex = actmesh.Dome_Indices[i].ToString();

                        sw.WriteLine(lineindex);
                    }

                    sw.Flush();

                    sw.Close();
                }
            }
        }

        private void Export_Scatterplot_ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Export_Aneurysm_ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Meshes_3D)
            {
                Mesh_Inner actmesh = (Mesh_Inner)kvp.Value;

                if (actmesh.AneurysmPart != null)
                {
                    if (kvp.Key == Settings.Default.MeshInnerName)
                    {
                        string path = this.selected_dataset_path + @"\Aneurysm";

                        DirectoryInfo di = Directory.CreateDirectory(path);

                        actmesh.Seperate_Aneurysm();

                        actmesh.AneurysmPart.Export_to_VTP(path);
                    }
                    else
                    {
                        string path = this.selected_dataset_path + @"\Stents\" + kvp.Key + @"\Aneurysm";

                        DirectoryInfo di = Directory.CreateDirectory(path);

                        actmesh.AneurysmPart.Export_to_VTP(path);
                    }
                }
            }
        }

        #endregion

        #endregion
    }
}
