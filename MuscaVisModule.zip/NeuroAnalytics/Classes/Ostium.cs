﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PCADecomp;
using NeuroAnalytics.Properties;
using MathWorks.MATLAB.NET.Arrays;

using OpenTK;
using OpenTK.Graphics.OpenGL;


namespace NeuroAnalytics
{
    public class Ostium : RenderItem
    {
        #region - Private Variables -

        private List<uint> index_buffer;

        private List<Vector3> colors;

        private Vector3 center;

        private float line_width;

        // VBO Initialization
        private enum VBONames { Pos, Norm, Color, IndexBuffer };

        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        #endregion

        #region - Constructors -

        public Ostium(List<Vector3> Positions, List<Vector3> Normals)
            : base(Settings.Default.OstiumName)
        {
            this.positions = Positions;

            this.normals = Normals;

            this.colors = this.Init_Colors();

            this.index_buffer = new List<uint>();

            this.center = this.Calculate_Center(this.positions);

            this.line_width = 5.0f;

            this.vao = new uint[1];
            this.vbo = new uint[this.number_vbo];
        }

        public Ostium(List<Vector3> Positions, List<Vector3> Normals, List<Vector3> Colors)
            : base(Settings.Default.OstiumName)
        {
            this.positions = Positions;

            this.normals = Normals;

            this.colors = Colors;

            this.index_buffer = new List<uint>();

            this.center = this.Calculate_Center(this.positions);

            this.line_width = 5.0f;

            this.vao = new uint[1];
            this.vbo = new uint[this.number_vbo];
        }

        #endregion

        #region - Properties -

        public Vector3 Center
        {
            get { return this.center; }
            set { this.center = value; }
        }

        public float Line_Width
        {
            get { return this.line_width; }
            set { this.line_width = value; }
        }

        #endregion

        #region - Methods -

        #region - Rendering -

        /// <summary>
        /// Proofs if the ostium is ready to render
        /// </summary>
        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Initializes all used VBO's
        /// </summary>
        public override void SetupRender()
        {
            this.shaderprog.Item_Point_Number = this.positions.Count;

            GL.GenVertexArrays(1, out vao[0]);
            GL.BindVertexArray(vao[0]);
            GL.GenBuffers(vbo.Length, vbo);

            // vbo [0] = position
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Pos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.positions.Count * Vector3.SizeInBytes), this.positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = normal
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Norm]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.normals.Count * Vector3.SizeInBytes), this.normals.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo [2] = colors
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Color]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.colors.Count * Vector3.SizeInBytes), this.colors.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(2, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(2);

            // vbo [3] = index buffer
            this.index_buffer = this.Create_Index_Buffer();
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.index_buffer.Count * sizeof(uint)), this.index_buffer.ToArray(), BufferUsageHint.StaticDraw);

            // Unbind VAO
            GL.BindVertexArray(0);

            this.Init_Setup = true;

            Console.WriteLine("-> Ostium created");
        }

        /// <summary>
        /// Renders the ostium points using triangles
        /// </summary>
        public override void Render()
        {
            if (!this.Renderable())
            {
                return;
            }

            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);

                this.shaderprog.EnableShader();
                {
                    GL.BindVertexArray(vao[0]);
                    {
                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);

                        GL.LineWidth(this.line_width);

                        // #Primitives x #Points per Primitive
                        GL.DrawElements(PrimitiveType.LineStrip, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);

                        GL.LineWidth(1.0f);

                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    }

                    GL.BindVertexArray(0);
                }

                this.shaderprog.DisableShader();
            }

            GL.PopMatrix();
        }

        private List<Vector3> Init_Colors()
        {
            List<Vector3> colors = new List<Vector3>();

            float temp = 1.0f/(float)this.positions.Count;

            float id = 0;

            Vector3[] col = new Vector3[]{new Vector3(0,0,108)/255f,
                                          new Vector3(0,30,135)/255f,
                                          new Vector3(0,88,176)/255f,
                                          new Vector3(0,141,170)/255f,
                                          new Vector3(29,185,90)/255f,
                                          new Vector3(133,204,7)/255f,
                                          new Vector3(216,192,0)/255f,
                                          new Vector3(250,151,14)/255f,
                                          new Vector3(250,63,67)/255f};

            Vector3 newcol = col.Last();

          
            for (int j = 0; j < this.positions.Count; j++)
            {
                id = (float)j * temp;

                if (id < 0)
                {
                    id = 0;
                }

                if (id > 1)
                {
                    id = 1;
                }

                for (int i = 0; i < col.Length-1; i++)
                {
                    if (id >= ((float)i / (float)col.Length) && id <= ((float)(i + 1) / (float)col.Length))
                    {
                        float new_t = (id - ((float)i / (float)col.Length)) * (float)col.Length;

                        if (new_t > 1.0f)
                        {
                            new_t = 1.0f;
                        }

                        newcol = (1.0f - new_t) * col[i] + new_t * col[i + 1];  
                    }

                }

                colors.Add(newcol);
            }

            colors.Add(col.Last());

            return colors;
        }

        public override void Update_Items_Shader_Variables()
        {
            base.Update_Items_Shader_Variables();

            this.shaderprog.Item_Point_Number = this.positions.Count;
        }

        #endregion

        #region - Data Processing -

        public void Calculate_PCA()
        {
            if (this.positions.Count < 1)
            {
                return;
            }

            List<Vector3> variance_vertecis = new List<Vector3>();

            Vector3 act_vert = Vector3.Zero;

            foreach (Vector3 vert in this.positions)
            {
                act_vert = vert - this.center;

                variance_vertecis.Add(act_vert);
            }

            double[,] variance_matrix = new double[3, 3];

            for (int i = 0; i < variance_vertecis.Count; i++)
            {
                variance_matrix[0, 0] += Math.Pow(variance_vertecis[i].X, 2);

                variance_matrix[0, 1] += (variance_vertecis[i].X * variance_vertecis[i].Y);
                variance_matrix[1, 1] += Math.Pow(variance_vertecis[i].Y, 2);

                variance_matrix[0, 2] += (variance_vertecis[i].X * variance_vertecis[i].Z);
                variance_matrix[1, 2] += (variance_vertecis[i].Y * variance_vertecis[i].Z);
                variance_matrix[2, 2] += Math.Pow(variance_vertecis[i].Z, 2);
            }

            variance_matrix[1, 0] = variance_matrix[0, 1];
            variance_matrix[2, 0] = variance_matrix[0, 2];

            variance_matrix[2, 1] = variance_matrix[1, 2];

            for (int i = 0; i < variance_matrix.GetLength(0); i++)
            {
                for (int j = 0; j < variance_matrix.GetLength(1); j++)
                {
                    variance_matrix[i, j] = variance_matrix[i, j] / (this.positions.Count - 1);
                }
            }

            PCA eigendecomp = new PCA();

            MWCellArray celloutPCA = null;

            celloutPCA = (MWCellArray)eigendecomp.PCADecomp((MWNumericArray)variance_matrix, (MWNumericArray)0);

            MWNumericArray egval = (MWNumericArray)celloutPCA[1];
            MWNumericArray egvec = (MWNumericArray)celloutPCA[2];

            double lambda_1, lambda_2, lambda_3;

            lambda_1 = (double)egval[1, 1]; // Unsorted Diagonal Entries
            lambda_2 = (double)egval[2, 2];
            lambda_3 = (double)egval[3, 3];

            this.eigenvalues = new Vector3((float)lambda_1, (float)lambda_2, (float)lambda_3);

            double e11 = (double)egvec[1, 1];
            double e21 = (double)egvec[2, 1];
            double e31 = (double)egvec[3, 1];

            this.e3 = new Vector3((float)e11, (float)e21, (float)e31); // eigenvector according to smallest eigenvalue

            this.e3 = this.e3 * (float)Math.Sqrt(lambda_1);

            double e12 = (double)egvec[1, 2];
            double e22 = (double)egvec[2, 2];
            double e32 = (double)egvec[3, 2];

            this.e2 = new Vector3((float)e12, (float)e22, (float)e32);

            this.e2 = this.e2 * (float)Math.Sqrt(lambda_2);

            double e13 = (double)egvec[1, 3];
            double e23 = (double)egvec[2, 3];
            double e33 = (double)egvec[3, 3];

            this.e1 = new Vector3((float)e13, (float)e23, (float)e33); // eigenvector according to largest eigenvalue

            this.e1 = this.e1 * (float)Math.Sqrt(lambda_3);
        }

        #endregion

        #endregion
    }
}
