﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using NeuroAnalytics.Properties;

namespace NeuroAnalytics
{
    public class PointSphere : RenderItem
    {
        #region - Private Variables -

        private List<int> indices;

        private List<Vector3> colors;

        // VBO Initialization
        private enum VBONames { Pos, Norm, Color };

        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        #endregion

        #region - Constructors -

        public PointSphere()
            : base(Settings.Default.PointSphereName)
        {
            this.indices = new List<int>();

            this.colors = new List<Vector3>();

            this.vao = new uint[1];

            this.vbo = new uint[this.number_vbo];
        }

        #endregion

        #region - Properties -

        public List<int> Indices
        {
            get { return this.indices; }
            set { this.indices = value; }
        }

        public List<Vector3> Colors
        {
            get { return this.colors; }
            set { this.colors = value; }
        }

        #endregion

        #region - Methods -

        /// <summary>
        /// Proofs if the spheres is ready to render
        /// </summary>
        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Initializes all used VBO's
        /// </summary>
        public override void SetupRender()
        {
            // Init VAO
            GL.GenVertexArrays(1, out vao[0]);
            GL.BindVertexArray(vao[0]);

            // vbo [0] = position
            GL.GenBuffers(vbo.Length, vbo);
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Pos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.positions.Count * Vector3.SizeInBytes), this.positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer((int)VBONames.Pos, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray((int)VBONames.Pos);

            // vbo [1] = normals
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Norm]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.normals.Count * Vector3.SizeInBytes), this.normals.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer((int)VBONames.Norm, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray((int)VBONames.Norm);

            // vbo [2] = color
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Color]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.colors.Count * Vector3.SizeInBytes), this.colors.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer((int)VBONames.Color, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray((int)VBONames.Color);

            // Unbind VAO
            GL.BindVertexArray(0);

            this.Init_Setup = true;

            Console.WriteLine("-> Point Spheres created");
        }

        /// <summary>
        /// Renders the points spheres using triangles
        /// </summary>
        public override void Render()
        {
            if (!Renderable())
            {
                return;
            }

            GL.PushMatrix();
            {
                this.shaderprog.EnableShader();
                {
                    GL.BindVertexArray(vao[0]);
                    {
                        GL.DrawArrays(PrimitiveType.Points, 0, this.positions.Count);
                    }
                    GL.BindVertexArray(0);
                }

                this.shaderprog.DisableShader();
            }

            GL.PopMatrix();
        }

        #endregion

        #region IDisposable Member

        public override void Dispose()
        {
            base.Dispose();

            this.positions = null;
            this.normals = null;
            this.colors = null;
            this.indices = null;
        }

        #endregion
    }
}
