﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.IO;
using NeuroAnalytics.Properties;
using MathWorks.MATLAB.NET.Arrays;
using AneurysmSeparation;
using MeshClustering;
using SpectralClusteringWithoutNum;
using SpectralClusteringWithNumber;
using MeshClusterMerging;
using RegionStatistics;
using System.Diagnostics;
using ICPCalculation;
using System.Drawing;

namespace NeuroAnalytics
{
    public abstract class Mesh : RenderItem
    {
        #region - Private Variables -

        protected List<Triangle> triangles;

        protected List<uint> index_buffer;

        #endregion

        #region - Constructors -

        public Mesh(string name)
            : base(name)
        {
            this.triangles = new List<Triangle>();
            this.index_buffer = new List<uint>();
        }

        #endregion

        #region - Properties -

        public List<Triangle> Triangles
        {
            get { return this.triangles; }
            set { this.triangles = value; }
        }

        #endregion

        #region - Methods -

        public virtual void Determine_Triangle_Neighbors()
        {
            for (int i = 0; i < this.triangles.Count; i++)
            {
                for (int j = 0; j < this.triangles.Count; j++)
                {
                    if (i != j)
                    {
                        if (this.triangles[i].Is_Adjacent(this.triangles[j]))
                        {
                            this.triangles[i].Neighbor_Triangle_IDs.Add(this.triangles[j].ID);
                        }
                    }
                }
            }
        }

        public virtual void Set_Mesh_Connectivity(List<List<int>> connectivity)
        {
            for (int i = 0; i < this.triangles.Count; i++)
            {
                if (this.triangles[i].ID <= connectivity.Count)
                {
                    this.triangles[i].Neighbor_Triangle_IDs = connectivity[this.triangles[i].ID];
                }
            }
        }

        #region - Export Data -

        //public override void Export_to_VTP(string path)
        //{
        //    bool is_vert = this.vertex_data.ContainsKey(Settings.Default.SFVertexName);

        //    if (!is_vert)
        //    {
        //        return;
        //    }

        //    string file_dir = path + @"\mesh_info.txt";

        //    int numfiles = Utility.Num_Timesteps;

        //    string filename;

        //    using (StreamWriter sw = File.CreateText(file_dir))
        //    {
        //        for (int i = 0; i < numfiles; i++)
        //        {
        //            filename = "Mesh_" + (i) + ".vtp";

        //            sw.WriteLine(filename);
        //        }

        //        sw.Flush();

        //        sw.Close();
        //    }

        //    VTKWriter writer;

        //    for (int i = 0; i < numfiles; i++)
        //    {
        //        writer = new VTKWriter();

        //        filename = "Mesh_" + (i) + ".vtp";

        //        filename = path + @"\" + filename;

        //        writer.Save_PolyData(filename, this.triangles, this.vertex_data[Settings.Default.SFVertexName].Data_Original, this, i);
        //    }
        //}

        /// <summary>
        /// Write mesh to an OBJ-File
        /// </summary>
        public override void Export_to_OBJ(string path)
        {
            string file_dir = path + @"\mesh_info.txt";

            using (StreamWriter sw = File.CreateText(file_dir))
            {
                for (int i = 0; i < Utility.Num_Timesteps; i++)
                {
                    string filename = "Mesh_" + (i) + ".obj";

                    sw.WriteLine(filename);
                }

                sw.Flush();

                sw.Close();
            }

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                OBJWriter writer = new OBJWriter();

                string filename = @"\Mesh_" + (i) + ".obj";

                writer.Write_Mesh(path + filename, this.triangles, this.positions, this);
            }
        }

        #endregion

        #endregion
    }

    public class Mesh_Inner : Mesh
    {
        #region - Private Variables -

        private List<int> ostium_indices;

        private List<int> dome_indices;

        private int[] is_aneurys_index;

        // Cluster Rendering
        private Shader isoline_shader_prog;

        private bool render_iso_lines;

        private uint[] isoline_lables;
        private float[] cluster_values;

        private WatershedClustering surface_clustering;

        private AneurysmMesh aneurysm_part;

        // map topology
        private List<Vector3> map_positions;
        private List<Triangle> map_triangles;

        // map dimensions
        private Vector2 min_map_dim;
        private Vector2 max_map_dim;

        private int map_vert_count;

        private Ostium mesh_ostium;

        // Transform Feedback
        private List<float> transform_feedback_list;

        private Shader transformfeedback_shader;

        // Contour Rendering
        private Shader contour_shader_prog;

        private bool render_contour;

        private float[] brushed_points;

        // VBO Initialization
        private enum VBONames { Pos, Norm, AneurysmIndex, Map_Pos, IndexBuffer };

        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        // SSBO Initialization
        private enum SSBONames { AllParam, TransformFeedback, Isolinedata, ClusterAVGValues, BrushedId };

        private int number_ssbo =  Enum.GetNames(typeof(SSBONames)).Length; // all parameters are written in one SSBO

        private List<float> all_parameters;

        private List<uint> all_histo_values;

        private bool show_initial_brush;

        private int[] inital_vertex_region_ids;

        private List<int> vertex_region_ids;

        private int[] brushed_reg_indices;

        private float[] selected_colors;

        #endregion

        #region - Constructors -

        public Mesh_Inner(List<Triangle> Triangles, List<Vector3> Positions, List<Vector3> Normals, Dictionary<string,
                          Unsteady_Datafield<float>> Mesh_Scalar_Info, Dictionary<string, Unsteady_Datafield<Vector3>> Mesh_Vector_Info, List<int> Initial_Vertex_Region_Ids)
            : base(Settings.Default.MeshInnerName)
        {
            #region - Topology -

            this.triangles = Triangles;

            this.positions = Positions;

            this.normals = Normals;

            this.map_positions = this.Init_Map_Positions();

            this.map_vert_count = 0;

            this.ostium_indices = new List<int>();

            this.dome_indices = new List<int>();

            this.is_aneurys_index = new int[this.positions.Count];

            this.isoline_lables = new uint[this.positions.Count*Utility.Num_Timesteps];

            this.cluster_values = new float[this.positions.Count * Utility.Num_Timesteps];

            #endregion

            #region - Original Vertex Attributes -

            this.scalar_data = Mesh_Scalar_Info;
            this.vector_data = Mesh_Vector_Info;

            #endregion

            #region  - Rendering Parameters -

            this.brushed_reg_indices = new int[this.positions.Count];

            this.all_histo_values = new List<uint>();

            this.render_contour = true;

            this.render_iso_lines = false;

            this.surface_clustering = new WatershedClustering();

            this.inital_vertex_region_ids = new int[this.positions.Count];

            Initial_Vertex_Region_Ids.CopyTo(this.inital_vertex_region_ids);

            this.show_initial_brush = true;

            this.vertex_region_ids = Initial_Vertex_Region_Ids;

            this.selected_colors = this.Init_Vertex_Region_Colors();

            this.vao = new uint[1];

            this.vbo = new uint[this.number_vbo];

            this.ssbo = new uint[this.number_ssbo];

            #endregion
        }

        #endregion

        #region - Properties -

        public List<int> Ostium_Indices
        {
            get { return this.ostium_indices; }
            set { this.ostium_indices = value;}
        }

        public List<int> Dome_Indices
        {
            get { return this.dome_indices; }
            set { this.dome_indices = value; }
        }

        public Ostium Mesh_Ostium
        {
            get { return this.mesh_ostium; }
            set { this.mesh_ostium = value; }
        }

        public AneurysmMesh AneurysmPart
        {
            get { return this.aneurysm_part; }
            set { this.aneurysm_part = value; }
        }

        public List<Vector3> Map_Positions
        {
            get { return this.map_positions; }
            set { this.map_positions = value;

            this.Get_Map_Dimensions();
            }
        }

        public List<Triangle> Map_Triangles
        {
            get { return this.map_triangles; }
            set { this.map_triangles = value;}
        }

        public int[] Is_Aneurys_Index
        {
            get { return this.is_aneurys_index; }
            set { this.is_aneurys_index = value; }
        }

        public Shader Transformfeedback_Shader
        {
            get { return this.transformfeedback_shader; }
            set { this.transformfeedback_shader = value; }
        }

        public float[] Brushed_Points 
        {
            get { return this.brushed_points; }
            set { this.brushed_points = value; }
        }

        public List<float> TransformFeedbackList
        {
            get { return this.transform_feedback_list; }
            set { this.transform_feedback_list = value; }
        }

        public int[] Brushed_Region_Indices
        {
            get { return this.brushed_reg_indices; }
            set { this.brushed_reg_indices = value; }
        }

        public bool Show_Initial_Brush
        {
            get { return this.show_initial_brush; }
            set { this.show_initial_brush = value; }
        }

        public int[] Inital_Vertex_Region_IDs
        {
            get { return this.inital_vertex_region_ids; }
            set { this.inital_vertex_region_ids = value; }
        }

        public List<int> Vertex_Region_IDs
        {
            get { return this.vertex_region_ids; }
            set { this.vertex_region_ids = value; }
        }

        public List<uint> All_Histo_Values
        {
            get { return this.all_histo_values; }
            set { this.all_histo_values = value; }
        }

        public bool Render_Cont
        {
            get { return this.render_contour; }
            set { this.render_contour = value; }
        }

        public bool Render_IsoLines
        {
            get { return this.render_iso_lines; }
            set { this.render_iso_lines = value; }
        }

        public uint[] IsoLine_Lables
        {
            get { return this.isoline_lables; }
            set { this.isoline_lables = value; }
        }

        public float[] Cluster_Values
        {
            get { return this.cluster_values; }
            set { this.cluster_values = value; }
        }

        public float[] Selected_Colors
        {
            get { return this.selected_colors; }
            set { this.selected_colors = value; }
        }

        public Shader Isoline_Shader_Prog
        {
            get { return this.isoline_shader_prog; }
            set { this.isoline_shader_prog = value; }
        }

        #endregion

        #region - Methods -

        #region - Rendering -

        /// <summary>
        /// Proofs if the mesh is ready to render
        /// </summary>
        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Initializes all used VBO's and SSBO's
        /// </summary>
        public override void SetupRender()
        {
            if (this.show_initial_brush)
            {
                this.vertex_region_ids = this.inital_vertex_region_ids.ToList();

                this.selected_colors = Init_Vertex_Region_Colors();
            }
           
            this.shaderprog.Brushing_Colors = this.selected_colors;

            this.transform_feedback_list = this.Init_Transform_Feedback();

            this.Convert_Vector_Attributes_To_Lists();

            this.Get_Scalar_SSBO_Inputs();

            this.all_parameters = Reorder_All_Attribute_List();

            // Set number scalar fields
            this.shaderprog.Num_Scalar_Fields = this.scalar_data.Count;

            this.shaderprog.Item_Point_Number = this.positions.Count;

            // Set map dimensions
            this.shaderprog.Max_Map_Dim = this.max_map_dim;
            this.shaderprog.Min_Map_Dim = this.min_map_dim;

            this.Init_Transformfeedback_Shader();

            GL.GenVertexArrays(1, out this.vao[0]);
            GL.BindVertexArray(this.vao[0]);

            // vbo [0] = vertex position
            GL.GenBuffers(this.vbo.Length, this.vbo);
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Pos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.positions.Count * Vector3.SizeInBytes), this.positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = vertex normal
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Norm]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.normals.Count * Vector3.SizeInBytes), this.normals.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo [2] = aneurysm indices
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.AneurysmIndex]);
            GL.BufferData(BufferTarget.ArrayBuffer, (IntPtr)(this.is_aneurys_index.Length * sizeof(int)), this.is_aneurys_index, BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(2, 1, VertexAttribPointerType.Int, false, 0, 0);
            GL.EnableVertexAttribArray(2);

            // vbo [3] = map positions
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Map_Pos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.map_positions.Count * Vector3.SizeInBytes), this.map_positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(3, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(3);

            // vbo[4] = triangle index buffer
            this.index_buffer = this.Create_Index_Buffer(this.triangles);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.index_buffer.Count * sizeof(uint)), this.index_buffer.ToArray(), BufferUsageHint.StaticDraw);

            GL.BindVertexArray(0);

            // Unbind VAO
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

            //-----------------------------------------------------------------------------------------------------------------------------------------------------------

            // Generate SSBO's
            GL.GenBuffers(this.ssbo.Length, this.ssbo);

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.AllParam]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.all_parameters.Count * sizeof(float)), this.all_parameters.ToArray(), BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // ssbo[1] = brushed vertices
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.TransformFeedback]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.transform_feedback_list.Count * sizeof(float)), this.transform_feedback_list.ToArray(), BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // ssbo[2] = cluster labels
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.Isolinedata]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.isoline_lables.Length * sizeof(uint)), this.isoline_lables, BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // ssbo[3] = cluster values
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.ClusterAVGValues]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.cluster_values.Length * sizeof(float)), this.cluster_values, BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // ssbo[4] = brushing col
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.BrushedId]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.vertex_region_ids.Count * sizeof(int)), this.vertex_region_ids.ToArray(), BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // Init Contour Shader
            this.Init_Contour_Shader();

            // Init Cluster Rendering
            this.Init_Isoline_Cluster_Shader();

            this.Init_Setup = true;

            Console.WriteLine("-> Mesh created");
        }

        /// <summary>
        /// Renders the mesh using triangles
        /// </summary>
        public override void Render()
        {
            if (!this.Renderable())
            {
                return;
            }

            this.Render_Mesh();

            if (this.ShaderProg.Rendered_Mesh > 0)
            {
                if (this.mesh_ostium != null)
                {
                    if (!this.mesh_ostium.Init_Setup || !this.mesh_ostium.Init_Shader)
                    {
                        this.mesh_ostium.Initialize_Render_Item();
                    }

                    this.mesh_ostium.Render();
                }

                if (this.render_contour)
                {
                    this.Render_Contour();
                }

                if (this.isoline_shader_prog != null && this.render_iso_lines)
                {
                    this.Render_Iso_Lines();
                }
            }
        }

        private void Write_Scatterplot()
        {
            //this.scattterplot_write_shader.EnableShader();
            //{
            //    GL.BindVertexArray(vao[0]);
            //    GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);

            //    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.AllParam, ssbo[(uint)SSBONames.AllParam]);
            //    {
            //        GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
            //    }
            //    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.AllParam, 0);

            //    GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
            //    GL.BindVertexArray(0);
            //}

            //this.scattterplot_write_shader.DisableShader();
        }

        private void Render_Mesh()
        {
            // transformfeedback
            if (this.Transformfeedback_Shader.Brushing_On > 0)
            {
                this.transformfeedback_shader.EnableShader();
                {
                    //Console.WriteLine(this.transformfeedback_shader.Brushing_Region_Id);

                    GL.BindVertexArray(vao[0]);
                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);

                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.TransformFeedback, ssbo[(uint)SSBONames.TransformFeedback]);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.BrushedId, ssbo[(uint)SSBONames.BrushedId]);
                    {
                        GL.Enable(EnableCap.RasterizerDiscard);

                        GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
                    }
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.TransformFeedback, 0);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.BrushedId, 0);

                    int len = this.transform_feedback_list.Count;
                    this.brushed_points = new float[len];
                    this.brushed_reg_indices = new int[len];

                    //------------------------------------------------------------------------------------------------------------------------------

                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, ssbo[(uint)SSBONames.TransformFeedback]);

                    GL.GetBufferSubData(BufferTarget.ElementArrayBuffer, (IntPtr)0, (IntPtr)(len * sizeof(float)), this.brushed_points);

                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    
                    //------------------------------------------------------------------------------------------------------------------------------

                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, ssbo[(uint)SSBONames.BrushedId]);

                    GL.GetBufferSubData(BufferTarget.ElementArrayBuffer, (IntPtr)0, (IntPtr)(len * sizeof(int)), this.brushed_reg_indices);

                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

                    //------------------------------------------------------------------------------------------------------------------------------

                    GL.BindVertexArray(0);

                    GL.Disable(EnableCap.RasterizerDiscard);
                }

                this.transformfeedback_shader.DisableShader();
            }

            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);

                this.shaderprog.EnableShader();
                {
                    GL.BindVertexArray(vao[0]);
                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);

                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.AllParam, ssbo[(uint)SSBONames.AllParam]);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.TransformFeedback, ssbo[(uint)SSBONames.TransformFeedback]);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.ClusterAVGValues, ssbo[(uint)SSBONames.ClusterAVGValues]);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.BrushedId, ssbo[(uint)SSBONames.BrushedId]);
                    {
                        GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
                    }
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.AllParam, 0);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.TransformFeedback, 0);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.ClusterAVGValues, 0);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.BrushedId, 0);

                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    GL.BindVertexArray(0);
                }

                this.shaderprog.DisableShader();
            }

            GL.PopMatrix();
        }

        private void Render_Contour()
        {
            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);
                this.contour_shader_prog.EnableShader();
                {
                    GL.BindVertexArray(vao[0]);
                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.AllParam, ssbo[(uint)SSBONames.AllParam]);
                    {
                        // #Primitives x #Points per Primitive
                        GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
                    }
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.AllParam, 0);
                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    GL.BindVertexArray(0);
                }
                this.contour_shader_prog.DisableShader();
            }
            GL.PopMatrix();
        }

        private void Render_Iso_Lines()
        {
            this.isoline_shader_prog.EnableShader();
            {
                GL.BindVertexArray(vao[0]);

                GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.Isolinedata, ssbo[(uint)SSBONames.Isolinedata]);
                {
                    GL.LineWidth(4.0f);

                    GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);

                    GL.LineWidth(1.0f);
                }
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.Isolinedata, 0);
                GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

                GL.BindVertexArray(0);
            }

            this.isoline_shader_prog.DisableShader();
        }

        public void Set_Transform_Feedback_Input()
        {
            //GL.BindBuffer(BufferTarget.ElementArrayBuffer, ssbo[(uint)SSBONames.TransformFeedback]);

            //GL.BufferSubData(BufferTarget.ElementArrayBuffer, (IntPtr)0, (IntPtr)(this.transform_feedback_list.Count * sizeof(float)), this.transform_feedback_list.ToArray());

            //GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.TransformFeedback]);

            GL.BufferSubData(BufferTarget.ShaderStorageBuffer, (IntPtr)0, (IntPtr)(this.transform_feedback_list.Count * sizeof(float)), this.transform_feedback_list.ToArray());

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);
        }

        public void Set_Region_Ids_Input()
        {
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.BrushedId]);

            GL.BufferSubData(BufferTarget.ShaderStorageBuffer, (IntPtr)0, (IntPtr)(this.vertex_region_ids.Count * sizeof(int)), this.vertex_region_ids.ToArray());

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);
        }

        public void Set_IsoLines_Input()
        {
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.Isolinedata]);

            GL.BufferSubData(BufferTarget.ShaderStorageBuffer, (IntPtr)0, (IntPtr)(this.isoline_lables.Length * sizeof(uint)), this.isoline_lables);

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);
        }

        public void ReSet_Region_Ids_Input()
        {
            this.vertex_region_ids = this.inital_vertex_region_ids.ToList();

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.BrushedId]);

            GL.BufferSubData(BufferTarget.ShaderStorageBuffer, (IntPtr)0, (IntPtr)(this.vertex_region_ids.Count * sizeof(int)), this.vertex_region_ids.ToArray());

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);
        }

        public override void Update_Items_Shader_Variables()
        {
            base.Update_Items_Shader_Variables();

            this.shaderprog.Num_Scalar_Fields = this.scalar_data.Count;
            this.shaderprog.Item_Point_Number = this.positions.Count;

            if (this.mesh_ostium != null)
            {
                this.mesh_ostium.Update_Render_Item_Shaders();
            }

            this.Init_Transformfeedback_Shader();

            this.Init_ScatterplotWrite_Shader();
        }

        private void Init_SSBO_Vector(string name)
        {
            List<Vector3> value = new List<Vector3>();

            for (int i = 0; i < this.positions.Count; i++)
            {
                value.Add(Vector3.Zero);
            }

            List<List<Vector3>> timedep_values = new List<List<Vector3>>();

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                timedep_values.Add(value);
            }

            this.Integrate_Vectorfeld(name, timedep_values);

            this.Convert_Single_Vector_Attribute_To_Lists(name);
        }

        private void Init_SSBO_Scalar(string name)
        {
            List<float> value = new List<float>();

            for (int i = 0; i < this.positions.Count; i++)
            {
                value.Add(0);
            }

            List<List<float>> timedep_values = new List<List<float>>();

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                timedep_values.Add(value);
            }

            this.Integrate_Scalarfield(name, timedep_values);

            this.Convert_Single_Scalar_Attribute_To_List(name);
        }

        private List<float> Init_Transform_Feedback()
        {
            List<float> values = new List<float>();

            for (int i = 0; i < this.positions.Count; i++)
            {
                values.Add(0);
            }

            return values;
        }

        public float[] Init_Vertex_Region_Colors()
        {
            float[] values = new float[Utility.Max_Region_Colors*3];

            for (int i = 0, j = 0; i < Utility.Num_Regions; i++, j+=3)
            {
                values[j] = Utility.Initial_Brush_Region_Colors[i].X;
                values[j+1] = Utility.Initial_Brush_Region_Colors[i].Y;
                values[j+2] = Utility.Initial_Brush_Region_Colors[i].Z;
            }

            return values;
        }

        private List<Vector3> Init_Map_Positions()
        {
            List<Vector3> map_positions = new List<Vector3>();

            for (int i = 0; i < this.positions.Count; i++)
            {
                map_positions.Add(Vector3.Zero);
            }

            return map_positions;
        }

        public void Init_Contour_Shader()
        {
            List<string> shaderpathes = new List<string>();

            string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + @"Contour_3D\";

            shaderpathes.Add(shaderpath + "2_contour_3d.vert");
            shaderpathes.Add(shaderpath + "2_contour_3d.geom");
            shaderpathes.Add(shaderpath + "2_contour_3d.frag");

            this.contour_shader_prog = new Shader(shaderpathes);

            this.contour_shader_prog.Item_Point_Number = this.positions.Count;
            this.contour_shader_prog.Snd_Rendered_Prop = this.shaderprog.Snd_Rendered_Prop;
            this.contour_shader_prog.Contour_Val = this.shaderprog.Contour_Val;

            if (this.shaderprog.Hatching_Active_Val > 0)
            {
                this.render_contour = true;
            }
            else
            {
                this.render_contour = false;
            }
        }

        public void Init_Isoline_Cluster_Shader()
        {
            List<string> shaderpathes = new List<string>();

            string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + @"Isolines\";

            shaderpathes.Add(shaderpath + "2_isolines.vert");
            shaderpathes.Add(shaderpath + "2_isolines.geom");
            shaderpathes.Add(shaderpath + "2_isolines.frag");

            this.isoline_shader_prog = new Shader(shaderpathes);

            this.isoline_shader_prog.Item_Point_Number = this.positions.Count;
        }

        private void Get_Map_Dimensions()
        {
            float xmax = 0;
            float ymax = 0;
            float xmin = float.MaxValue;
            float ymin = float.MaxValue;

            for (int i = 0; i < this.map_positions.Count; i++)
            {
                if (this.map_positions[i].X > xmax)
                {
                    xmax = this.map_positions[i].X;
                }
                if (this.map_positions[i].X < xmin)
                {
                    xmin = this.map_positions[i].X;
                }
                if (this.map_positions[i].Y > ymax)
                {
                    ymax = this.map_positions[i].Y;
                }
                if (this.map_positions[i].Y < ymin)
                {
                    ymin = this.map_positions[i].Y;
                }
            }

            this.max_map_dim = new Vector2(xmax, ymax);
            this.min_map_dim = new Vector2(xmin, ymin);
        }

        public void Init_Transformfeedback_Shader()
        {
            //if (!(this.transformfeedback_shader == null))
            //{
            //    return;
            //}

            List<string> shaderpathes = new List<string>();

            string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + Settings.Default.TransformfeedbackPath;

            shaderpathes.Add(shaderpath + "transformfeed.vert");

            this.transformfeedback_shader = new Shader(shaderpathes);
        }

        public void Init_ScatterplotWrite_Shader()
        {
            //if (!(this.scattterplot_write_shader == null))
            //{
            //    return;
            //}

            //List<string> shaderpathes = new List<string>();

            //string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + @"Scatterplot\";

            //shaderpathes.Add(shaderpath + "2_scatterplotwrite.vert");
            //shaderpathes.Add(shaderpath + "2_scatterplotwrite.geom");
            //shaderpathes.Add(shaderpath + "2_scatterplotwrite.frag");

            //this.scattterplot_write_shader = new Shader(shaderpathes);

            //this.scattterplot_write_shader.Num_Scalar_Fields = this.scalar_data.Count;

            //this.scattterplot_write_shader.Item_Point_Number = this.positions.Count;
        }

        public void Update_SSBO(string scalarfield_key)
        {
            this.Update_Render_Item();
        }

        public override void Update_Child_Render_Objects()
        {
            base.Update_Child_Render_Objects();

            if (this.contour_shader_prog != null)
            {
                this.contour_shader_prog.Contour_Val = this.shaderprog.Contour_Val;
                this.contour_shader_prog.Snd_Rendered_Prop = this.shaderprog.Snd_Rendered_Prop;

                this.contour_shader_prog.Fst_Rescale = this.shaderprog.Fst_Rescale;
                this.contour_shader_prog.Snd_Rescale = this.shaderprog.Snd_Rescale;
            }

            if (this.shaderprog.Hatching_Active_Val > 0)
            {
                this.render_contour = true;
            }
            else
            {
                this.render_contour = false;
            }
        }

        #endregion

        #region - Interaction -

        public override int Calculate_Picked_Triangle(Vector3 P, Vector3 d, out Vector3 hit_point, out Vector3 hit_normal)
        {
            List<Triangle> intersected_Tri = this.Calculate_Ray_Intersection(P, d);

            if (!(intersected_Tri.Count > 0))
            {
                hit_point = Vector3.Zero;
                hit_normal = Vector3.Zero;

                return -1;
            }

            Triangle nearest_tri = intersected_Tri.First();

            if (this.Get_Nearest_Picked_Triangle(intersected_Tri, P, out nearest_tri))
            {
                float d0 = (P - this.positions[nearest_tri.VIndex_0]).LengthSquared;
                float d1 = (P - this.positions[nearest_tri.VIndex_1]).LengthSquared;
                float d2 = (P - this.positions[nearest_tri.VIndex_2]).LengthSquared;

                if (d0 <= d1 && d0 <= d2)
                {
                    hit_point = this.positions[nearest_tri.VIndex_0];
                    hit_normal = this.normals[nearest_tri.VIndex_0];

                    return nearest_tri.VIndex_0;
                }
                else if (d1 <= d0 && d1 <= d2)
                {
                    hit_point = this.positions[nearest_tri.VIndex_1];
                    hit_normal = this.normals[nearest_tri.VIndex_1];

                    return nearest_tri.VIndex_1;
                }
                else
                {
                    hit_point = this.positions[nearest_tri.VIndex_2];
                    hit_normal = this.normals[nearest_tri.VIndex_2];

                    return nearest_tri.VIndex_2;
                }
            }
            else
            {
                hit_point = Vector3.Zero;
                hit_normal = Vector3.Zero;

                return -1;
            }
        }

        private List<Triangle> Calculate_Ray_Intersection(Vector3 P, Vector3 d)
        {
            Vector3 u = Vector3.Zero;
            Vector3 v = Vector3.Zero;
            Vector3 w = Vector3.Zero;

            int index_0 = 0;
            int index_1 = 0;
            int index_2 = 0;

            List<Triangle> intersected_Tri = new List<Triangle>();

            for (int i = 0; i < this.triangles.Count; i++)
            {
                index_0 = this.triangles[i].VIndex_0;
                index_1 = this.triangles[i].VIndex_1;
                index_2 = this.triangles[i].VIndex_2;

                u = this.positions[index_1] - this.positions[index_0];
                v = this.positions[index_2] - this.positions[index_0];
                w = P - this.positions[index_0];

                Vector3 cross_dv = Vector3.Cross(d, v);
                Vector3 cross_wu = Vector3.Cross(w, u);

                float scalar_prod_u = Vector3.Dot(cross_dv, u);
                float scalar_prod_v = Vector3.Dot(cross_wu, v);
                float scalar_prod_w = Vector3.Dot(cross_dv, w);
                float scalar_prod_d = Vector3.Dot(cross_wu, d);

                Vector3 para_coords = (1.0f / scalar_prod_u) * new Vector3(scalar_prod_v, scalar_prod_w, scalar_prod_d);

                if (para_coords.Y >= 0.0f && para_coords.Y <= 1.0f && para_coords.Z >= 0.0f && para_coords.Z <= 1.0f && (para_coords.Y + para_coords.Z) <= 1.0f)
                {
                    intersected_Tri.Add(this.triangles[i]);
                }
            }

            return intersected_Tri;
        }

        private bool Get_Nearest_Picked_Triangle(List<Triangle> triangles, Vector3 Near_Plane, out Triangle nearest_tri)
        {
            float dist = float.MaxValue;
            float act_dist = 0;

            if (!(triangles.Count > 0))
            {
                nearest_tri = new Triangle(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Vector3.Zero, Vector3.Zero, Vector3.Zero);

                return false;
            }

            try
            {
                nearest_tri = triangles.First();

                for (int i = 0; i < triangles.Count; i++)
                {
                    act_dist = (triangles[i].Center - Near_Plane).Length;

                    if (act_dist < dist)
                    {
                        dist = act_dist;

                        nearest_tri = triangles[i];
                    }
                }

                return true;
            }
            catch (Exception)
            {
                nearest_tri = triangles.First();

                return false;
            }
        }

        #endregion

        #region - Data Processing -

        public void Seperate_Aneurysm()
        {
            AneurysmSep aneurysma = new AneurysmSep();

            double[,] points = new double[3, this.positions.Count];
            double[,] triangles = new double[3, this.triangles.Count];
            double[,] dome_ind = new double[1, this.dome_indices.Count];
            double[,] ostium_ind = new double[1, this.ostium_indices.Count + 1];

            for (int i = 0; i < this.positions.Count; i++)
            {
                points.SetValue(this.positions[i].X, 0, i);
                points.SetValue(this.positions[i].Y, 1, i);
                points.SetValue(this.positions[i].Z, 2, i);
            }

            //triangle indices müssen bei 1 beginnen, da matlab 1 basiert ist
            for (int i = 0; i < this.triangles.Count; i++)
            {
                triangles.SetValue(this.triangles[i].VIndex_0 + 1, 0, i);
                triangles.SetValue(this.triangles[i].VIndex_1 + 1, 1, i);
                triangles.SetValue(this.triangles[i].VIndex_2 + 1, 2, i);
            }

            for (int i = 0; i < this.dome_indices.Count; i++)
            {
                dome_ind.SetValue(this.dome_indices[i] + 1, 0, i);
            }

            for (int i = 0; i < this.ostium_indices.Count; i++)
            {
                ostium_ind.SetValue(this.ostium_indices[i] + 1, 0, i);
            }

            ostium_ind.SetValue(this.ostium_indices.First() + 1, 0, this.ostium_indices.Count);


            MWCellArray celloutaneurysm = null;

            celloutaneurysm = (MWCellArray)aneurysma.Get_AneurysmPart((MWNumericArray)points, (MWNumericArray)triangles, (MWNumericArray)ostium_ind, (MWNumericArray)dome_ind);

            MWNumericArray triangulation = (MWNumericArray)celloutaneurysm[1];
            MWNumericArray ostium_path = (MWNumericArray)celloutaneurysm[2];
            MWNumericArray aneurysm_indices = (MWNumericArray)celloutaneurysm[3];

            double act_in_0 = 0;
            int act_index_0 = 0;

            this.ostium_indices.Clear();

            for (int i = 1; i <= ostium_path.Dimensions[1]; i++)
            {
                act_in_0 = (double)ostium_path[1, i];

                act_index_0 = (int)act_in_0 - 1;

                this.ostium_indices.Add(act_index_0);
            }

            // Read 3D Ostium Path
            List<Vector3> ostium_positions = this.Read_3D_Path(ostium_path);
            List<Vector3> ostium_normals = this.Read_3D_Normals(ostium_path);

            this.mesh_ostium = new Ostium(ostium_positions, ostium_normals);

            this.mesh_ostium.Line_Width = 7.0f;

            // Read Aneurysm Indices
            List<int> aneurysm_ind = new List<int>();

            for (int i = 1; i <= aneurysm_indices.Dimensions[0]; i++)
            {
                act_in_0 = (double)aneurysm_indices[i, 1];

                act_index_0 = (int)act_in_0 - 1;

                aneurysm_ind.Add(act_index_0);
            }

            // Read Aneurysm Triangles
            List<Triangle> aneurysm_triangles = new List<Triangle>();

            double in_0 = 0;
            double in_1 = 0;
            double in_2 = 0;

            int index_0 = 0;
            int index_1 = 0;
            int index_2 = 0;

            Vector3 p_0_3d;
            Vector3 p_1_3d;
            Vector3 p_2_3d;

            Triangle tri3d;

            Array triangulation_2D = triangulation.ToArray();

            for (int i = 0; i < triangulation_2D.GetLength(1); i++)
            {
                in_0 = (double)triangulation_2D.GetValue(0, i);
                in_1 = (double)triangulation_2D.GetValue(1, i);
                in_2 = (double)triangulation_2D.GetValue(2, i);

                index_0 = (int)in_0 - 1;
                index_1 = (int)in_1 - 1;
                index_2 = (int)in_2 - 1;

                p_0_3d = this.positions[index_0];
                p_1_3d = this.positions[index_1];
                p_2_3d = this.positions[index_2];

                tri3d = new Triangle(0, index_0, index_1, index_2, index_0, index_1, index_2, index_0, index_1, index_2, p_0_3d, p_1_3d, p_2_3d);

                aneurysm_triangles.Add(tri3d);
            }

            List<Vector3> aneurysm_normals;
            List<Vector3> aneurysm_positions = this.Reorder_Aneurysm_Surface(aneurysm_ind, ref aneurysm_triangles, out aneurysm_normals);

            // Create Aneurysm Surface
            Dictionary<string, Unsteady_Datafield<float>> aneurysm_scalar_info = new Dictionary<string, Unsteady_Datafield<float>>();

            Dictionary<string, Unsteady_Datafield<Vector3>> aneurysm_vector_info = new Dictionary<string, Unsteady_Datafield<Vector3>>();

            this.aneurysm_part = new AneurysmMesh(aneurysm_triangles, aneurysm_positions, aneurysm_normals, aneurysm_scalar_info, aneurysm_vector_info);
        }

        public void Construct_Aneurysm_Ostium()
        {
            if (this.ostium_indices.Count < 1)
            {
                return;
            }

            List<Vector3> positions = new List<Vector3>();
            List<Vector3> normals = new List<Vector3>();

            for (int i = 0; i < this.ostium_indices.Count; i++)
            {
                positions.Add(this.positions[ostium_indices[i]]);

                normals.Add(this.normals[ostium_indices[i]]);
            }

            this.mesh_ostium = new Ostium(positions, normals);

            this.mesh_ostium.Line_Width = 7.0f;
        }

        public void Construct_Aneurysm_Ostium(List<Vector3> colors)
        {
            if (this.ostium_indices.Count < 1)
            {
                return;
            }

            List<Vector3> positions = new List<Vector3>();
            List<Vector3> normals = new List<Vector3>();

            for (int i = 0; i < this.ostium_indices.Count; i++)
            {
                positions.Add(this.positions[this.ostium_indices[i]]);

                normals.Add(this.normals[this.ostium_indices[i]]);
            }

            this.mesh_ostium = new Ostium(positions, normals, colors);

            this.mesh_ostium.Line_Width = 7.0f;
        }

        private List<Vector3> Read_3D_Path(MWNumericArray path)
        {
            double in_0 = 0;
            int index_0 = 0;

            List<Vector3> threed_points = new List<Vector3>();
            Vector3 np = Vector3.Zero;

            for (int i = 1; i <= path.Dimensions[1]; i++)
            {
                in_0 = (double)path[1, i];

                index_0 = (int)in_0 - 1;

                np = new Vector3(this.positions[index_0].X, this.positions[index_0].Y, this.positions[index_0].Z);

                threed_points.Add(np);
            }

            return threed_points;
        }

        private List<Vector3> Read_3D_Normals(MWNumericArray path)
        {
            double in_0 = 0;

            int index_0 = 0;

            List<Vector3> threed_normals = new List<Vector3>();
            Vector3 np = Vector3.Zero;

            for (int i = 1; i <= path.Dimensions[1]; i++)
            {
                in_0 = (double)path[1, i];

                index_0 = (int)in_0 - 1;

                np = new Vector3(this.normals[index_0].X, this.normals[index_0].Y, this.normals[index_0].Z);

                threed_normals.Add(np);
            }

            return threed_normals;
        }

        private List<Vector3> Reorder_Aneurysm_Surface(List<int> aneurysm_indices, ref List<Triangle> aneurysm_triangles, out List<Vector3> aneurysm_normals)
        {
            List<Vector3> aneurysm_positions = new List<Vector3>();

            aneurysm_normals = new List<Vector3>();

            int act_index = 0;

            for (int i = 0; i < aneurysm_indices.Count; i++)
            {
                act_index = aneurysm_indices[i];

                aneurysm_positions.Add(this.positions[act_index]);
                aneurysm_normals.Add(this.normals[act_index]);

                for (int j = 0; j < aneurysm_triangles.Count; j++)
                {
                    if (aneurysm_triangles[j].VIndex_0 == act_index)
                    {
                        aneurysm_triangles[j].VIndex_0 = i;
                        aneurysm_triangles[j].NIndex_0 = i;
                        aneurysm_triangles[j].TIndex_0 = i;
                    }

                    if (aneurysm_triangles[j].VIndex_1 == act_index)
                    {
                        aneurysm_triangles[j].VIndex_1 = i;
                        aneurysm_triangles[j].NIndex_1 = i;
                        aneurysm_triangles[j].TIndex_1 = i;
                    }

                    if (aneurysm_triangles[j].VIndex_2 == act_index)
                    {
                        aneurysm_triangles[j].VIndex_2 = i;
                        aneurysm_triangles[j].NIndex_2 = i;
                        aneurysm_triangles[j].TIndex_2 = i;
                    }
                }
            }

            return aneurysm_positions;
        }

        public void Get_Aneurysm_Part_From_Map(List<Triangle> map_triangles_2D)
        {
            int index_0;
            int index_1;
            int index_2;

            List<int> aneurysm_indices = new List<int>();

            for (int i = 0; i < map_triangles_2D.Count; i++)
            {
                index_0 = map_triangles_2D[i].VIndex_0;
                index_1 = map_triangles_2D[i].VIndex_1;
                index_2 = map_triangles_2D[i].VIndex_2;

                this.is_aneurys_index[index_0] = 1;
                this.is_aneurys_index[index_1] = 1;
                this.is_aneurys_index[index_2] = 1;

                if (!aneurysm_indices.Contains(index_0))
                {
                    aneurysm_indices.Add(index_0);
                }

                if (!aneurysm_indices.Contains(index_1))
                {
                    aneurysm_indices.Add(index_1);
                }

                if (!aneurysm_indices.Contains(index_2))
                {
                    aneurysm_indices.Add(index_2);
                }
            }

            this.map_vert_count = aneurysm_indices.Count;
        }

        public void Rescale_Scalar_Data_To_Aneurysm_Part()
        {
            float min = float.MaxValue;
            float max = 0;

            float avg_val = 0;
            float counter = 0;

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                if (kvp.Value.Data_Ordered.Count > 0)
                {
                    kvp.Value.Data_Ordered.Clear();
                }

                min = float.MaxValue;
                max = 0;

                avg_val = 0;
                counter = 0;

                for (int i = 0; i < kvp.Value.Data_Unordered.Count; i++)
                {
                    for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
                    {
                        if (this.is_aneurys_index[j] > 0)
                        {
                            kvp.Value.Data_Ordered.Add(kvp.Value.Data_Unordered[i][j]);

                            avg_val += kvp.Value.Data_Unordered[i][j];
                            counter++;

                            if (kvp.Value.Data_Unordered[i][j] < min)
                            {
                                min = kvp.Value.Data_Unordered[i][j];
                            }

                            if (kvp.Value.Data_Unordered[i][j] > max)
                            {
                                max = kvp.Value.Data_Unordered[i][j];
                            }
                        }
                        else
                        {
                            kvp.Value.Data_Ordered.Add(float.MinValue);
                        }
                    }
                }

                kvp.Value.Min_Value = min;
                kvp.Value.Max_Value = max;
                kvp.Value.Avg_Value = avg_val / counter;
            }
        }

        public override void Calculate_Scalar_Histograms()
        {
            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                //float range = (float)Math.Round(Utility.norm_values[kvp.Key].Y, 2) / Utility.Num_Bins;

                float range = Utility.norm_values[kvp.Key].Y / (float)Utility.Num_Bins;

                List<float> ranges = new List<float>();

                if (kvp.Value.Histo_Bin_Values.Count > 0)
                {
                    kvp.Value.Histo_Bin_Values.Clear();
                }

                for (int i = 1; i <= Utility.Num_Bins; i++)
                {
                    ranges.Add((float)i * range);
                }

                for (int i = 0; i < kvp.Value.Data_Unordered.Count; i++)
                {
                    List<int> values = new List<int>();

                    for (int j = 0; j < Utility.Num_Bins; j++)
                    {
                        values.Add(0);
                    }

                    kvp.Value.Histo_Bin_Values.Add(values);
                }

                int is_aneurysm;
                float act_val;

                for (int i = 0; i < kvp.Value.Data_Unordered.Count; i++)
                {
                    for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
                    {
                        act_val = (float)Math.Round(kvp.Value.Data_Unordered[i][j],2);
                        act_val = kvp.Value.Data_Unordered[i][j];
                        is_aneurysm = this.is_aneurys_index[j];

                        if (is_aneurysm > 0)
                        {
                            for (int k = 0; k < ranges.Count; k++)
                            {
                                if (k < ranges.Count - 1)
                                {
                                    if (act_val <= ranges[k])
                                    {
                                        kvp.Value.Histo_Bin_Values[i][k]++;

                                        break;
                                    }
                                }
                                else
                                {
                                    kvp.Value.Histo_Bin_Values[i][k]++;
                                }
                            }
                        }
                    }
                }
            }

            this.Get_Min_Max_Hist_Val();
        }

        public override void Get_Min_Max_Hist_Val()
        {
            int max_histval = 0;
            int min_histval = int.MaxValue;

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                max_histval = 0;
                min_histval = int.MaxValue;

                // Find min und max entry
                for (int i = 0; i < kvp.Value.Histo_Bin_Values.Count; i++)
                {
                    for (int j = 0; j < kvp.Value.Histo_Bin_Values[i].Count; j++)
                    {
                        if (kvp.Value.Histo_Bin_Values[i][j] > max_histval)
                        {
                            max_histval = kvp.Value.Histo_Bin_Values[i][j];
                        }
                        if ((kvp.Value.Histo_Bin_Values[i][j] < min_histval))
                        {
                            min_histval = kvp.Value.Histo_Bin_Values[i][j];
                        }
                    }
                }

                if (Utility.norm_hist_values.ContainsKey(kvp.Key))
                {
                    if (Utility.norm_hist_values[kvp.Key].X > min_histval)
                    {
                        Utility.norm_hist_values[kvp.Key] = new Vector2(min_histval, Utility.norm_hist_values[kvp.Key].Y);
                    }

                    if (Utility.norm_hist_values[kvp.Key].Y < max_histval)
                    {
                        Utility.norm_hist_values[kvp.Key] = new Vector2(Utility.norm_hist_values[kvp.Key].X, max_histval);
                    }
                }
                else
                {
                    Utility.norm_hist_values.Add(kvp.Key, new Vector2(min_histval, max_histval));
                }
            }
        }

        public override void Normalize_Histogram_Values()
        {
            int max_histval = 0;
            int min_histval = int.MaxValue;
            float range = 0;

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                max_histval = (int)Utility.norm_hist_values[kvp.Key].Y;
                min_histval = (int)Utility.norm_hist_values[kvp.Key].X;

                range = max_histval-min_histval;

                float act_val;
                float norm_val;

                // normalize values according to min and max entry
                for (int i = 0; i < kvp.Value.Histo_Bin_Values.Count; i++)
                {
                    for (int j = 0; j < kvp.Value.Histo_Bin_Values[i].Count; j++)
                    {
                        act_val = (float)kvp.Value.Histo_Bin_Values[i][j];

                        if (act_val > 0)
                        {
                            norm_val = ((act_val - (float)min_histval) / range) * ((Utility.Matrix_Size / 2) - 6);

                            //kvp.Value.Histo_Bin_Values[i][j] = (int)norm_val + 1;

                            kvp.Value.Histo_Bin_Values[i][j] = (int)norm_val;
                        }
                    }
                }
            }

            this.Reorder_All_Histo_Values();
        }

        private void Reorder_All_Histo_Values()
        {
            if (this.all_histo_values.Count > 0)
            {
                this.all_histo_values.Clear();
            }
            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                for (int i = 0; i < kvp.Value.Histo_Bin_Values.Count; i++)
                {
                    for (int j = 0; j < Utility.Max_Num_Bins; j++)
                    {
                        if (j >= kvp.Value.Histo_Bin_Values[i].Count)
                        {
                            this.all_histo_values.Add(0);
                        }
                        else
                        {
                            this.all_histo_values.Add((uint)kvp.Value.Histo_Bin_Values[i][j]);
                        }
                    }
                }
            }
            
            int remainingval = Utility.Max_num_Scalar_Fields - this.scalar_data.Count;

            for (int i = 0; i < remainingval; i++)
            {
                for (int j= 0; j < Utility.Num_Timesteps; j++)
                {
                    for (int k = 0; k < Utility.Max_Num_Bins; k++)
                    {
                        this.all_histo_values.Add(0);
                    }
                }
            }
        }

        //public void Cluster_Mesh(List<float> weights, List<int> norm_values, List<int> invert_values)
        //{
        //   SpectralClusteringWOutNum surface_clustering = new SpectralClusteringWOutNum();
        //    //SpectralClusteringWN surface_clustering = new SpectralClusteringWN();

        //    double[,] points = new double[3, this.positions.Count];
        //    double[,] triangles = new double[3, this.map_triangles.Count];
           
        //    double[,] scalar_weights = new double[this.scalar_data.Count, 1];
 
        //    double max_labels = 20;

        //    for (int i = 0; i < this.positions.Count; i++)
        //    {
        //        points.SetValue(this.positions[i].X, 0, i);
        //        points.SetValue(this.positions[i].Y, 1, i);
        //        points.SetValue(this.positions[i].Z, 2, i);
        //    }

        //    //triangle indices müssen bei 1 beginnen, da matlab 1 basiert ist
        //    for (int i = 0; i < this.map_triangles.Count; i++)
        //    {
        //        triangles.SetValue(this.map_triangles[i].VIndex_0 + 1, 0, i);
        //        triangles.SetValue(this.map_triangles[i].VIndex_1 + 1, 1, i);
        //        triangles.SetValue(this.map_triangles[i].VIndex_2 + 1, 2, i);
        //    }

        //    int max_vert_count = 25300;
        //    int time_step = max_vert_count/this.map_vert_count;
        //    time_step = 1;
        //    int time_jump = Utility.Num_Timesteps / time_step;
        //    int size = 2;

        //    //for (int i = 0; i < Utility.Num_Timesteps; i += time_jump)
        //    //{
        //    //    size++;
        //    //}

        //    MWCellArray cluster_mat = new MWCellArray(1, size);

        //    int ns_counter = 0;

        //    int cellindex = 1;

        //    float act_scal;

        //    //for (int i = 0; i < Utility.Num_Timesteps; i += time_jump)
        //    for (int i = 27; i < 29; i ++)
        //    {
        //        double[,] scalar_values = new double[this.scalar_data.Count, this.positions.Count];

        //        foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
        //        {
        //            for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
        //            {
        //                act_scal = kvp.Value.Data_Unordered[i][j];

        //                if (invert_values[ns_counter] > 0)
        //                {
        //                    act_scal = Utility.norm_values[kvp.Key].Y - act_scal;
        //                }

        //                if (norm_values[ns_counter] > 0)
        //                {
        //                    act_scal = (act_scal - Utility.norm_values[kvp.Key].X) / (Utility.norm_values[kvp.Key].Y - Utility.norm_values[kvp.Key].X);
        //                }

        //                scalar_values.SetValue(act_scal, ns_counter, j);
        //            }

        //            ns_counter++;
        //        }

        //        cluster_mat[1, cellindex] = (MWNumericArray)scalar_values;

        //        ns_counter = 0;

        //        cellindex++;
        //    }

        //    for (int i = 0; i < weights.Count; i++)
        //    {
        //        scalar_weights.SetValue(weights[i], i, 0);
        //    }

        //    MWNumericArray cluster_labels = new MWNumericArray();

        //    string clustertype = "RT1";
        //    double sizeN = 7;

        //    //cluster_labels = (MWNumericArray)surface_clustering.HelperFunction((MWNumericArray)points, (MWNumericArray)triangles, (MWCellArray)cluster_mat, (MWNumericArray)scalar_weights, (MWNumericArray)max_labels, (MWCharArray)clustertype, (MWNumericArray)sizeN);
        //    cluster_labels = (MWNumericArray)surface_clustering.HelperFunction((MWNumericArray)points, (MWNumericArray)triangles, (MWCellArray)cluster_mat, (MWNumericArray)scalar_weights, (MWNumericArray)max_labels);

        //    List<int> labels = new List<int>();

        //    double index = 0;
        //    int act_index = 0;

        //    int pos = 27 * this.positions.Count;

        //    for (int i = 1; i <= cluster_labels.Dimensions[1]; i++)
        //    {
        //        index = (double)cluster_labels[1, i];

        //        act_index = (int)index;

        //        labels.Add(act_index);

        //        this.cluster_lables[pos + (i - 1)] = (uint)act_index;
        //    }

        //    max_labels = labels.Max();

        //    //this.Interpolate_Surface_Cluster_Results(labels, time_step);

        //    this.Calculate_Cluster_Color(weights, (int)max_labels);

        //    this.render_cluster_lines = true;

        //    this.Init_Setup = false;
        //}

        public void Cluster_Mesh(List<float> weights, List<int> norm_values, List<int> invert_values)
        {
            double[,] triangles = new double[3, this.map_triangles.Count];

            double[,] scalar_weights = new double[this.scalar_data.Count, 1];

            //triangle indices müssen bei 1 beginnen, da matlab 1 basiert ist
            for (int i = 0; i < this.map_triangles.Count; i++)
            {
                triangles.SetValue(this.map_triangles[i].VIndex_0 + 1, 0, i);
                triangles.SetValue(this.map_triangles[i].VIndex_1 + 1, 1, i);
                triangles.SetValue(this.map_triangles[i].VIndex_2 + 1, 2, i);
            }

            MWCellArray cluster_mat = new MWCellArray(1, Utility.Num_Timesteps);

            int ns_counter = 0;

            int cellindex = 1;

            float act_scal;

            for (int i = 0; i < Utility.Num_Timesteps; i ++)
            {
                double[,] scalar_values = new double[this.scalar_data.Count, this.positions.Count];

                foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
                {
                    for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
                    {
                        act_scal = kvp.Value.Data_Unordered[i][j];

                        if (invert_values[ns_counter] > 0)
                        {
                            act_scal = Utility.norm_values[kvp.Key].Y - act_scal;
                        }

                        if (norm_values[ns_counter] > 0)
                        {
                            act_scal = (act_scal - Utility.norm_values[kvp.Key].X) / (Utility.norm_values[kvp.Key].Y - Utility.norm_values[kvp.Key].X);
                        }

                        scalar_values.SetValue(act_scal, ns_counter, j);
                    }

                    ns_counter++;
                }

                cluster_mat[1, cellindex] = (MWNumericArray)scalar_values;

                ns_counter = 0;

                cellindex++;
            }

            for (int i = 0; i < weights.Count; i++)
            {
                scalar_weights.SetValue(weights[i], i, 0);
            }

            MWNumericArray cluster_labels = new MWNumericArray();

            double thres = 0.5;
            
            cluster_labels = (MWNumericArray)surface_clustering.HelperFunction((MWNumericArray)triangles, (MWCellArray)cluster_mat, (MWNumericArray)scalar_weights, (MWNumericArray)thres);

            List<int> labels = new List<int>();

            double index = 0;
            int act_index = 0;

            int cluster_num = 1;

            Parallel.For(1, cluster_labels.Dimensions[1], i =>
            {
                index = (double)cluster_labels[1, i];

                act_index = (int)index;

                labels.Add(act_index);

                this.isoline_lables[(i - 1)] = (uint)act_index;
            });

            cluster_num = (int)this.isoline_lables.Max();

            int max_index = this.isoline_lables.ToList().IndexOf(12);

            this.Calculate_Cluster_Color(weights, cluster_num, max_index);

            this.render_iso_lines = true;

            this.Init_Setup = false;
        }

        public void Calculate_Brushing_Analysis()
        {
            List<int> br_points = new List<int>();

            if (this.brushed_points == null)
            {
                return;
            }

            for (int i = 0; i < this.positions.Count; i++)
            {
                if (this.brushed_points[i] > 0)
                {
                    br_points.Add(i);
                }
            }

            double[,] vertices = new double[1, br_points.Count];

            for (int i = 0; i < br_points.Count; i++)
            {
                vertices.SetValue(br_points[i] + 1, 0, i);
            }

            MWCellArray sclar_cell = new MWCellArray(1, Utility.Num_Timesteps);

            int ns_counter = 0;

            int cellindex = 1;

            float act_scal;

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                double[,] scalar_values = new double[this.scalar_data.Count, this.positions.Count];

                foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
                {
                    for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
                    {
                        act_scal = kvp.Value.Data_Unordered[i][j];

                        scalar_values.SetValue(act_scal, ns_counter, j);
                    }

                    ns_counter++;
                }

                sclar_cell[1, cellindex] = (MWNumericArray)scalar_values;

                ns_counter = 0;

                cellindex++;
            }

            cellindex = 1;

            MWCellArray sclar_names = new MWCellArray(1, this.scalar_data.Count);

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                sclar_names[1, cellindex] = (MWCharArray)kvp.Key.ToString();

                cellindex++;
            }

            Statistics st = new Statistics();

            st.getStatistics((MWNumericArray)vertices, (MWCellArray)sclar_cell, (MWCellArray)sclar_names);
        }

        private void Interpolate_Surface_Cluster_Results(List<int> red_labels, int timesteps)
        {
            int jump = (Utility.Num_Timesteps/timesteps);

            int t_0 = 0;
            int t_1 = jump;

            int red_t_index0 = 0;
            int red_t_index1 = 1;

            int label_0, label_1;
            int index_l0, index_l1;

            float t;
            float range = ((float)t_1 - (float)t_0);
            uint interpol_val;

            int act_index;

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                if (i > t_1)
                {
                    t_0 = t_1;
                    t_1 = t_0 + jump;

                    range = ((float)t_1 - (float)t_0);

                    red_t_index0++;
                    red_t_index1++;
                }

                if (t_1 < Utility.Num_Timesteps)
                {
                    for (int j = 0; j < this.positions.Count; j++)
                    {
                        index_l0 = j + (red_t_index0 * this.positions.Count);
                        index_l1 = j + (red_t_index1 * this.positions.Count);

                        label_0 = red_labels[index_l0];
                        label_1 = red_labels[index_l1];

                        t = ((float)i - (float)t_0) / range;

                        interpol_val = (uint)Math.Round((1.0f - t) * (float)label_0 + t * (float)label_1);

                        act_index = j + (i * this.positions.Count);

                        this.isoline_lables[act_index] = interpol_val;
                    }
                }
                else
                {
                    for (int j = 0; j < this.positions.Count; j++)
                    {
                        index_l0 = j + (red_t_index0 * this.positions.Count);
                        label_0 = red_labels[index_l0];

                        act_index = j + (i * this.positions.Count);

                        this.isoline_lables[act_index] = (uint)label_0;
                    }
                }
            }
        }

        private void Calculate_Cluster_Color(List<float> weights, int cluster_number, int maxindex)
        {
            int vert_counter = 0;

            int weight_count = 0;

            float[] cluster_avg_values = new float[cluster_number + 1];
            float[] cluster_point_count = new float[cluster_number + 1];

            float val = 0;

            uint actlabel;

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                for (int j = 0; j < this.positions.Count; j++)
                {
                    if (vert_counter == maxindex)
                    {
                        Console.WriteLine(vert_counter);
                    }

                    actlabel = this.isoline_lables[vert_counter];

                    weight_count = 0;

                    if (actlabel > 0)
                    {
                        foreach (KeyValuePair<string, Unsteady_Datafield<float>> item in this.scalar_data)
                        {
                            val = val + (float)Math.Pow(item.Value.Data_Unordered[i][j], 2) * weights[weight_count];

                            weight_count++;
                        }

                        val = (float)Math.Sqrt(val);

                        cluster_avg_values[actlabel] += val;
                        cluster_point_count[actlabel]++;
                    }

                    vert_counter++;

                    val = 0;
                }
            }

            for (int i = 1; i < cluster_avg_values.Length; i++)
            {
                cluster_avg_values[i] = cluster_avg_values[i] / cluster_point_count[i];
            }

            //normalize cluster average values 
            float max = cluster_avg_values.Max();
            float min = float.MaxValue;

            for (int i = 1; i < cluster_avg_values.Length; i++)
            {
                if (cluster_avg_values[i] < min)
                {
                    min = cluster_avg_values[i];
                }
            }

            float range = max - min;

            if (range > float.Epsilon)
            {
                for (int i = 0; i < cluster_avg_values.Length; i++)
                {
                    if (cluster_avg_values[i] > 0)
                    {
                        cluster_avg_values[i] = (cluster_avg_values[i] - min) / range;
                    }
                }
            }

            // set cluster avg values
            vert_counter = 0;
            float act_cluster_val;

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                for (int j = 0; j < this.positions.Count; j++)
                {
                    actlabel = this.isoline_lables[vert_counter];

                    act_cluster_val = cluster_avg_values[actlabel];

                    this.cluster_values[vert_counter] = act_cluster_val;

                    vert_counter++;
                }
            }
        }

        private List<float> Reorder_All_Attribute_List()
        {
            List<float> values = new List<float>();

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                for (int i = 0; i < kvp.Value.Data_Ordered.Count; i++)
                {
                    values.Add(kvp.Value.Data_Ordered[i]);
                }
            }

            return values;
        }

        public void Get_Scalar_SSBO_Inputs()
        {
            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                float avg_val = 0;
                float counter = 0;

                if (kvp.Value.Data_Ordered.Count > 0)
                {
                    kvp.Value.Data_Ordered.Clear();
                }

                for (int i = 0; i < kvp.Value.Data_Unordered.Count; i++)
                {
                    for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
                    {
                        if (this.is_aneurys_index[j] > 0)
                        {
                            kvp.Value.Data_Ordered.Add(kvp.Value.Data_Unordered[i][j]);

                            avg_val += kvp.Value.Data_Unordered[i][j];
                            counter++;
                        }
                        else
                        {
                            kvp.Value.Data_Ordered.Add(float.MinValue);
                        }
                      
                    }
                }

                kvp.Value.Min_Value = Utility.norm_values[kvp.Key].X;
                kvp.Value.Max_Value = Utility.norm_values[kvp.Key].Y;
                kvp.Value.Avg_Value = avg_val / counter;
            }

            // normalization
            this.Normalize_Attribute_Lists();
        }

        public void Update_Isoline_Data(int region_id) // region_id was added with 1 to avoid shader problems
        {
            uint regid = (uint)region_id;

            int counter = 0;

            int[] act_vertex_ids = new int[this.positions.Count];

            if (this.show_initial_brush)
            {
                act_vertex_ids = this.inital_vertex_region_ids;
            }
            else
            {
                act_vertex_ids = this.brushed_reg_indices;     
            }

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                for (int j = 0; j < this.positions.Count; j++)
                {
                    if (act_vertex_ids[j] == (region_id - 1))
                    {
                        this.isoline_lables[counter] = regid;
                    }
                    else
                    {
                        this.isoline_lables[counter] = 0;
                    }

                    counter++;
                }
            }

            this.Set_IsoLines_Input();
        }

        #endregion

        #endregion

        #region IDisposable Member

        public override void Dispose()
        {
            base.Dispose();

            this.triangles = null;
        }

        public override void Clear_Brushing()
        {
            this.Render_IsoLines = false;

            if (this.brushed_points != null && this.brushed_points.Length > 0)
            {
                for (int i = 0; i < this.brushed_points.Length; i++)
                {
                    this.brushed_points[i] = 0;
                }
            }

            if (this.transform_feedback_list != null && this.transform_feedback_list.Count > 0)
            {
                 for (int i = 0; i < this.transform_feedback_list.Count; i++)
                {
                    this.transform_feedback_list[i] = 0;
                }
            }

            if (this.brushed_reg_indices != null && this.brushed_reg_indices.Length > 0)
            {
                for (int i = 0; i < this.brushed_reg_indices.Length; i++)
                {
                    this.brushed_reg_indices[i] = -1;
                }
            }

            if (this.vertex_region_ids != null && this.vertex_region_ids.Count > 0)
            {
                for (int i = 0; i < this.vertex_region_ids.Count; i++)
                {
                    this.vertex_region_ids[i] = -1;
                }
            }

            this.Update_Render_Item();
        }

        #endregion
    }

    public class Stent_Mesh : Mesh
    {
        #region - Private Variables -

        private enum VBONames { StentPos, StentNorm, IndexBuffer };
        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        #endregion

        #region - Constructors -

        public Stent_Mesh(List<Triangle> Triangles, List<Vector3> Positions, List<Vector3> Normals)
            : base(Settings.Default.StentMeshName)
        {
            #region - Topology -

            this.triangles = Triangles;

            this.positions = Positions;

            this.normals = Normals;

            #endregion

            #region  - Rendering Parameters -

            this.vao = new uint[1];

            this.vbo = new uint[this.number_vbo];

            #endregion
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        #region - Rendering -

        /// <summary>
        /// Proofs if the mesh is ready to render
        /// </summary>
        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Initializes all used VBO's and SSBO's
        /// </summary>
        public override void SetupRender()
        {
            GL.GenVertexArrays(1, out this.vao[0]);
            GL.BindVertexArray(this.vao[0]);

            // vbo [0] = vertex position
            GL.GenBuffers(this.vbo.Length, this.vbo);
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.StentPos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.positions.Count * Vector3.SizeInBytes), this.positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = vertex normal
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.StentNorm]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.normals.Count * Vector3.SizeInBytes), this.normals.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo[2] = triangle index buffer
            this.index_buffer = this.Create_Index_Buffer(this.triangles);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.index_buffer.Count * sizeof(uint)), this.index_buffer.ToArray(), BufferUsageHint.StaticDraw);

            GL.BindVertexArray(0);

            // Unbind VAO
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

            this.Init_Setup = true;

            Console.WriteLine("-> Stent Mesh created");
        }

        /// <summary>
        /// Renders the mesh using triangles
        /// </summary>
        public override void Render()
        {
            if (!this.Renderable())
            {
                return;
            }

            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);

                this.shaderprog.EnableShader();
                {
                    GL.BindVertexArray(vao[0]);
                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
                    {
                        GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
                    }
                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    GL.BindVertexArray(0);
                }

                this.shaderprog.DisableShader();
            }

            GL.PopMatrix();
        }

        #endregion

        #region IDisposable Member

        public override void Dispose()
        {
            base.Dispose();

            this.triangles = null;
        }

        #endregion

        #endregion
    }

    public class AneurysmMesh : Mesh
    {
        #region - Private Variables -


        #endregion

        #region - Constructors -

        public AneurysmMesh()
            : base(Settings.Default.AneurysmMeshName)
        { }

        public AneurysmMesh(List<Triangle> Triangles, List<Vector3> Positions, List<Vector3> Normals, 
                            Dictionary<string, Unsteady_Datafield<float>> Aneurysm_Scalar_Info, Dictionary<string, Unsteady_Datafield<Vector3>> Aneurysm_Vector_Info)
            : base(Settings.Default.AneurysmMeshName)
        {
            this.triangles = Triangles;

            this.positions = Positions;

            this.normals = Normals;

            this.scalar_data = Aneurysm_Scalar_Info;

            this.vector_data = Aneurysm_Vector_Info;
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            return true;
        }

        public override void SetupRender()
        {
        }

        public override void Render()
        {
        }

        #region - Interaction -

        private Vector3 Get_Farest_Intersected_Point(Vector3 startpoint, Vector3 dir, out float max_dist)
        {
            max_dist = 0;

            List<Vector3> intersec_positions = this.Calculate_Ray_Intersection(startpoint, dir);

            Vector3 farest_pos = this.Get_Farest_Triangle(startpoint, intersec_positions, out max_dist);

            return farest_pos;
        }

        private Vector3 Get_Farest_Triangle(Vector3 startpoint, List<Vector3> intersec_positions, out float max_dist)
        {
            Vector3 farest_pos = Vector3.Zero;

            float dist = 0;
            max_dist = 0;

            for (int i = 0; i < intersec_positions.Count; i++)
            {
                dist = (intersec_positions[i] - startpoint).Length;

                if (dist > max_dist)
                {
                    max_dist = dist;

                    farest_pos = intersec_positions[i];
                }
            }

            return farest_pos;
        }

        private List<Vector3> Calculate_Ray_Intersection(Vector3 startpoint, Vector3 dir)
        {
            Vector3 u = Vector3.Zero;
            Vector3 v = Vector3.Zero;
            Vector3 w = Vector3.Zero;

            int index_0 = 0;
            int index_1 = 0;
            int index_2 = 0;

            Vector3 para_coords = Vector3.Zero;

            List<Vector3> intersected_Pos = new List<Vector3>();
            Vector3 triangle_pos = Vector3.Zero;

            for (int i = 0; i < this.triangles.Count; i++)
            {
                index_0 = this.triangles[i].VIndex_0;
                index_1 = this.triangles[i].VIndex_1;
                index_2 = this.triangles[i].VIndex_2;

                u = this.positions[index_1] - this.positions[index_0];
                v = this.positions[index_2] - this.positions[index_0];
                w = startpoint - this.positions[index_0];

                Vector3 cross_dv = Vector3.Cross(dir, v);
                Vector3 cross_wu = Vector3.Cross(w, u);

                float scalar_prod_u = Vector3.Dot(cross_dv, u);
                float scalar_prod_v = Vector3.Dot(cross_wu, v);
                float scalar_prod_w = Vector3.Dot(cross_dv, w);
                float scalar_prod_d = Vector3.Dot(cross_wu, dir);

                para_coords = (1.0f / scalar_prod_u) * new Vector3(scalar_prod_v, scalar_prod_w, scalar_prod_d);

                // Get intersected triangle points
                if (para_coords.Y >= 0.0f && para_coords.Y <= 1.0f && para_coords.Z >= 0.0f && para_coords.Z <= 1.0f && (para_coords.Y + para_coords.Z) <= 1.0f)
                {
                    triangle_pos = this.triangles[i].VPosition_0 + para_coords.Y * u + para_coords.Z * v;

                    intersected_Pos.Add(triangle_pos);
                }
            }

            return intersected_Pos;
        }

        #endregion

        #region - Export -

        public override void Export_to_VTP(string path)
        {
            if (!(this.positions.Count >1))
            {
                return;
            }

            string file_dir = path + @"\mesh_info.txt";

            int numfiles = Utility.Num_Timesteps;

            string filename;

            using (StreamWriter sw = File.CreateText(file_dir))
            {
                for (int i = 0; i < numfiles; i++)
                {
                    filename = "Aneurysm_" + (i) + ".vtp";

                    sw.WriteLine(filename);
                }

                sw.Flush();

                sw.Close();
            }

            VTKWriter writer;

            for (int i = 0; i < numfiles; i++)
            {
                writer = new VTKWriter();

                filename = "Aneurysm_" + (i) + ".vtp";

                filename = path + @"\" + filename;

                writer.Save_PolyData(filename, this.triangles, this.positions, this, i);
            }
        }

        #endregion

        #endregion
    }

    public class Cylinder : Mesh
    {
        #region - Private Variables -

        private List<Vector2> cylinder_postions; // sample positions on map

        // Rendering 
        private enum VBONames { CylinderPos, CylinderNorm, IndexBuffer };
        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        private enum SSBONames { MapPos, ScalValues };
        private int number_ssbo = Enum.GetNames(typeof(SSBONames)).Length;

        // SSBO Inputs
        private List<float> cylinder_pos;
        private List<float> cylinderscal_vals;

        #endregion

        #region - Constructors -

        public Cylinder(List<Vector2> Cylinder_Positions, Dictionary<string, Unsteady_Datafield<float>> Cylinder_Sample_Scal_Data)
            : base(Settings.Default.CylinderName)
        {
            this.cylinder_postions = Cylinder_Positions;

            this.scalar_data = Cylinder_Sample_Scal_Data;

            this.Generate_Cylinder(0.05f);

            this.vao = new uint[1];
            this.vbo = new uint[this.number_vbo];
            this.ssbo = new uint[this.number_ssbo];

            this.cylinder_pos = new List<float>();
            this.cylinderscal_vals = new List<float>();

            this.Convert_Scalar_Attributes_To_Lists();

            this.Generate_SSBO_Inputs();
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        #region - Data Processsing -

        private void Generate_Cylinder(float radius)
        {
            List<List<uint>> ellipses = new List<List<uint>>();
            List<uint> act_ellipse;

            uint counter = 0;

            float step = 360 / 100;
            float angleCircle = 0;

            float x, y, z;

            Vector3 act_pos;

            for (uint i = 0; i < Utility.Num_Timesteps; i++)
            {
                angleCircle = 0;

                act_ellipse = new List<uint>();

                while (!(angleCircle > (360 - step)))
                {
                    x = (float)(Math.Sqrt(radius) * Math.Cos(Utility.toRad(angleCircle)));
                    y = (float)(Math.Sqrt(radius) * Math.Sin(Utility.toRad(angleCircle)));
                    z = (float)i;

                    act_pos = new Vector3(x, y, z);

                    this.positions.Add(act_pos);
                    this.normals.Add(Vector3.Zero);
                    act_ellipse.Add(counter);

                    angleCircle += step;
                    counter++;
                }

                ellipses.Add(act_ellipse);
            }

            this.Triangulate_Cylinder(ellipses);

            this.index_buffer = this.Create_Index_Buffer(this.triangles);
        }

        private void Triangulate_Cylinder(List<List<uint>> ellipses)
        {
            for (int i = 0; i < ellipses.Count - 1; i++)
            {
                if (ellipses[i].Count > 0 && ellipses[i + 1].Count > 0)
                {
                    this.Triangulate_Between_Two_Ellipses(ellipses[i], ellipses[i + 1]);
                }
            }
        }

        private void Triangulate_Between_Two_Ellipses(List<uint> first_ellipse, List<uint> sec_ellipse)
        {
            Vector3 edge_1;
            Vector3 edge_2;
            Vector3 normalv1;
            Vector3 normalv2;
            Vector3 normalv3;

            int frt_index, snd_index, trd_index;

            for (int j = 0; j < first_ellipse.Count; j++)
            {
                if (j == (first_ellipse.Count - 1))
                {
                    // first triangle
                    frt_index = (int)first_ellipse[j];
                    snd_index = (int)sec_ellipse[0];
                    trd_index = (int)sec_ellipse[j];

                    // calculate normals
                    edge_1 = new Vector3(this.positions[snd_index] - this.positions[frt_index]);
                    edge_2 = new Vector3(this.positions[trd_index] - this.positions[frt_index]);

                    normalv1 = new Vector3(this.positions[frt_index].X, this.positions[frt_index].Y, 0);
                    normalv2 = new Vector3(this.positions[snd_index].X, this.positions[snd_index].Y, 0);
                    normalv3 = new Vector3(this.positions[trd_index].X, this.positions[trd_index].Y, 0);

                    normalv1.Normalize();
                    normalv2.Normalize();
                    normalv3.Normalize();

                    this.normals[frt_index] = normalv1;
                    this.normals[snd_index] = normalv2;
                    this.normals[trd_index] = normalv3;

                    int id = 0;

                    if (this.triangles.Count > 0)
                    {
                        id = this.triangles.Last().ID + 1;
                    }

                    this.triangles.Add(new Triangle(id, frt_index, snd_index, trd_index, frt_index, snd_index, trd_index, frt_index, snd_index, trd_index, this.positions[frt_index], this.positions[snd_index], this.positions[trd_index]));

                    // second triangle
                    frt_index = (int)first_ellipse[j];
                    snd_index = (int)first_ellipse[0];
                    trd_index = (int)sec_ellipse[0];

                    // calculate normals
                    edge_1 = new Vector3(this.positions[snd_index] - this.positions[frt_index]);
                    edge_2 = new Vector3(this.positions[trd_index] - this.positions[frt_index]);

                    normalv1 = new Vector3(this.positions[frt_index].X, this.positions[frt_index].Y, 0);
                    normalv2 = new Vector3(this.positions[snd_index].X, this.positions[snd_index].Y, 0);
                    normalv3 = new Vector3(this.positions[trd_index].X, this.positions[trd_index].Y, 0);

                    normalv1.Normalize();
                    normalv2.Normalize();
                    normalv3.Normalize();

                    this.normals[frt_index] = normalv1;
                    this.normals[snd_index] = normalv2;
                    this.normals[trd_index] = normalv3;

                    id = this.triangles.Last().ID + 1;

                    this.triangles.Add(new Triangle(id, frt_index, snd_index, trd_index, frt_index, snd_index, trd_index, frt_index, snd_index, trd_index, this.positions[frt_index], this.positions[snd_index], this.positions[trd_index]));
                }
                else
                {
                    // first triangle
                    frt_index = (int)first_ellipse[j];
                    snd_index = (int)sec_ellipse[j + 1];
                    trd_index = (int)sec_ellipse[j];

                    // calculate normals
                    edge_1 = new Vector3(this.positions[snd_index] - this.positions[frt_index]);
                    edge_2 = new Vector3(this.positions[trd_index] - this.positions[frt_index]);

                    normalv1 = new Vector3(this.positions[frt_index].X, this.positions[frt_index].Y, 0);
                    normalv2 = new Vector3(this.positions[snd_index].X, this.positions[snd_index].Y, 0);
                    normalv3 = new Vector3(this.positions[trd_index].X, this.positions[trd_index].Y, 0);

                    normalv1.Normalize();
                    normalv2.Normalize();
                    normalv3.Normalize();

                    this.normals[frt_index] = normalv1;
                    this.normals[snd_index] = normalv2;
                    this.normals[trd_index] = normalv3;

                    int id = 0;

                    if (this.triangles.Count > 0)
                    {
                        id = this.triangles.Last().ID + 1;
                    }

                    this.triangles.Add(new Triangle(id, frt_index, snd_index, trd_index, frt_index, snd_index, trd_index, frt_index, snd_index, trd_index, this.positions[frt_index], this.positions[snd_index], this.positions[trd_index]));

                    // second triangle
                    frt_index = (int)first_ellipse[j];
                    snd_index = (int)first_ellipse[j + 1];
                    trd_index = (int)sec_ellipse[j + 1];

                    // calculate normals
                    edge_1 = new Vector3(this.positions[snd_index] - this.positions[frt_index]);
                    edge_2 = new Vector3(this.positions[trd_index] - this.positions[frt_index]);

                    normalv1 = new Vector3(this.positions[frt_index].X, this.positions[frt_index].Y, 0);
                    normalv2 = new Vector3(this.positions[snd_index].X, this.positions[snd_index].Y, 0);
                    normalv3 = new Vector3(this.positions[trd_index].X, this.positions[trd_index].Y, 0);

                    normalv1.Normalize();
                    normalv2.Normalize();
                    normalv3.Normalize();

                    this.normals[frt_index] = normalv1;
                    this.normals[snd_index] = normalv2;
                    this.normals[trd_index] = normalv3;

                    id = this.triangles.Last().ID + 1;

                    this.triangles.Add(new Triangle(id, frt_index, snd_index, trd_index, frt_index, snd_index, trd_index, frt_index, snd_index, trd_index, this.positions[frt_index], this.positions[snd_index], this.positions[trd_index]));
                }
            }
        }

        public override void Convert_Scalar_Attributes_To_Lists()
        {
            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                for (int i = 0; i < kvp.Value.Data_Unordered.Count; i++)
                {
                    for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
                    {
                        kvp.Value.Data_Ordered.Add(kvp.Value.Data_Unordered[i][j]);
                    }
                }
            }

            // normalization
            this.Normalize_Attribute_Lists();
        }

        private void Generate_SSBO_Inputs()
        {
            this.cylinder_pos = new List<float>();
            this.cylinderscal_vals = new List<float>();

            for (int i = 0; i < this.cylinder_postions.Count; i++)
            {
                this.cylinder_pos.Add(this.cylinder_postions[i].X);
                this.cylinder_pos.Add(this.cylinder_postions[i].Y);
            }

            float actval = 0;

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data) // current scalar field
            {
                for (int i = 0; i < kvp.Value.Data_Ordered.Count; i++)
                {
                    actval = kvp.Value.Data_Ordered[i];

                    this.cylinderscal_vals.Add(actval);
                }
            }
        }

        #endregion

        #region - Rendering -

        /// <summary>
        /// Proofs if the cylinder is ready to render
        /// </summary>
        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Initializes all used VBO's and SSBO's
        /// </summary>
        public override void SetupRender()
        {
            GL.GenVertexArrays(1, out this.vao[0]);
            GL.BindVertexArray(this.vao[0]);

            // vbo [0] = cylinder position
            GL.GenBuffers(this.vbo.Length, this.vbo);
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.CylinderPos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.positions.Count * Vector3.SizeInBytes), this.positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = vertex normal
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.CylinderNorm]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.normals.Count * Vector3.SizeInBytes), this.normals.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // triangle index buffer
            //this.index_buffer = this.Create_Index_Buffer(this.triangles);

            //GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
            //GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.index_buffer.Count * sizeof(uint)), this.index_buffer.ToArray(), BufferUsageHint.StaticDraw);

            GL.BindVertexArray(0);

            // Unbind VAO
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
            //GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

            //-----------------------------------------------------------------------------------------------------------------------------------------------------------

            // Generate SSBO's
            GL.GenBuffers(this.ssbo.Length, this.ssbo);

            // ssbo[0] = cylinder positions
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.MapPos]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.cylinder_pos.Count * sizeof(float)), this.cylinder_pos.ToArray(), BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // ssbo[1] = ellipsoid eigenvalues inner
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.ScalValues]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.cylinderscal_vals.Count * sizeof(float)), this.cylinderscal_vals.ToArray(), BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            this.Init_Setup = true;

            Console.WriteLine("-> Cylinder created");
        }

        /// <summary>
        /// Renders the mesh using triangles
        /// </summary>
        public override void Render()
        {
            if (!this.Renderable())
            {
                return;
            }
            this.shaderprog.EnableShader();
            {
                GL.BindVertexArray(vao[0]);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, 0, ssbo[(uint)SSBONames.MapPos]);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, 1, ssbo[(uint)SSBONames.ScalValues]);
                {
                    GL.DrawElementsInstanced(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, this.index_buffer.ToArray(), this.cylinder_postions.Count);
                }
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.MapPos, 0);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.ScalValues, 0);
                GL.BindVertexArray(0);
            }

            this.shaderprog.DisableShader();
        }

        #endregion

        #endregion
    }
}
