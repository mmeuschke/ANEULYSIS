﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuroAnalytics
{
    public class RenderCollection
    {
        #region - Private Variables -

        private Dictionary<string, RenderItem> render_objects_3D; // 3D objects that are no meshes
        private Dictionary<string, RenderItem> render_meshes_3D;
        private Dictionary<string, List<RenderItem>> render_stents_3D;
        //private Dictionary<string, RenderItem> render_maps_2D;
        private Dictionary<string, RenderItem> render_sampled_maps_2D;

        private Dictionary<string, VesselPlot> aneurysm_plots; 

        #endregion

        #region - Constructors -

        public RenderCollection()
        {
            this.render_objects_3D = new Dictionary<string, RenderItem>();

            this.render_meshes_3D = new Dictionary<string, RenderItem>();

            this.render_stents_3D = new Dictionary<string, List<RenderItem>>();

            //this.render_maps_2D = new Dictionary<string, RenderItem>();

            this.render_sampled_maps_2D = new Dictionary<string, RenderItem>();

            this.aneurysm_plots = new Dictionary<string, VesselPlot>();
        }

        #endregion

        #region - Properties -

        public Dictionary<string, RenderItem> Render_Objects_3D
        {
            get { return this.render_objects_3D; }
            set { this.render_objects_3D = value; }
        }

        public Dictionary<string, RenderItem> Render_Meshes_3D
        {
            get { return this.render_meshes_3D; }
            set { this.render_meshes_3D = value; }
        }

        public Dictionary<string, List<RenderItem>> Render_Stents_3D
        {
            get { return this.render_stents_3D; }
            set { this.render_stents_3D = value; }
        }

        //public Dictionary<string, RenderItem> Render_Maps_2D
        //{
        //    get { return this.render_maps_2D; }
        //    set { this.render_maps_2D = value; }
        //}

        public Dictionary<string, RenderItem> Render_Sampled_Maps_2D
        {
            get { return this.render_sampled_maps_2D; }
            set { this.render_sampled_maps_2D = value; }
        }

        public Dictionary<string, VesselPlot> Aneurysm_Plots
        {
            get { return this.aneurysm_plots; }
            set { this.aneurysm_plots = value; }
        }

        #endregion

        #region - Methods -

        #endregion
    }
}
