﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL;

namespace NeuroAnalytics
{
    public class Framebuffer
    {
        #region - Private Variables -

        private uint framebufferid;

        private uint framebufferimage;

        private int framebuffer_width = 64;
        private int framebuffer_height = 64;

        #endregion

        #region - Constructors -

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        /// <summary>
        /// Initializes the buffers for Framebuffer Rendering
        /// </summary>
        public void SetupFramebuffer()
        {
            GL.DeleteTextures(1, ref this.framebufferimage);

            GL.GenFramebuffers(1, out this.framebufferid);

            GL.BindFramebuffer(FramebufferTarget.Framebuffer, this.framebufferid);

            GL.GenTextures(1, out this.framebufferimage);

            GL.BindTexture(TextureTarget.Texture2D, this.framebufferimage);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba32f, this.framebuffer_width, this.framebuffer_height, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Rgba, PixelType.Float, IntPtr.Zero);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);

            GL.FramebufferTexture(FramebufferTarget.Framebuffer, FramebufferAttachment.ColorAttachment0, this.framebufferimage, 0);

            GL.BindImageTexture(0, this.framebufferimage, 0, true, 0, TextureAccess.ReadWrite, SizedInternalFormat.Rgba32f);

            GL.BindTexture(TextureTarget.Texture2DArray, 0);
        }

        /// <summary>
        /// Sets the size of the ABuffer
        /// </summary>
        public void SetFramebufferSize(int width, int height)
        {
            this.framebuffer_width = width;
            this.framebuffer_height = height;
        }

        public void BeginDrawing()
        {
            GL.BindFramebuffer(FramebufferTarget.DrawFramebuffer, this.framebufferid);
            GL.DrawBuffer(DrawBufferMode.ColorAttachment0);
            GL.PushAttrib(AttribMask.ViewportBit);

            GL.Viewport(0, 0, this.framebuffer_width, this.framebuffer_height);
        }

        public void EndDrawing()
        {
            GL.PopAttrib();
            GL.Ext.BindFramebuffer(FramebufferTarget.DrawFramebuffer, 0); // disable rendering into the FBO
        }

        /// <summary>
        /// Renders the ABuffer content in correct order
        /// </summary>
        public void RenderFramebufferContent()
        {
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();

            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadIdentity();

            // Draw Content of FBO
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            this.DrawToScreen(0,0);
        }

        public void DrawToScreen(float xoffset = 0, float yoffset = 0)
        {
            GL.BindTexture(TextureTarget.Texture2D, this.framebufferimage);

            GL.Begin(BeginMode.Quads);
            //todo : might also flip the texture since fbo's have right handed coordinate systems
            GL.TexCoord2(0.0, 0.0);
            GL.Vertex3(xoffset, yoffset, 0.0);

            GL.TexCoord2(0.0, 1.0);
            GL.Vertex3(xoffset, yoffset + this.framebuffer_width - 10, 0.0);

            GL.TexCoord2(1.0, 1.0);
            GL.Vertex3(xoffset + this.framebuffer_width, yoffset + this.framebuffer_height - 10, 0.0);

            GL.TexCoord2(1.0, 0.0);
            GL.Vertex3(xoffset + this.framebuffer_width - 10, yoffset, 0.0);

            GL.End();
        }

        #endregion
    }
}
