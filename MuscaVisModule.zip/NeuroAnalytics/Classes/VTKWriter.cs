﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using Kitware.VTK;

namespace NeuroAnalytics
{
    public class VTKWriter
    {
        #region - Private Variables -

        #endregion

        #region - Constructors -

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public bool Save_PolyData(string filename, List<Triangle> triangles, List<Vector3> vertices, RenderItem rend_item, int time_index)
        {
            if (filename.Length == 0)
            {
                return false;
            }

            string[] propertyNames = rend_item.Get_Attribute_Scalar_Names();
            int numProps = propertyNames.Length;

            string[] propertyVectorNames = rend_item.Get_Attribute_Vector_Names();
            int numVecProps = propertyVectorNames.Length;

            vtkPolyData vtk_polyData = new vtkPolyData();

            vtkPoints vtk_points = new vtkPoints();

            vtkCellArray vtk_cellarray = new vtkCellArray();

            // scalar properties
            vtkDoubleArray[] vtk_attributeArrayScalar = new vtkDoubleArray[numProps];

            // vectorproperties
            vtkDoubleArray[] vtk_attributeArrayVector = new vtkDoubleArray[numVecProps];

            // Transformation Matrix
            Matrix4 transformationMatrix = Matrix4.Identity;

            // Rotate
            transformationMatrix *= rend_item.TransformationMatrix;

            Vector4 vrtx_act = Vector4.Zero;
            Vector4 vrtx_trans = Vector4.Zero;

            for (int j = 0; j < vertices.Count; j++)
            {
                vrtx_act = new Vector4(vertices[j], 1.0f);

                // Perform Transformation
                Vector4.Transform(ref vrtx_act, ref transformationMatrix, out vrtx_trans);

                vtk_points.InsertNextPoint(vrtx_trans.X, vrtx_trans.Y, vrtx_trans.Z);
            }

            // write vertices and vertex attributes
            for (int i = 0; i < numProps; i++)
            {
                vtk_attributeArrayScalar[i] = new vtkDoubleArray();
                vtkDoubleArray vtk_current_attribute = vtk_attributeArrayScalar[i];
                vtk_current_attribute.SetName(propertyNames[i]);

                for (int j = 0; j < vertices.Count; j++)
                {
                    // insert vertex attributes
                    double current_attribute = rend_item.Get_Attribute_Scalar_Value(propertyNames[i], time_index, j);

                    vtk_current_attribute.InsertNextValue(current_attribute);
                }

                vtk_polyData.GetPointData().AddArray(vtk_current_attribute);
            }

            int pointIDCnt = 0;

            for (int i = 0; i < numVecProps; i++)
            {
                vtk_attributeArrayVector[i] = new vtkDoubleArray();
                vtkDoubleArray vtk_current_attribute = vtk_attributeArrayVector[i];
                vtk_current_attribute.SetNumberOfComponents(3);
                vtk_current_attribute.SetNumberOfTuples(vertices.Count);
                vtk_current_attribute.SetName(propertyVectorNames[i]);

                Vector3 act_vec = Vector3.Zero;

                for (int j = 0; j < vertices.Count; j++)
                {
                    act_vec = rend_item.Get_Attribute_Vector_Value(propertyVectorNames[i], time_index, j);

                    float[] dv = { act_vec.X, act_vec.Y, act_vec.Z };

                    vtk_current_attribute.SetTuple3((long)pointIDCnt, dv[0], dv[1], dv[2]);

                    pointIDCnt++;
                }

                pointIDCnt = 0;

                vtk_polyData.GetPointData().AddArray(vtk_current_attribute);
            }

            // write triangles
            for (int c = 0; c < triangles.Count; c++)
            {
                vtkIdList vtk_current_triangle_Ids = new vtkIdList();

                vtk_current_triangle_Ids.InsertNextId(triangles[c].VIndex_0);
                vtk_current_triangle_Ids.InsertNextId(triangles[c].VIndex_1);
                vtk_current_triangle_Ids.InsertNextId(triangles[c].VIndex_2);

                vtk_cellarray.InsertNextCell(vtk_current_triangle_Ids);
            }

            vtk_polyData.SetPoints(vtk_points);
            vtk_polyData.SetLines(vtk_cellarray);

            // add file ending if it is not existent
            string suffix = (".vtp");

            if (!(filename.EndsWith(suffix)))
            {
                filename += suffix;
            }

            // write data to file
            vtkXMLPolyDataWriter vtk_pdwriter = new vtkXMLPolyDataWriter();

            vtk_pdwriter.SetInput(vtk_polyData);
            vtk_pdwriter.SetFileName(filename);
            vtk_pdwriter.Update();

            vtk_pdwriter.SetDataModeToBinary();
            vtk_pdwriter.Write();

            return true;
        }

        #endregion
    }
}
