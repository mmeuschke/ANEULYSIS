﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using NeuroAnalytics.Properties;

namespace NeuroAnalytics
{
    public abstract class RenderItem : IDisposable
    {
        #region - Private Variables -

        protected Matrix4 transformationMatrix;

        // object identification
        protected string name;

        private bool init_setup;
        private bool init_shader;

        // object attributes
        protected List<Vector3> positions;
        protected List<Vector3> normals;
        protected Dictionary<string, Unsteady_Datafield<float>> scalar_data;
        protected Dictionary<string, Unsteady_Datafield<Vector3>> vector_data;

        // center
        protected float meanx;
        protected float meany;
        protected float meanz;

        // eigenvalues of the sourrounding ellipsoid
        protected Vector3 eigenvalues;
        protected Vector3 e1;
        protected Vector3 e2;
        protected Vector3 e3;

        protected Shader shaderprog;

        protected uint[] vao;
        protected uint[] vbo;
        protected uint[] ssbo;

        protected bool hide_rendering;

        #endregion

        #region - Constructors -

        public RenderItem(string name = "none")
        {
            this.transformationMatrix = Matrix4.Identity;

            this.name = name;

            this.init_setup = false;
            this.init_shader = false;

            this.positions = new List<Vector3>();
            this.normals = new List<Vector3>();
            this.scalar_data = new Dictionary<string, Unsteady_Datafield<float>>();
            this.vector_data = new Dictionary<string, Unsteady_Datafield<Vector3>>();
            this.hide_rendering = false;

            this.meanx = 0.0f;
            this.meany = 0.0f;
            this.meanz = 0.0f;

            this.eigenvalues = Vector3.Zero;
            this.e1 = Vector3.Zero;
            this.e2 = Vector3.Zero;
            this.e3 = Vector3.Zero;
        }

        #endregion

        #region - Properties -

        public string Name
        {
            get { return this.name; }
            set { this.name = value; }
        }

        public Matrix4 TransformationMatrix
        {
            get { return this.transformationMatrix; }
            set { this.transformationMatrix = value; }
        }

        public List<Vector3> Positions
        {
            get { return this.positions; }
            set { this.positions = value; }
        }

        public List<Vector3> Normals
        {
            get { return this.normals; }
            set { this.normals = value; }
        }

        public Dictionary<string, Unsteady_Datafield<float>> Scalar_Data
        {
            get { return this.scalar_data; }
            set { this.scalar_data = value; }
        }

        public Dictionary<string, Unsteady_Datafield<Vector3>> Vector_Data
        {
            get { return this.vector_data; }
            set { this.vector_data = value; }
        }

        public Vector3 FirstEigVec
        {
            get { return this.e1; }
            set { this.e1 = value; }
        }

        public Vector3 SndEigVec
        {
            get { return this.e2; }
            set { this.e2 = value; }
        }

        public Vector3 ThirdEigVec
        {
            get { return this.e3; }
            set { this.e3 = value; }
        }

        public virtual Shader ShaderProg
        {
            get { return this.shaderprog; }
            set { this.shaderprog = value; }
        }

        public bool IsRenderable
        {
            get { return this.Renderable(); }
        }

        public bool Init_Setup
        {
            get { return this.init_setup; }
            set { this.init_setup = value; }
        }

        public bool Init_Shader
        {
            get { return this.init_shader; }
            set { this.init_shader = value; }
        }

        public bool Hide_Render
        {
            get { return this.hide_rendering; }
            set { this.hide_rendering = value; }
        }

        #endregion

        #region - Methods -

        #region - Rendering -

        /// <summary>
        /// Proofs if a render object is ready to render
        /// </summary>
        public abstract bool Renderable();

        /// <summary>
        /// Initializes all used VBO's
        /// </summary>
        public abstract void SetupRender();

        /// <summary>
        /// Renders the object
        /// </summary>
        public abstract void Render();

        /// <summary>
        /// Create the index buffer for correct rendering order
        /// </summary>
        public virtual List<uint> Create_Index_Buffer(List<Triangle> triangles)
        {
            List<uint> index_buffer = new List<uint>();

            foreach (Triangle tri in triangles)
            {
                index_buffer.Add((uint)tri.VIndex_0);
                index_buffer.Add((uint)tri.VIndex_1);
                index_buffer.Add((uint)tri.VIndex_2);
            }

            return index_buffer;
        }

        /// <summary>
        /// Create the element buffer with indices for correct rendering order
        /// </summary>
        public virtual List<uint> Create_Index_Buffer()
        {
            List<uint> lines_buffer = new List<uint>();

            for (uint i = 0; i < this.positions.Count; i++)
            {
                lines_buffer.Add(i);
            }

            lines_buffer.Add(0);

            return lines_buffer;
        }

        /// <summary>
        /// Initialize item for rendering
        /// </summary>
        public void Initialize_Render_Item()
        {
            if (this != null)
            {
                if (!this.init_shader)
                {
                    this.ShaderProg = new Shader(this.GetShadersfromXML());

                    this.init_shader = true;
                }

                if (this.Renderable())
                {
                    this.Clear_Rendering_Members();
                }

                if (!this.init_setup)
                {
                    this.SetupRender();
                }
            }
        }

        public virtual void Update_Render_Item_Shaders()
        {
            if (this != null)
            {
                this.ShaderProg = new Shader(this.GetShadersfromXML());

                this.Update_Items_Shader_Variables();
            }
        }

        /// <summary>
        /// Update content of render item after scalar field data for rendering has been changed
        /// </summary>
        public void Update_Render_Item()
        {
            if (this != null)
            {
                if (this.Renderable())
                {
                    this.Clear_Rendering_Members();
                }

                this.SetupRender();
            }
        }

        public virtual void Update_Items_Shader_Variables()
        { }

        public virtual void Update_Child_Render_Objects()
        { }

        /// <summary>
        /// Reads names of shader files used for current render item from a XML-file
        /// </summary>
        public virtual List<string> GetShadersfromXML()
        {
            List<string> shaderpathes = new List<string>();

            string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + this.name + @"\";

            XmlDocument doc = new XmlDocument();

            doc.Load(Utility.Get_Relative_Project_Path() + Settings.Default.InitXMLPath + this.name + ".xml");

            XmlNode filesNode = doc.SelectSingleNode("/" + this.name + "/Shaderfiles");

            if (filesNode.HasChildNodes)
            {
                for (int i = 0; i < filesNode.ChildNodes.Count; i++)
                {
                    shaderpathes.Add(Path.Combine(shaderpath, filesNode.ChildNodes[i].Attributes["Name"].Value));
                }
            }

            return shaderpathes;
        }

        #endregion

        #region - Data Processing -

        /// <summary>
        /// Centers object around a given center point
        /// </summary>
        public virtual List<Vector3> Center_RenderItem(List<Vector3> points, Vector3 center)
        {
            List<Vector3> newpoints = new List<Vector3>();

            Vector3 newpoint = Vector3.Zero;

            foreach (Vector3 point in points)
            {
                newpoint.X = point.X - center.X;
                newpoint.Y = point.Y - center.Y;
                newpoint.Z = point.Z - center.Z;

                newpoints.Add(newpoint);
            }

            return newpoints;
        }

        public virtual List<Vector2> Center_RenderItem(List<Vector2> points, Vector2 center)
        {
            List<Vector2> newpoints = new List<Vector2>();

            Vector2 newpoint = Vector2.Zero;

            foreach (Vector2 point in points)
            {
                newpoint.X = point.X - center.X;
                newpoint.Y = point.Y - center.Y;

                newpoints.Add(newpoint);
            }

            return newpoints;
        }

        /// <summary>
        /// Calculates a center point from a given list of positions
        /// </summary>
        public virtual Vector3 Calculate_Center(List<Vector3> points)
        {
            Vector3 center;

            this.meanx = 0;
            this.meany = 0;
            this.meanz = 0;

            foreach (Vector3 point in points)
            {
                this.meanx = this.meanx + point.X;
                this.meany = this.meany + point.Y;
                this.meanz = this.meanz + point.Z;
            }

            this.meanx = this.meanx / points.Count;
            this.meany = this.meany / points.Count;
            this.meanz = this.meanz / points.Count;

            center = new Vector3(this.meanx, this.meany, this.meanz);

            return center;
        }

        public virtual Vector2 Calculate_Center(List<Vector2> points)
        {
            Vector2 center;

            this.meanx = 0;
            this.meany = 0;

            foreach (Vector2 point in points)
            {
                this.meanx = this.meanx + (float)point.X;
                this.meany = this.meany + (float)point.Y;
            }

            this.meanx = this.meanx / points.Count;
            this.meany = this.meany / points.Count;

            center = new Vector2(this.meanx, this.meany);

            return center;
        }

        public virtual void Integrate_Scalarfield(string name, List<List<float>> values)
        {
            if (this.scalar_data == null)
            {
                return;
            }

            if (this.scalar_data.ContainsKey(name))
            {
                this.scalar_data[name].Data_Unordered = values;
            }
            else
            {
                this.scalar_data.Add(name, new Unsteady_Datafield<float>(values));
            }
        }

        public virtual void Integrate_Vectorfeld(string name, List<List<Vector3>> values)
        {
            if (this.vector_data == null)
            {
                return;
            }

            if (this.vector_data.ContainsKey(name))
            {
                this.vector_data[name].Data_Unordered = values;
            }
            else
            {
                this.vector_data.Add(name, new Unsteady_Datafield<Vector3>(values));
            }
        }

        public virtual void Convert_Scalar_Attributes_To_Lists()
        {
            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                float avg_val = 0;
                float counter = 0;

                if ( kvp.Value.Data_Ordered.Count > 0)
                {
                    kvp.Value.Data_Ordered.Clear();
                }

                for (int i = 0; i < kvp.Value.Data_Unordered.Count; i++)
                {
                    for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
                    {
                        kvp.Value.Data_Ordered.Add(kvp.Value.Data_Unordered[i][j]);

                        avg_val += kvp.Value.Data_Unordered[i][j];
                        counter++;
                    }
                }

                kvp.Value.Min_Value = Utility.norm_values[kvp.Key].X;
                kvp.Value.Max_Value = Utility.norm_values[kvp.Key].Y;
                kvp.Value.Avg_Value = avg_val / counter;
            }

            // normalization
            this.Normalize_Attribute_Lists();
        }

        public virtual List<float> Convert_Scalar_Attributes_To_One_List()
        {
            List<float> values = new List<float>();

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                if (kvp.Value.Data_Unordered.Count > 0 && kvp.Value.Data_Ordered.Count < 1)
                {
                    this.Convert_Single_Scalar_Attribute_To_List(kvp.Key, kvp.Value);
                }

                for (int i = 0; i < kvp.Value.Data_Ordered.Count; i++)
                {
                    values.Add(kvp.Value.Data_Ordered[i]);
                }
            }

            return values;
        }

        public virtual void Convert_Single_Scalar_Attribute_To_List(string name)
        {
            if (!this.scalar_data.ContainsKey(name))
            {
                return;
            }

            float avg_val = 0;
            float counter = 0;

            for (int i = 0; i < this.scalar_data[name].Data_Unordered.Count; i++)
            {
                for (int j = 0; j < this.scalar_data[name].Data_Unordered[i].Count; j++)
                {
                    this.scalar_data[name].Data_Ordered.Add(this.scalar_data[name].Data_Unordered[i][j]);

                    avg_val += this.scalar_data[name].Data_Unordered[i][j];
                    counter++;
                }
            }

            this.scalar_data[name].Min_Value = Utility.norm_values[name].X;
            this.scalar_data[name].Max_Value = Utility.norm_values[name].X;
            this.scalar_data[name].Avg_Value = avg_val / counter;

            // normalization
            this.Normalize_Attribute(this.scalar_data[name].Data_Ordered, this.scalar_data[name].Min_Value, this.scalar_data[name].Max_Value);
        }

        public virtual void Convert_Single_Scalar_Attribute_To_List(string key, Unsteady_Datafield<float> field)
        {
            float avg_val = 0;
            float counter = 0;

            if (field.Data_Ordered.Count > 0)
            {
                field.Data_Ordered.Clear();
            }

            for (int i = 0; i < field.Data_Unordered.Count; i++)
            {
                for (int j = 0; j < field.Data_Unordered[i].Count; j++)
                {
                    field.Data_Ordered.Add(field.Data_Unordered[i][j]);

                    avg_val += field.Data_Unordered[i][j];
                    counter++;
                }
            }

            field.Max_Value = Utility.norm_values[key].X;
            field.Max_Value = Utility.norm_values[key].Y;
            field.Avg_Value = avg_val / counter;

            // normalization
            this.Normalize_Attribute(field.Data_Ordered, field.Min_Value, field.Max_Value);
        }

        public virtual void Normalize_Attribute_Lists()
        {
            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                if (Utility.norm_values.ContainsKey(kvp.Key))
                {
                    Vector2 norm_data = Utility.norm_values[kvp.Key];

                    kvp.Value.Min_Value = norm_data.X;

                    kvp.Value.Max_Value = norm_data.Y;

                    this.Normalize_Attribute(kvp.Value.Data_Ordered, norm_data.X, norm_data.Y);
                }
            }
        }

        public virtual void Normalize_Attribute(List<float> values, float min, float max)
        {
            float range = max - min;

            if (!(range > float.Epsilon))
            {
                range = 1;
            }

            for (int i = 0; i < values.Count; i++)
            {
                if (values[i] == float.MinValue)
                {
                    values[i] = 0;
                }
                else
                {
                    values[i] = (values[i] - min) / range;
                }
            }
        }

        public virtual void Convert_Vector_Attributes_To_Lists()
        {
            foreach (KeyValuePair<string, Unsteady_Datafield<Vector3>> kvp in this.vector_data)
            {
                for (int i = 0; i < kvp.Value.Data_Unordered.Count; i++)
                {
                    for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
                    {
                        kvp.Value.Data_Ordered.Add(kvp.Value.Data_Unordered[i][j].X);
                        kvp.Value.Data_Ordered.Add(kvp.Value.Data_Unordered[i][j].Y);
                        kvp.Value.Data_Ordered.Add(kvp.Value.Data_Unordered[i][j].Z);
                    }
                }
            }
        }

        public virtual void Convert_Single_Vector_Attribute_To_Lists(string name)
        {
            if (!this.vector_data.ContainsKey(name))
            {
                return;
            }

            for (int i = 0; i < this.vector_data[name].Data_Unordered.Count; i++)
            {
                for (int j = 0; j < this.vector_data[name].Data_Unordered[i].Count; j++)
                {
                    this.vector_data[name].Data_Ordered.Add(this.vector_data[name].Data_Unordered[i][j].X);
                    this.vector_data[name].Data_Ordered.Add(this.vector_data[name].Data_Unordered[i][j].Y);
                    this.vector_data[name].Data_Ordered.Add(this.vector_data[name].Data_Unordered[i][j].Z);
                }
            }
        }

        public virtual void Clear_Brushing()
        {

        }

        public virtual void Calculate_Scalar_Histograms()
        {

        }

        public virtual void Get_Min_Max_Hist_Val()
        {

        }

        public virtual void Normalize_Histogram_Values()
        {

        }

        public virtual void Sample_Map()
        {
        }

        #endregion

        #region - Data Requests -

        /// <summary>
        /// Return names of all scalar fields
        /// </summary>
        public virtual string[] Get_Attribute_Scalar_Names()
        {
            Dictionary<string, Unsteady_Datafield<float>>.KeyCollection keyColl = this.scalar_data.Keys;

            string[] names = keyColl.ToArray();

            return names;
        }

        /// <summary>
        /// Return names of all vectorial data fields
        /// </summary>
        public virtual string[] Get_Attribute_Vector_Names()
        {
            Dictionary<string, Unsteady_Datafield<Vector3>>.KeyCollection keyColl = this.vector_data.Keys;

            string[] names = keyColl.ToArray();

            return names;
        }

        /// <summary>
        /// Return the value for a specific attribute
        /// </summary>
        public virtual float Get_Attribute_Scalar_Value(string attributeName, int time_index, int vertex_index)
        {
            Unsteady_Datafield<float> scalar_val = new Unsteady_Datafield<float>();

            bool is_scalar = this.scalar_data.TryGetValue(attributeName, out scalar_val);

            if (is_scalar)
            {
                return scalar_val.Data_Unordered[time_index][vertex_index];
            }
            else
            {
                return 0;
            }
        }

        public virtual Vector3 Get_Attribute_Vector_Value(string attributeName, int time_index, int vertex_index)
        {
            Unsteady_Datafield<Vector3> vector_val = new Unsteady_Datafield<Vector3>();

            bool is_vector = this.vector_data.TryGetValue(attributeName, out vector_val);

            if (is_vector)
            {
                return vector_val.Data_Unordered[time_index][vertex_index];
            }
            else
            {
                return Vector3.Zero;
            }
        }

        public virtual Vector3 Get_Local_Scalar_Attributes(string attributename_scal1, string attributename_scal2, string attributename_scal3, int index, int time)
        {
            Vector3 vec = Vector3.Zero;

            try
            {
                vec.X = this.scalar_data[attributename_scal1].Data_Unordered[time][index];
                vec.Y = this.scalar_data[attributename_scal2].Data_Unordered[time][index];
                vec.Z = this.scalar_data[attributename_scal3].Data_Unordered[time][index];
            }
            catch (Exception)
            {
                vec = Vector3.Zero;
            }

            return vec;
        }

        public virtual Vector3 Get_Local_Vector_Attribute(string attributename_vec, int index, int time)
        {
            Vector3 vec = Vector3.Zero;

            try
            {
                vec = this.vector_data[attributename_vec].Data_Unordered[time][index];
            }
            catch (Exception)
            {
                vec = Vector3.Zero;
            }

            return vec;
        }

        #endregion

        #region - Interaction -

        public virtual int Calculate_Picked_Triangle(Vector3 P, Vector3 d, out Vector3 hit_point, out Vector3 hit_normal)
        {
            hit_point = Vector3.Zero;
            hit_normal = Vector3.Zero;

            return 0;
        }

        #endregion

        #region - Data Export -

        public virtual void Export_to_VTP(string path)
        {
            Console.WriteLine("Export renderitem");
        }

        public virtual void Export_to_OBJ(string path)
        {
            Console.WriteLine("Export renderitem");
        }

        #endregion

        #region - Clear -

        public virtual void Dispose()
        {
            if (this.vbo != null)
            {
                GL.DeleteBuffers(this.vbo.Length, this.vbo);
            }

            if (this.ssbo != null)
            {
                GL.DeleteBuffers(this.ssbo.Length, this.ssbo);
            }

            if (this.vao != null)
            {
                for (int i = 0; i < this.vao.Length; i++)
                {
                    GL.DeleteVertexArray(this.vao[i]);
                }
            }

            this.vao = null;

            this.shaderprog = null;

            this.transformationMatrix = Matrix4.Identity;

            this.name = "none";

            this.init_setup = false;
            this.init_shader = false;

            this.positions = null;

            this.normals = null;

            this.scalar_data = null;

            this.vector_data = null;

            this.hide_rendering = false;

            Console.WriteLine("-> Render Item:\t\tdisposed");
        }

        /// <summary>
        /// Clear buffer objects for redraw
        /// </summary>
        public virtual void Clear_Rendering_Members()
        {
            if (this.vbo != null)
            {
                GL.DeleteBuffers(this.vbo.Length, this.vbo);
            }

            if (this.ssbo != null)
            {
                GL.DeleteBuffers(this.ssbo.Length, this.ssbo);
            }

            if (this.vao != null)
            {
                for (int i = 0; i < this.vao.Length; i++)
                {
                    GL.DeleteVertexArray(this.vao[i]);
                }
            }
        }

        #endregion

        #endregion
    }
}
