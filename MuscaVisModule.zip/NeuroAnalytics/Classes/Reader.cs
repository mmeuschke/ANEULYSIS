﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using NeuroAnalytics.Properties;

namespace NeuroAnalytics
{
    public abstract class Reader : IDisposable
    {
        #region - Private Variables -

        protected string name;

        protected List<Vector3> positions;
        protected List<Vector3> normals;

        protected List<List<uint>> lines;
        protected List<Triangle> triangles;

        protected Dictionary<string, Unsteady_Datafield<float>> scalar_data;
        protected Dictionary<string, Unsteady_Datafield<Vector3>> vector_data;

        protected List<int> line_indices;

        #endregion

        #region - Constructors -

        public Reader(string name = "none")
        {
            this.name = name;

            this.positions = new List<Vector3>();
            this.normals = new List<Vector3>();

            this.lines = new List<List<uint>>();

            this.triangles = new List<Triangle>();

            this.scalar_data = new Dictionary<string, Unsteady_Datafield<float>>();
            this.vector_data = new Dictionary<string, Unsteady_Datafield<Vector3>>();

            this.line_indices = new List<int>();

            Console.WriteLine("-> Reader:\t\tReader Created");
        }

        #endregion

        #region - Properties -

        public List<Vector3> Positions
        {
            get { return this.positions; }
            set { this.positions = value; }
        }

        public List<Vector3> Normals
        {
            get { return this.normals; }
            set { this.normals = value; }
        }

        public List<List<uint>> Lines
        {
            get { return this.lines; }
            set { this.lines = value; }
        }

        public List<Triangle> Triangles
        {
            get { return this.triangles; }
            set { this.triangles = value; }
        }

        public Dictionary<string, Unsteady_Datafield<float>> Scalar_Data
        {
            get { return this.scalar_data; }
            set { this.scalar_data = value; }
        }

        public Dictionary<string, Unsteady_Datafield<Vector3>> Vector_Data
        {
            get { return this.vector_data; }
            set { this.vector_data = value; }
        }

        public List<int> Line_Indices
        {
            get { return this.line_indices; }
            set { this.line_indices = value; }
        }

        #endregion

        #region - Methods -

        public abstract bool Load(string filename, bool first_timestep);

        public virtual bool Load(string filename, bool first_timestep, int timesteps, int act_timestep)
        {
            return true;
        }

        public virtual void Calculate_Triangle_Normals_per_Vertex(bool first_timestep)
        {
            if (!first_timestep)
            {
                return;
            }

            Vector3 edge_1 = Vector3.Zero;
            Vector3 edge_2 = Vector3.Zero;

            Vector4 normal = Vector4.Zero;

            List<Vector4> vertex_normals = new List<Vector4>();

            for (int i = 0; i < this.positions.Count; i++)
            {
                vertex_normals.Add(Vector4.Zero);
            }

            float tri_area = 0;

            foreach (Triangle tri in this.Triangles)
            {
                edge_1 = (this.positions[tri.VIndex_1] - this.positions[tri.VIndex_0]);
                edge_2 = (this.positions[tri.VIndex_2] - this.positions[tri.VIndex_0]);

                normal.Xyz = Vector3.Cross(edge_1, edge_2);

                tri_area = normal.Xyz.Length;

                normal.W = tri_area;

                vertex_normals[tri.VIndex_0] += normal;
                vertex_normals[tri.VIndex_1] += normal;
                vertex_normals[tri.VIndex_2] += normal;
            }

            Vector4 new_norm;

            for (int j = 0; j < vertex_normals.Count; j++)
            {
                if (vertex_normals[j].W > 0)
                {
                    new_norm = new Vector4((vertex_normals[j].Xyz / vertex_normals[j].W), 1);
                }
                else
                {
                    new_norm = new Vector4(vertex_normals[j].Xyz, 1);
                }


                if (new_norm.Xyz != Vector3.Zero)
                {
                    this.normals.Add(new Vector3(new_norm.Xyz.Normalized()));
                }
                else
                {
                    this.normals.Add(new Vector3(new_norm.Xyz));
                }
            }
        }

        public void Add_Artificial_Time_Points()
        {
            if (this.lines == null || this.lines.Count == 0 || Utility.Num_Timesteps < 2)
            {
                return;
            }

            float act_time = 0;

            float time_span = 0;

            try
            {
                if (this.scalar_data.ContainsKey(Settings.Default.SFTimeName))
                {
                    this.scalar_data[Settings.Default.SFTimeName].Data_Unordered.Clear();
                }
            }
            catch (Exception)
            {
            }

            List<float> time_val = new List<float>();

            foreach (List<uint> line in this.lines)
            {
                time_span = (float)(Utility.Num_Timesteps - 1) / (float)(line.Count - 1);

                for (int i = 0; i < line.Count; i++)
                {
                    act_time = i * time_span;

                    time_val.Add(act_time);
                }
            }

            if (this.scalar_data.ContainsKey(Settings.Default.SFTimeName))
            {
                this.scalar_data[Settings.Default.SFTimeName].Data_Unordered.Add(time_val);
            }
            else
            {
                this.scalar_data.Add(Settings.Default.SFTimeName, new Unsteady_Datafield<float>(time_val));
            }
        }

        public virtual void Dispose()
        {
            this.positions = null;
            this.normals = null;
            this.lines = null;
            this.triangles = null;

            this.scalar_data = null;
            this.vector_data = null;

            this.line_indices = null;
        }

        #endregion
    }
}
