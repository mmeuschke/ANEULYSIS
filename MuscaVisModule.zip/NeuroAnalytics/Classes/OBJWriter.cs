﻿using OpenTK;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuroAnalytics
{
    public class OBJWriter : Writer
    {
        #region - Private Variables -

        #endregion

        #region - Constructors -

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public override void Write_Mesh(string path, List<Triangle> faces, List<Vector3> positions, RenderItem rend_item)
        {
            // Transformation Matrix
            Matrix4 transformationMatrix = Matrix4.Identity;

            //  Rotate
            transformationMatrix *= rend_item.TransformationMatrix;

            Vector4 vrtx_act = Vector4.Zero;
            Vector4 vrtx_trans = Vector4.Zero;

            using (StreamWriter sw = File.CreateText(path))
            {
                //foreach (Vector3 vert in vert_positions)
                foreach (Vector3 vert in positions)
                {
                    vrtx_act = new Vector4(vert, 1.0f);

                    // Perform Transformation
                    Vector4.Transform(ref vrtx_act, ref transformationMatrix, out vrtx_trans);

                    sw.WriteLine("v " + vrtx_trans.X.ToString(CultureInfo.InvariantCulture) + " " + vrtx_trans.Y.ToString(CultureInfo.InvariantCulture) + " " + vrtx_trans.Z.ToString(CultureInfo.InvariantCulture));
                }

                sw.Flush();

                sw.Close();
            }

            using (StreamWriter sw = File.AppendText(path))
            {
                for (int i = 0; i < faces.Count; i++)
                {
                    sw.WriteLine("f " + (faces[i].VIndex_0 + 1) + " " + (faces[i].VIndex_1 + 1) + " " + (faces[i].VIndex_2 + 1));
                }

                sw.Flush();

                sw.Close();
            }
        }

        public override void Write_Lines(string path, string filename, List<List<uint>> lines_indices, List<Vector3> positions, List<float> scalar_vertex_value, RenderItem rend_item)
        {
            int vertices_number = 0;

            // Get number of vertices
            foreach (List<uint> line in lines_indices)
            {
                foreach (uint index in line)
                {
                    if (index > vertices_number)
                    {
                        vertices_number = (int)index;
                    }
                }
            }

            vertices_number = vertices_number + 1;

            // Initialize original vertex positions and scalar values
            List<Vector3> vert_positions = new List<Vector3>();
            List<float> vert_value = new List<float>();

            vert_positions.Capacity = vertices_number;
            vert_value.Capacity = vertices_number;

            for (int i = 0; i < vertices_number; i++)
            {
                vert_positions.Add(new Vector3(float.MaxValue));
                vert_value.Add(float.MaxValue);
            }

            // Transformation Matrix
            Matrix4 transformationMatrix = Matrix4.Identity;

            // Rotate
            transformationMatrix *= rend_item.TransformationMatrix;

            Vector4 vrtx_act = Vector4.Zero;
            Vector4 vrtx_trans = Vector4.Zero;

            for (int i = 0; i < lines_indices.Count; i++)
            {
                for (int j = 0; j < lines_indices[i].Count; j++)
                {
                    int current_index = (int)lines_indices[i][j];

                    if (vert_positions[current_index].X == float.MaxValue)
                    {
                        vrtx_act = new Vector4(positions[(int)lines_indices[i][j]], 1.0f);

                        // Perform Transformation
                        Vector4.Transform(ref vrtx_act, ref transformationMatrix, out vrtx_trans);

                        vert_positions[(int)lines_indices[i][j]] = vrtx_trans.Xyz;
                        vert_value[(int)lines_indices[i][j]] = scalar_vertex_value[(int)lines_indices[i][j]];
                    }
                }
            }

            // write all information to an obj file
            path = path + @"Pathlines_New\" + filename + ".obj";

            using (StreamWriter sw = File.CreateText(path))
            {
                foreach (Vector3d vert in vert_positions)
                {
                    sw.WriteLine("v " + vert.X.ToString(CultureInfo.InvariantCulture) + " " + vert.Y.ToString(CultureInfo.InvariantCulture) + " " + vert.Z.ToString(CultureInfo.InvariantCulture));
                }

                sw.Flush();

                sw.Close();
            }

            using (StreamWriter sw = File.AppendText(path))
            {
                foreach (float scalar_value in vert_value)
                {
                    sw.WriteLine("st " + scalar_value.ToString(CultureInfo.InvariantCulture));
                }

                foreach (List<uint> line in lines_indices)
                {
                    string new_line = "l ";

                    for (int i = 0; i < line.Count; i++)
                    {
                        new_line = new_line + (line[i] + 1) + " ";
                    }

                    sw.WriteLine(new_line);
                }

                sw.Flush();

                sw.Close();
            }
        }

        public void Write_TestLines(string path, string filename, List<List<uint>> lines_indices, List<Vector3> positions, List<float> scalar_vertex_value)
        {
            int vertices_number = 0;

            // Get number of vertices
            foreach (List<uint> line in lines_indices)
            {
                foreach (uint index in line)
                {
                    if (index > vertices_number)
                    {
                        vertices_number = (int)index;
                    }
                }
            }

            vertices_number = vertices_number + 1;

            // Initialize original vertex positions and scalar values
            List<Vector3> vert_positions = new List<Vector3>();
            List<float> vert_value = new List<float>();

            vert_positions.Capacity = vertices_number;
            vert_value.Capacity = vertices_number;

            for (int i = 0; i < vertices_number; i++)
            {
                vert_positions.Add(new Vector3(float.MaxValue));
                vert_value.Add(float.MaxValue);
            }

            // write each vertex position and scalar value ones

            // Transformation Matrix
            Matrix4 transformationMatrix = Matrix4.Identity;

            Vector4 vrtx_act = Vector4.Zero;
            Vector4 vrtx_trans = Vector4.Zero;

            for (int i = 0; i < lines_indices.Count; i++)
            {
                for (int j = 0; j < lines_indices[i].Count; j++)
                {
                    int current_index = (int)lines_indices[i][j];

                    if (vert_positions[current_index].X == float.MaxValue)
                    {
                        vrtx_act = new Vector4(positions[(int)lines_indices[i][j]], 1.0f);

                        // Perform Transformation
                        Vector4.Transform(ref vrtx_act, ref transformationMatrix, out vrtx_trans);

                        vert_positions[(int)lines_indices[i][j]] = vrtx_trans.Xyz;
                        vert_value[(int)lines_indices[i][j]] = scalar_vertex_value[(int)lines_indices[i][j]];
                    }
                }
            }

            // write all information to an obj file
            path = path + filename;

            using (StreamWriter sw = File.CreateText(path))
            {
                foreach (Vector3 vert in vert_positions)
                {
                    sw.WriteLine("v " + vert.X.ToString(CultureInfo.InvariantCulture) + " " + vert.Y.ToString(CultureInfo.InvariantCulture) + " " + vert.Z.ToString(CultureInfo.InvariantCulture));
                }

                sw.Flush();

                sw.Close();
            }

            using (StreamWriter sw = File.AppendText(path))
            {
                foreach (float scalar_value in vert_value)
                {
                    sw.WriteLine("st " + scalar_value.ToString(CultureInfo.InvariantCulture));
                }

                foreach (List<uint> line in lines_indices)
                {
                    string new_line = "l ";

                    for (int i = 0; i < line.Count; i++)
                    {
                        new_line = new_line + (line[i] + 1) + " ";
                    }

                    sw.WriteLine(new_line);
                }

                sw.Flush();

                sw.Close();
            }
        }

        #endregion
    }
}
