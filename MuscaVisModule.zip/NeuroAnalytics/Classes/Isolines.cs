﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NeuroAnalytics.Properties;
using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace NeuroAnalytics
{
    public class Isolines :RenderItem
    {
        #region - Private Variables -

        private List<Triangle> triangles;

        private uint[] isoline_data;

        private List<uint> index_buffer;

        // VBO Initialization
        private enum VBONames { Pos, Norm, IndexBuffer };

        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        // SSBO Initialization
        private enum SSBONames { Isolinedata };

        private int number_ssbo = Enum.GetNames(typeof(SSBONames)).Length; 

        #endregion

        #region - Constructors -

         public Isolines(List<Triangle> Topology, List<Vector3> Positions,  List<Vector3> Normals, uint[] Isoline_Data)
            : base(Settings.Default.IsolinesName)
        {
            this.triangles = Topology;
            this.positions = Positions;
            this.normals = Normals;
            this.isoline_data = Isoline_Data;

            this.vao = new uint[1];

            this.vbo = new uint[this.number_vbo];

            this.index_buffer = new List<uint>();
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            return true;
        }

        public override void SetupRender()
        {
            this.shaderprog.Item_Point_Number = this.positions.Count;

            GL.GenVertexArrays(1, out this.vao[0]);
            GL.BindVertexArray(this.vao[0]);

            // Generate VBO's
            GL.GenBuffers(this.vbo.Length, this.vbo);

            // vbo [0] = vertex position
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Pos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.positions.Count * Vector3.SizeInBytes), this.positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = vertex normal 
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Norm]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.normals.Count * Vector3.SizeInBytes), this.normals.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo[3] = triangle index buffer
            this.index_buffer = this.Create_Index_Buffer(this.triangles);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.index_buffer.Count * sizeof(uint)), this.index_buffer.ToArray(), BufferUsageHint.StaticDraw);

            GL.BindVertexArray(0);

            // Unbind VAO
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

            //-----------------------------------------------------------------------------------------------------------------------------------------------------------

            // Generate SSBO's
            GL.GenBuffers(this.ssbo.Length, this.ssbo);

            // ssbo[0] = vertex deformation
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.Isolinedata]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.isoline_data.Length * sizeof(uint)), this.isoline_data, BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            this.Init_Setup = true;

            Console.WriteLine("-> Isolines created");
        }

        public override void Render()
        {
            if (!this.Renderable())
            {
                return;
            }

            this.shaderprog.EnableShader();
            {
                GL.BindVertexArray(vao[0]);

                GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.Isolinedata, ssbo[(uint)SSBONames.Isolinedata]);
                {
                    GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
                }
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.Isolinedata, 0);
                GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

                GL.BindVertexArray(0);
            }

            this.shaderprog.DisableShader();
        }

        #endregion

        #region IDisposable Member

        public override void Dispose()
        {
            base.Dispose();

            this.triangles = null;

            this.isoline_data = null;

            this.index_buffer = null;
        }

        #endregion
        
    }
}
