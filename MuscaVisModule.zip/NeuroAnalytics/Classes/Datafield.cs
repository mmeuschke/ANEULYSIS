﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuroAnalytics
{
    public abstract class Datafield<T>
    {
        #region - Private Variables -

        protected List<float> data_ordered; // data in correct order for rendering

        private float min_value;

        private float max_value;

        private float avg_value;

        private List<List<int>> histo_bin_values;

        #endregion

        #region - Constructors -

        public Datafield()
        {
            this.data_ordered = new List<float>();

            this.min_value = 0;

            this.max_value = 1;

            this.avg_value = 0.5f;

            this.histo_bin_values = new List<List<int>>();
        }

        #endregion

        #region - Properties -

        public List<float> Data_Ordered
        {
            get { return this.data_ordered; }
            set { this.data_ordered = value; }
        }

        public float Min_Value
        {
            get { return min_value; }
            set { this.min_value = value; }
        }

        public float Max_Value
        {
            get { return this.max_value; }
            set { this.max_value = value; }
        }

        public float Avg_Value
        {
            get { return this.avg_value; }
            set { this.avg_value = value; }
        }

        public List<List<int>> Histo_Bin_Values
        {
            get { return this.histo_bin_values; }
            set { this.histo_bin_values = value; }
        }

        #endregion

        #region - Methods -

        #endregion
    }

    public class Steady_Datafield<T> : Datafield<T>
    {
        #region - Private Variables -

        private List<T> data_unordered; // not ordered data per point

        #endregion

        #region - Constructors -

        public Steady_Datafield()
            : base()
        {
            this.data_unordered = new List<T>();
        }

        public Steady_Datafield(List<T> DF)
            : base()
        {
            this.data_unordered = DF;
        }

        #endregion

        #region - Properties -

        public List<T> Data_Unordered
        {
            get { return this.data_unordered; }
            set { this.data_unordered = value; }
        }

        #endregion

        #region - Methods -

        #endregion
    }

    public class Unsteady_Datafield<T> : Datafield<T>
    {
        #region - Private Variables -

        private List<List<T>> data_unordered; // not ordered data per point for each timestep

        #endregion

        #region - Constructors -

        public Unsteady_Datafield()
            : base()
        {
            this.data_unordered = new List<List<T>>();
        }

        public Unsteady_Datafield(int capacity)
            : base()
        {
            this.data_unordered = new List<List<T>>();

            this.Init_Original_Data(capacity);
        }

        public Unsteady_Datafield(List<List<T>> SF)
            : base()
        {
            this.data_unordered = SF;
        }

        public Unsteady_Datafield(List<T> SingleField)
            : base()
        {
            this.data_unordered = new List<List<T>>();
            this.data_unordered.Add(SingleField);
        }

        #endregion

        #region - Properties -

        public List<List<T>> Data_Unordered
        {
            get { return this.data_unordered; }
            set { this.data_unordered = value; }
        }

        #endregion

        #region - Methods -

        private void Init_Original_Data(int capacity)
        {
            for (int i = 0; i < capacity; i++)
            {
                List<T> item = new List<T>();

                this.data_unordered.Add(item);
            }
        }

        public List<T> RescaleData()
        {
            List<T> newdata = new List<T>();

            for (int i = 0; i < this.Data_Unordered.Count; i++)
            {
                for (int j = 0; j < this.Data_Unordered[i].Count; j++)
                {
                    newdata.Add(this.Data_Unordered[i][j]);
                }
            }

            return newdata;
        }

        #endregion
    }
}
