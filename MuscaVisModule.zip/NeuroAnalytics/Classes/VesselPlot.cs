﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NeuroAnalytics.Properties;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using QuickFont;
using OpenTK.Graphics;

namespace NeuroAnalytics
{
    public class VesselPlot : RenderItem
    {
        #region - Private Variables -

        private int[] is_aneurys_index;

        private int[] vert_segment_index;

        private List<string> parameter_names;

        private List<float> parameter_thresholds;

        private List<int> invert_values;

        private float inner_rad;

        private float outer_rad;

        // List of points for segment lines
        private List<Vector2> segment_lines;

        private List<Vector3> segment_colors;

        // List of points for time lines
        private List<Vector2> time_lines;

        private List<Vector3> time_colors;

        // Indices of segment lines for rendering a line strip
        private List<uint> segment_lines_indices;

        // Indices of time lines for rendering a line strip
        private List<uint> time_lines_indices;

        private Plot_Legend p_legend;

        private int num_timesteps =1; // each third time step (>= 1)

        private Vector3[] region_colors;

        private int initial_num_regions;

        private int num_regions;

        private List<List<int>> vertex_region_information; // a list for each region on the map containing the corresponding vertex indices

        // Plot Information
        private List<List<int>> segment_information;

        private List<Vector2> segment_point_coords;

        private List<Vector3> segment_point_colors;

        private List<uint> triangle_indices;

        // Selection

        // List of points for selected segment lines
        private List<Vector2> sel_segment_lines; 

        // Indices of segment lines for rendering a line strip
        private List<uint> sel_segment_lines_indices;

        private List<Vector3> selected_segment_colors_back;
        private List<Vector3> selected_segment_colors_forg;

        private uint act_sel_index_counter;

        // Translate 
        private Matrix4 translationMatrix;

        // Plot Texture
        private Shader texture_prog;

        private int texture;

        private string texture_path;

        //Plot Text
        QFont text;

        SizeF text_size; 

        // VBO Initialization
        private enum VBONames { PosSeg, ColSeg, IndSeg, PosTime, ColTime, IndTime, PosContent, ColContent, IndContent, PosSel, ColSel, IndSel, PosSel2, ColSel2, IndSel2 };

        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        #endregion

        #region - Constructors -

        public VesselPlot(Dictionary<string, Unsteady_Datafield<float>> Scalar_Data, int[] IS_Aneurysm_Index, string Texture_Path, int Num_Regions, int[] Initial_Vertex_Region_Ids)
            :base(Settings.Default.VesselPlotName)
        {
            this.scalar_data = Scalar_Data;

            this.is_aneurys_index = IS_Aneurysm_Index;

            this.texture_path = Texture_Path;

            this.initial_num_regions = Num_Regions;

            this.num_regions = Num_Regions;

            this.region_colors = this.Init_Region_Colors();

            this.vert_segment_index = Initial_Vertex_Region_Ids;

            this.parameter_names = this.scalar_data.Keys.ToList();

            this.parameter_thresholds = this.Init_Thresholds();

            this.invert_values = this.Init_Invert_Values();

            this.vertex_region_information = this.Get_Vertex_Region_Information();

            this.inner_rad = 0.5f;
            this.outer_rad = 5.0f;

            this.segment_lines = new List<Vector2>();
            this.time_lines = new List<Vector2>();

            this.segment_colors = new List<Vector3>();
            this.time_colors = new List<Vector3>();

            this.segment_lines_indices = new List<uint>();
            this.time_lines_indices = new List<uint>();

            this.segment_information = new List<List<int>>();

            this.segment_point_coords = new List<Vector2>();

            this.segment_point_colors = new List<Vector3>();

            this.triangle_indices = new List<uint>();

            this.sel_segment_lines = new List<Vector2>();

            this.sel_segment_lines_indices = new List<uint>();

            this.selected_segment_colors_back = new List<Vector3>();
            this.selected_segment_colors_forg = new List<Vector3>();

            this.act_sel_index_counter = 0;

            this.Get_Segment_Information();

            this.Generate_Time_Lines();

            this.Generate_Segment_Lines();

            this.p_legend = new Plot_Legend(this.parameter_names);

            translationMatrix = Matrix4.CreateTranslation(new Vector3(1.0f, 0f, 0f));

            translationMatrix = Matrix4.Identity * translationMatrix;

            this.transformationMatrix = this.transformationMatrix * translationMatrix;

            this.vao = new uint[5];

            this.vbo = new uint[this.number_vbo];
        }

        #endregion

        #region - Properties -

        public List<float> Parameter_Thresholds
        {
            get { return this.parameter_thresholds; }
            set { this.parameter_thresholds = value; }
        }

        public List<string> Parameter_Names
        {
            get { return this.parameter_names; }
            set { this.parameter_names = value; }
        }

        public List<int> InvertValues
        {
            get { return this.invert_values; }
            set { this.invert_values = value; }
        }

        public int Num_Depicted_Plot_Timesteps
        {
            get { return this.num_timesteps; }
            set { this.num_timesteps = value; }
        }

        public Plot_Legend Legend
        {
            get { return this.p_legend; }
            set { this.p_legend = value; }
        }

        public int Num_Regions
        {
            get { return this.num_regions; }
            set { this.num_regions = value; }
        }

        public int Initial_Num_Regions
        {
            get { return this.initial_num_regions; }
            set { this.initial_num_regions = value; }
        }

        public int[] Vert_Segment_Indices
        {
            get { return this.vert_segment_index; }
            set { this.vert_segment_index = value;
            this.vertex_region_information = this.Get_Vertex_Region_Information();
            }
        }

        public Vector3[] Region_Colors
        {
            get { return this.region_colors; }
            set { this.region_colors = value; }
        }

        #endregion

        #region - Methods -

        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            return true;
        }

        public override void SetupRender()
        {
            //this.Load_Plot_Texture(@"B:\Monique\06_Promotion\1_Datasets\EuroVis\Extracted_Data\FSI_Challenge_Case01\StreamlineClustering\Texture\MapRegionsFSI01.bmp");
            this.Load_Plot_Texture(this.texture_path);

            this.Init_Plot_Texture_Shader();

            GL.GenVertexArrays(5, out this.vao[0]);
            GL.BindVertexArray(this.vao[0]);

            // vbo [0] = segment positions
            GL.GenBuffers(this.vbo.Length, this.vbo);
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.PosSeg]);
            GL.BufferData<Vector2>(BufferTarget.ArrayBuffer, (IntPtr)(this.segment_lines.Count * Vector2.SizeInBytes), this.segment_lines.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = segment colors
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.ColSeg]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.segment_colors.Count * Vector3.SizeInBytes), this.segment_colors.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo [2] = segment indices
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndSeg]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.segment_lines_indices.Count * sizeof(uint)), this.segment_lines_indices.ToArray(), BufferUsageHint.StaticDraw);

            //________________________________________________________________________________________________________________________________________________________________________

            GL.BindVertexArray(this.vao[1]);

            // vbo [3] = time positions
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.PosTime]);
            GL.BufferData<Vector2>(BufferTarget.ArrayBuffer, (IntPtr)(this.time_lines.Count * Vector2.SizeInBytes), this.time_lines.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [4] = time colors
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.ColTime]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.time_colors.Count * Vector3.SizeInBytes), this.time_colors.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo [5] = time indices
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndTime]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.time_lines_indices.Count * sizeof(uint)), this.time_lines_indices.ToArray(), BufferUsageHint.StaticDraw);

            //________________________________________________________________________________________________________________________________________________________________________

            GL.BindVertexArray(this.vao[2]);

            // vbo [6] = content positions
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.PosContent]);
            GL.BufferData<Vector2>(BufferTarget.ArrayBuffer, (IntPtr)(this.segment_point_coords.Count * Vector2.SizeInBytes), this.segment_point_coords.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [7] = content colors
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.ColContent]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.segment_point_colors.Count * Vector3.SizeInBytes), this.segment_point_colors.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo [8] = time indices
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndContent]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.triangle_indices.Count * sizeof(uint)), this.triangle_indices.ToArray(), BufferUsageHint.StaticDraw);

            //________________________________________________________________________________________________________________________________________________________________________

            GL.BindVertexArray(this.vao[3]);

            // vbo [9] = selected positions
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.PosSel]);
            GL.BufferData<Vector2>(BufferTarget.ArrayBuffer, (IntPtr)(this.sel_segment_lines.Count * Vector2.SizeInBytes), this.sel_segment_lines.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [10] = selected colors
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.ColSel]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.selected_segment_colors_back.Count * Vector3.SizeInBytes), this.selected_segment_colors_back.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo [11] = selected indices
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndSel]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.sel_segment_lines_indices.Count * sizeof(uint)), this.sel_segment_lines_indices.ToArray(), BufferUsageHint.StaticDraw);

            //________________________________________________________________________________________________________________________________________________________________________

            GL.BindVertexArray(this.vao[4]);

            // vbo [9] = selected positions
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.PosSel]);
            GL.BufferData<Vector2>(BufferTarget.ArrayBuffer, (IntPtr)(this.sel_segment_lines.Count * Vector2.SizeInBytes), this.sel_segment_lines.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [10] = selected colors
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.ColSel2]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.selected_segment_colors_forg.Count * Vector3.SizeInBytes), this.selected_segment_colors_forg.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo [11] = selected indices
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndSel]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.sel_segment_lines_indices.Count * sizeof(uint)), this.sel_segment_lines_indices.ToArray(), BufferUsageHint.StaticDraw);

            // Unbind VAO
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

            GL.BindVertexArray(0);

            // Setup Text
            this.text = new QFont("times.ttf", 20, FontStyle.Regular);
            this.text.Options.Colour = new Color4(0.0f, 0.0f, 0.4f, 1.0f);

            this.Init_Setup = true;

            Console.WriteLine("-> Vessel Plot created");
        }

        public override void Render()
        {
            if (!this.Renderable())
            {
                return;
            }

            this.Render_Selected_Regions2();

            this.Render_Selected_Regions();

            this.Render_Segment_Lines();

            this.Render_Time_Lines();

            this.Render_Plot_Content();

            this.Render_Plot_Center();

            // Render Text
            this.RenderText();
        }

        private void Render_Segment_Lines()
        {
            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);

                this.shaderprog.EnableShader();
                {
                    //Binding VAO
                    GL.BindVertexArray(vao[0]);
                    {
                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndSeg]);

                        GL.Enable(EnableCap.PrimitiveRestart);

                        GL.LineWidth(2.0f);

                        //#Primitives x #Points per Primitive
                        GL.DrawElements(PrimitiveType.LineStrip, this.segment_lines_indices.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);

                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    }
                    GL.BindVertexArray(0);
                }
                this.shaderprog.DisableShader();
            }
            GL.PopMatrix();
        }

        private void Render_Time_Lines()
        {
            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);

                this.shaderprog.EnableShader();
                {
                    //Binding VAO
                    GL.BindVertexArray(vao[1]);
                    {
                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndTime]);

                        GL.Enable(EnableCap.PrimitiveRestart);

                        GL.LineWidth(2.0f);

                        //#Primitives x #Points per Primitive
                        GL.DrawElements(PrimitiveType.LineStrip, this.time_lines_indices.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);

                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    }
                    GL.BindVertexArray(0);
                }
                this.shaderprog.DisableShader();
            }
            GL.PopMatrix();
        }

        private void Render_Plot_Content()
        {
            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);

                this.shaderprog.EnableShader();
                {
                    //Binding VAO
                    GL.BindVertexArray(vao[2]);
                    {
                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndContent]);

                        GL.Enable(EnableCap.PrimitiveRestart);

                        //#Primitives x #Points per Primitive
                        GL.DrawElements(PrimitiveType.TriangleStrip, this.triangle_indices.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);

                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

                    }
                    GL.BindVertexArray(0);
                }
                this.shaderprog.DisableShader();
            }
            GL.PopMatrix();
        }

        private void Render_Plot_Center()
        {
            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);

                this.texture_prog.EnableShader();
                {
                    GL.ActiveTexture(TextureUnit.Texture0);
                    GL.BindTexture(TextureTarget.Texture2D, this.texture);
                    GL.Uniform1(GL.GetUniformLocation(this.texture_prog.Prog, "PlotTexture"), 0);

                    //#Primitives x #Points per Primitive
                    GL.DrawArrays(PrimitiveType.Quads, 0, 4);

                    GL.BindTexture(TextureTarget.Texture2DArray, 0);
                }
                this.texture_prog.DisableShader();
            }
            GL.PopMatrix();
        }

        private void Render_Selected_Regions()
        {
            if (this.sel_segment_lines_indices.Count < 1)
            {
                return;
            }

            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);

                this.shaderprog.EnableShader();
                {
                    //Binding VAO
                    GL.BindVertexArray(vao[3]);
                    {
                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndSel]);

                        GL.Enable(EnableCap.PrimitiveRestart);

                        GL.LineWidth(5.0f);

                        //#Primitives x #Points per Primitive
                        GL.DrawElements(PrimitiveType.LineStrip, this.sel_segment_lines_indices.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);

                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    }
                    GL.BindVertexArray(0);
                }
                this.shaderprog.DisableShader();
            }
            GL.PopMatrix();
        }

        private void Render_Selected_Regions2()
        {
            if (this.sel_segment_lines_indices.Count < 1)
            {
                return;
            }

            GL.PushMatrix();
            {
                GL.MultMatrix(ref this.transformationMatrix);

                this.shaderprog.EnableShader();
                {
                    //Binding VAO
                    GL.BindVertexArray(vao[4]);
                    {
                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndSel]);

                        GL.Enable(EnableCap.PrimitiveRestart);

                        GL.LineWidth(1.0f);

                        //#Primitives x #Points per Primitive
                        GL.DrawElements(PrimitiveType.LineStrip, this.sel_segment_lines_indices.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);

                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    }
                    GL.BindVertexArray(0);
                }
                this.shaderprog.DisableShader();
            }
            GL.PopMatrix();
        }

        private void RenderText()
        {
            List<int> positions = this.GenerateTextCoords();

            QFont.Begin();
            GL.PushMatrix();

            GL.MultMatrix(ref this.transformationMatrix);

            int j = 0;

            for (int i = 0; i < positions.Count; i += 2)
            {
                QFont.ForceViewportRefresh();

                this.text_size = this.text.Measure("T_" + j);
                this.text.Options.Colour = new OpenTK.Graphics.Color4(0.0f, 0.0f, 0.0f, 1.0f);
                //this.text.Print("T_" + j, new Vector2(positions[i], positions[i + 1]-this.text_size.Height));
                this.text.Print("T_" + j, new Vector2(positions[i], positions[i + 1] ));

                j+=this.num_timesteps;
            }

            GL.PopMatrix();
            QFont.End();
        }

        public void Init_Plot_Texture_Shader()
        {
            List<string> shaderpathes = new List<string>();

            string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + @"Quad\";

            shaderpathes.Add(shaderpath + "2_quad2D.vert");
            shaderpathes.Add(shaderpath + "2_quad2D.frag");

            this.texture_prog = new Shader(shaderpathes);
        }

        public Vector3[] Init_Region_Colors()
        {
            Vector3[] colors = new Vector3[this.num_regions];

            for (int i = 0; i < this.num_regions; i++)
            {
                if (i < Utility.Initial_Brush_Region_Colors.Length)
                {
                    colors[i] = Utility.Initial_Brush_Region_Colors[i];
                }
                else
                {
                    colors[i] = Vector3.Zero;
                }
            }

            return colors;
        }

        private void Generate_Time_Lines()
        {
            int timesteps = Utility.Num_Timesteps / this.num_timesteps;

            float mod = (float)Utility.Num_Timesteps % (float)this.num_timesteps;

            if (mod > 0)
            {
                timesteps++;
            }

            float step = 360.0f / timesteps;

            //float step = 360.0f / 10;

            float angleCircle = 0;

            uint index = 0;

            float x, y;

            while (!(angleCircle > (360.0-step)))
            {
                x = (float)(Math.Sqrt(this.inner_rad) * Math.Sin(Utility.toRad(angleCircle)));
                y = (float)(Math.Sqrt(this.inner_rad) * Math.Cos(Utility.toRad(angleCircle)));

                this.time_lines.Add(new Vector2(x, y));
                this.time_colors.Add(new Vector3(0.23f));
                this.time_lines_indices.Add(index);

                index++;

                x = (float)(Math.Sqrt(this.outer_rad) * Math.Sin(Utility.toRad(angleCircle)));
                y = (float)(Math.Sqrt(this.outer_rad) * Math.Cos(Utility.toRad(angleCircle)));

                this.time_lines.Add(new Vector2(x, y));
                this.time_colors.Add(new Vector3(0.23f));
                this.time_lines_indices.Add(index);

                index++;

                this.time_lines_indices.Add(uint.MaxValue);

                angleCircle += step;
            }
        }

        private void Generate_Segment_Lines()
        {
            float rad_step = (this.outer_rad - this.inner_rad);
            rad_step = rad_step / this.scalar_data.Count;

            float step = 360.0f / 100.0f;

            float angleCircle = 0;

            uint index = 0;

            float x, y;

            for (float i = this.inner_rad; i < (this.outer_rad + rad_step); i += rad_step)
            {
                while (!(angleCircle > 361))
                {
                    x = (float)(Math.Sqrt(i) * Math.Cos(Utility.toRad(angleCircle)));
                    y = (float)(Math.Sqrt(i) * Math.Sin(Utility.toRad(angleCircle)));

                    this.segment_lines.Add(new Vector2(x, y));
                    this.segment_colors.Add(new Vector3(0.23f));
                    this.segment_lines_indices.Add(index);

                    index++;

                    angleCircle += step;
                }

                this.segment_lines_indices.Add(uint.MaxValue);

                angleCircle = 0;
            }
        }

        private List<float> Init_Thresholds()
        {
            List<float> thr = new List<float>();

            float min, max;

            string name;

            float val;

            float t = 1.0f / 3.0f;

            for (int i = 0; i < this.parameter_names.Count; i++)
            {
                name = this.parameter_names[i];

                min = Utility.norm_values[name].X;
                max = Utility.norm_values[name].Y;

                val = ((1.0f-t) * min) + (t * max);

                thr.Add(val);
            }

            return thr;
        }

        private List<int> Init_Invert_Values()
        {
            List<int> values = new List<int>();

            for (int i = 0; i < this.parameter_names.Count; i++)
            {
                values.Add(0);
            }

            return values;
        }

        private List<List<int>> Get_Vertex_Region_Information()
        {
            List<List<int>> vertex_region_information = new List<List<int>>();

            for (int i = 0; i < this.num_regions; i++) // number of regions
            {
                vertex_region_information.Add(new List<int>());
            }

            for (int i = 0; i < this.vert_segment_index.Length; i++)
            {
                if (this.vert_segment_index[i] != -1)
                {
                    vertex_region_information[this.vert_segment_index[i]].Add(i);
                }
            }

            return vertex_region_information;
        }

        public void Get_Segment_Information()
        {
            if (this.segment_information.Count > 0)
            {
                for (int i = 0; i < this.segment_information.Count; i++)
                {
                    try
                    {
                        this.segment_information[i].Clear();
                    }
                    catch (Exception)
                    {
                    }
                }
            }
            else
            {
                int plotted_timesteps = Utility.Num_Timesteps / this.num_timesteps;

                float mod = (float)Utility.Num_Timesteps % (float)this.num_timesteps;

                if (mod > 0)
                {
                    plotted_timesteps++;
                }

                int capacity = plotted_timesteps * this.scalar_data.Count;

                for (int i = 0; i < capacity; i++)
                {
                    List<int> list = new List<int>();

                    this.segment_information.Add(list);
                }
            }

            string act_name = "";
            int act_vert_index = 0;
            int listcount = 0;
            int sfcount = 0;

            try
            {
                for (int t = 0; t < Utility.Num_Timesteps; t += this.num_timesteps) // over timesteps
                {
                    sfcount = listcount*this.parameter_names.Count;

                    for (int c = 0; c < this.num_timesteps; c++)                 // over plotted timesteps
                    {
                        if ((t + c) < Utility.Num_Timesteps)
                        {
                            for (int s = 0; s < this.parameter_names.Count; s++)
                            {
                                act_name = this.parameter_names[s];

                                for (int i = 0; i < this.vertex_region_information.Count; i++)
                                {
                                    if (this.segment_information[(sfcount+s)].Contains(i))
                                    {
                                        continue;
                                    }

                                    for (int j = 0; j < this.vertex_region_information[i].Count; j++)
                                    {
                                        act_vert_index = this.vertex_region_information[i][j];

                                        if (this.invert_values[s] > 0)
                                        {
                                            if (this.scalar_data[act_name].Data_Unordered[(t + c)][act_vert_index] <= this.parameter_thresholds[s])
                                            {
                                                this.segment_information[(sfcount + s)].Add(this.vert_segment_index[act_vert_index]);

                                                break;
                                            }
                                        }
                                        else
                                        {
                                            if (this.scalar_data[act_name].Data_Unordered[(t + c)][act_vert_index] >= this.parameter_thresholds[s])
                                            {
                                                this.segment_information[(sfcount + s)].Add(this.vert_segment_index[act_vert_index]);

                                                break;
                                            }
                                        } 
                                    }
                                }
                            }
                        }
                    }

                    listcount++;
                }

                this.Sort_Segment_Regions();

                this.Calculate_Segment_Parts();
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void Sort_Segment_Regions()
        {
            if (this.segment_information.Count > 0)
            {
                for (int i = 0; i < this.segment_information.Count; i++)
                {
                    this.segment_information[i].Sort();
                }
            }
        }

        private void Calculate_Segment_Parts()
        {
            try
            {
                this.triangle_indices.Clear();
                this.segment_point_coords.Clear();
                this.segment_point_colors.Clear();
            }
            catch (Exception)
            {
            }

            int index = 0;
            float seg_length = (this.outer_rad - this.inner_rad) / (float)this.scalar_data.Count;

            int timesteps = Utility.Num_Timesteps / this.num_timesteps;

            float mod = (float)Utility.Num_Timesteps % (float)this.num_timesteps;

            if (mod > 0)
            {
                timesteps++;
            }

            float K = (360.0f / timesteps);

            int acttimepoint;

            int radius, map_color_index;
            float start_radius, end_radius, angle, start_angle, end_angle, angle_range, angle_part;
            float x, y;

            for (int i = 0; i < this.segment_information.Count; i++)
            {
                radius = i % this.scalar_data.Count;
                start_radius = this.inner_rad + (seg_length * (float)radius);
                end_radius = start_radius + seg_length;

                acttimepoint = i / this.scalar_data.Count;
                angle = K * acttimepoint;
                start_angle = K * acttimepoint;
                end_angle = K * (acttimepoint + 1);
                angle_range = end_angle - angle;
                angle_part = angle_range / this.segment_information[i].Count;

                if (this.segment_information[i].Count > 0)
                {
                    for (int j = 1; j <= this.segment_information[i].Count; j++)
                    {
                        map_color_index = this.segment_information[i][j - 1];

                        while (angle <= (start_angle + (j * angle_part)))
                        {
                            x = (float)(Math.Sqrt(end_radius) * Math.Sin(Utility.toRad(angle)));
                            y = (float)(Math.Sqrt(end_radius) * Math.Cos(Utility.toRad(angle)));

                            this.segment_point_coords.Add(new Vector2(x, y));
                            this.segment_point_colors.Add(this.region_colors[map_color_index]);

                            this.triangle_indices.Add((uint)index);

                            index += 1;

                            x = (float)(Math.Sqrt(start_radius) * Math.Sin(Utility.toRad(angle)));
                            y = (float)(Math.Sqrt(start_radius) * Math.Cos(Utility.toRad(angle)));

                            this.segment_point_coords.Add(new Vector2(x, y));
                            this.segment_point_colors.Add(this.region_colors[map_color_index]);
                            this.triangle_indices.Add((uint)index);

                            index += 1;

                            angle += 0.01f;
                        }
                    }

                    this.triangle_indices.Add(uint.MaxValue);
                }
            }
        }

        private void Load_Plot_Texture(string path)
        {
            string[] texture_files = Directory.GetFiles(path);

            if (texture_files.Length > 0 && texture_files.Last().EndsWith("bmp"))
            {
                path = texture_files.Last();

                GL.GenTextures(1, out this.texture);

                GL.BindTexture(TextureTarget.Texture2D, this.texture);

                Bitmap bmp = new Bitmap(path);

                BitmapData bmp_data = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

                GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, bmp_data.Width, bmp_data.Height, 0,
                    OpenTK.Graphics.OpenGL.PixelFormat.Bgra, PixelType.UnsignedByte, bmp_data.Scan0);

                bmp.UnlockBits(bmp_data);

                //GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);

                GL.BindImageTexture(0, this.texture, 0, true, 0, TextureAccess.ReadWrite, SizedInternalFormat.Rgba32f);

                GL.BindTexture(TextureTarget.Texture2DArray, 0);
            }
        }

        public override void Clear_Brushing()
        {
            if (this.vert_segment_index != null)
            {
                for (int i = 0; i < this.vert_segment_index.Length; i++)
                {
                    this.vert_segment_index[i] = -1;
                }

                this.vertex_region_information = this.Get_Vertex_Region_Information();
            }
        }

        public void Get_Selected_Plot_Segment(Vector2 sel_point, out int region_id, out int time_seg)
        {
            Vector2 mir_sel_point = new Vector2(sel_point.Y, sel_point.X);

            Vector2 polar_coords = Utility.ConvertToPolarCoord(mir_sel_point);

            float radius = (float)Math.Pow(polar_coords.X, 2);

            float angle = Utility.toDeg(polar_coords.Y);

            time_seg = 0;

            int scal_seg = 0;

            region_id = -1;

            // Get time segment
            int timesteps = Utility.Num_Timesteps / this.num_timesteps;

            float mod = (float)Utility.Num_Timesteps % (float)this.num_timesteps;

            if (mod > 0)
            {
                timesteps++;
            }

            float step = 360.0f / timesteps;

            float angleCircle = 0;

            while (!(angleCircle > (360.0 - step)))
            {
                if (angle >= angleCircle && angle <= (angleCircle + step))
                {
                    break;
                }

                time_seg++;
                angleCircle += step;
            }

            //---------------------------------------------------------------------------------------------------------------

            // Get scalar field segment

            float rad_step = (this.outer_rad - this.inner_rad);
            rad_step = rad_step / this.scalar_data.Count;

            for (float i = this.inner_rad; i < this.outer_rad; i += rad_step)
            {
                if (radius >=i && radius <= (i + rad_step))
                {
                    break;
                }

                scal_seg++;
            }

            if ((radius < this.inner_rad) || (scal_seg > (this.scalar_data.Count-1))) // clicked position out of plot area
            {
                scal_seg = -1;
                time_seg = -1;

                return;
            }

            //---------------------------------------------------------------------------------------------------------------

            this.Add_Selected_Regions(time_seg, scal_seg, angle, out region_id);
        }

        private void Add_Selected_Regions(int time_segment, int scalar_segment, float angle, out int region_id)
        {
            List<int> act_regions = this.segment_information[time_segment * this.scalar_data.Count + scalar_segment];

            int num_regions = act_regions.Count;

            if (num_regions == 0)
            {
                region_id = -1;

                this.Reset_Selection();

                return;
            }

            region_id = 0;

             // Get time segment
            int timesteps = Utility.Num_Timesteps / this.num_timesteps;

            float mod = (float)Utility.Num_Timesteps % (float)this.num_timesteps;

            if (mod > 0)
            {
                timesteps++;
            }

            float step = 360.0f / timesteps;

            float start_angle = step * (float)time_segment;
            float end_angle = step * (float)(time_segment+1);

            float seg_step = step / (float)num_regions;

            float x, y;

            float start_rad = this.inner_rad + ((this.outer_rad - this.inner_rad) / (float)this.scalar_data.Count) * (float)scalar_segment;
            float end_rad = this.inner_rad + ((this.outer_rad - this.inner_rad) / (float)this.scalar_data.Count) * (float)(scalar_segment+1);

            int region_count = 0;

            this.Reset_Selection();

            while (!(start_angle > end_angle))
            {
                if (angle >= start_angle && angle <= (start_angle + seg_step))
                {
                    this.Generate_Time_Selection_Lines(start_rad, end_rad, start_angle, end_angle, seg_step);

                    this.Generate_Segment_Selection_Lines(start_rad, end_rad, start_angle, seg_step);

                    break;
                }

                region_count++;

                start_angle += seg_step;
            }

            region_id = act_regions[region_count];
        }

        private void Generate_Time_Selection_Lines(float start_rad, float end_rad, float start_angle, float end_angle, float seg_step)
        {
            float x, y;

            // First line
            x = (float)(Math.Sqrt(start_rad) * Math.Sin(Utility.toRad(start_angle)));
            y = (float)(Math.Sqrt(start_rad) * Math.Cos(Utility.toRad(start_angle)));

            this.sel_segment_lines.Add(new Vector2(x, y));
            this.selected_segment_colors_back.Add(Vector3.Zero);
            this.selected_segment_colors_forg.Add(Vector3.One);
            this.sel_segment_lines_indices.Add(this.act_sel_index_counter);

            this.act_sel_index_counter++;

            x = (float)(Math.Sqrt(end_rad) * Math.Sin(Utility.toRad(start_angle)));
            y = (float)(Math.Sqrt(end_rad) * Math.Cos(Utility.toRad(start_angle)));

            this.sel_segment_lines.Add(new Vector2(x, y));
            this.selected_segment_colors_back.Add(Vector3.Zero);
            this.selected_segment_colors_forg.Add(Vector3.One);
            this.sel_segment_lines_indices.Add(this.act_sel_index_counter);

            this.act_sel_index_counter++;

            this.sel_segment_lines_indices.Add(uint.MaxValue);

            // Second Line
            x = (float)(Math.Sqrt(start_rad) * Math.Sin(Utility.toRad((start_angle + seg_step))));
            y = (float)(Math.Sqrt(start_rad) * Math.Cos(Utility.toRad((start_angle + seg_step))));

            this.sel_segment_lines.Add(new Vector2(x, y));
            this.selected_segment_colors_back.Add(Vector3.Zero);
            this.selected_segment_colors_forg.Add(Vector3.One);
            this.sel_segment_lines_indices.Add(this.act_sel_index_counter);

            this.act_sel_index_counter++;

            x = (float)(Math.Sqrt(end_rad) * Math.Sin(Utility.toRad((start_angle + seg_step))));
            y = (float)(Math.Sqrt(end_rad) * Math.Cos(Utility.toRad((start_angle + seg_step))));

            this.sel_segment_lines.Add(new Vector2(x, y));
            this.selected_segment_colors_back.Add(Vector3.Zero);
            this.selected_segment_colors_forg.Add(Vector3.One);
            this.sel_segment_lines_indices.Add(this.act_sel_index_counter);

            this.act_sel_index_counter++;

            this.sel_segment_lines_indices.Add(uint.MaxValue);
        }

        private void Generate_Segment_Selection_Lines(float start_rad, float end_rad, float start_angle, float seg_step)
        {
            float step = 360.0f / 100.0f;

            float angleCircle = start_angle;

            float end_angle = start_angle + seg_step;

            float x, y;

            while (!(angleCircle > end_angle))
            {
                x = (float)(Math.Sqrt(start_rad) * Math.Sin(Utility.toRad(angleCircle)));
                y = (float)(Math.Sqrt(start_rad) * Math.Cos(Utility.toRad(angleCircle)));

                this.sel_segment_lines.Add(new Vector2(x, y));
                this.selected_segment_colors_back.Add(Vector3.Zero);
                this.selected_segment_colors_forg.Add(Vector3.One);
                this.sel_segment_lines_indices.Add(act_sel_index_counter);

                this.act_sel_index_counter++;

                angleCircle += step;
            }

            this.sel_segment_lines_indices.Add(uint.MaxValue);

            angleCircle = start_angle;

            while (!(angleCircle > end_angle))
            {
                x = (float)(Math.Sqrt(end_rad) * Math.Sin(Utility.toRad(angleCircle)));
                y = (float)(Math.Sqrt(end_rad) * Math.Cos(Utility.toRad(angleCircle)));

                this.sel_segment_lines.Add(new Vector2(x, y));
                this.selected_segment_colors_back.Add(Vector3.Zero);
                this.selected_segment_colors_forg.Add(Vector3.One);
                this.sel_segment_lines_indices.Add(act_sel_index_counter);

                this.act_sel_index_counter++;

                angleCircle += step;
            }

            this.sel_segment_lines_indices.Add(uint.MaxValue);
        }

        public void Reset_Selection()
        {
            if (this.sel_segment_lines.Count > 0)
            {
                this.sel_segment_lines.Clear();
                this.selected_segment_colors_forg.Clear();
                this.selected_segment_colors_back.Clear();
                this.sel_segment_lines_indices.Clear();

                this.act_sel_index_counter = 0;
            }
        }

        private List<int> GenerateTextCoords()
        {
            List<int> screenpos = new List<int>();

            int timesteps = Utility.Num_Timesteps / this.num_timesteps;

            float mod = (float)Utility.Num_Timesteps % (float)this.num_timesteps;

            if (mod > 0)
            {
                timesteps++;
            }

            float step = 360.0f / timesteps;
            float lineCircle = 0.0f;

            float x, y;

            Vector4 vp;
            GL.GetFloat(GetPName.Viewport, out vp);

            float xfragf = 0;
            float yfragf = 0;

            int xfrag = 0;
            int yfrag = 0;

            for (int j = 0; j < timesteps; j++)
            {
                // World Coordinates
                x = (float)(Math.Sqrt((this.outer_rad+0.5)) * Math.Sin(Utility.toRad(lineCircle + (step/2))));
                y = -(float)(Math.Sqrt((this.outer_rad + 0.5)) * Math.Cos(Utility.toRad(lineCircle + (step / 2))));

                this.text_size = this.text.Measure("T_" + j);

                //x = x - offset_X;
                x = x + 1; // Translation
                //y = y + offset_Y;

                Vector4 pos = new Vector4(x, y, 0.0f, 1.0f);

                
                 // Screen Coordinates

                Vector4 mv_transform = Vector4.Zero;
                Vector4 proj_transform = Vector4.Zero;
                Vector4 screen = Vector4.Zero;

                mv_transform = Vector4.Transform(pos, Utility.Picking_Mat_ModelView_2DBEPPlot);
                proj_transform = Vector4.Transform(mv_transform, Utility.Picking_Mat_Projection_2DBEPPlot);

                // perspective division
                screen.Xyz = proj_transform.Xyz / proj_transform.W;

                xfragf = screen.X * (vp.Z / 2) + (vp.Z / 2);
                yfragf = screen.Y * (vp.W / 2) + (vp.W / 2);

                xfrag = (int)xfragf;
                yfrag = (int)yfragf;


                if (lineCircle > 180.0f)
                {
                    xfrag = xfrag - (int)this.text_size.Width;
                }

                if (lineCircle >= 90 && lineCircle <= 270)
                {
                    yfrag = yfrag + ((int)this.text_size.Height /4);
                }
                else
                {
                    yfrag = yfrag - ((int)this.text_size.Height);
                }

                screenpos.Add(xfrag);
                screenpos.Add(yfrag);

                lineCircle += step;
            }
 
            return screenpos;
        }

        #endregion
    }

    public class Plot_Legend : RenderItem
    {
        #region - Private Variables -

        private List<string> parameter_names;

        // List of points for legend lines
        private List<Vector2> legend_lines;

        // Indices of legend lines for rendering a line strip
        List<uint> legend_lines_indices;

        // VBO Initialization
        private enum VBONames {PosLeg, LegInd };

        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        #endregion

        #region - Constructors -

        public Plot_Legend(List<string> Parameter_Names)
            : base(Settings.Default.PlotLegendName)
        {
            this.parameter_names = Parameter_Names;

            this.legend_lines = new List<Vector2>();
            this.legend_lines_indices = new List<uint>();

            this.Generate_Legend_Lines();

            this.vao = new uint[1];

            this.vbo = new uint[this.number_vbo];
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            return true;
        }

        public override void SetupRender()
        {
            GL.GenVertexArrays(1, out this.vao[0]);
            GL.BindVertexArray(this.vao[0]);

            // vbo [0] = legend positions
            GL.GenBuffers(this.vbo.Length, this.vbo);
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.PosLeg]);
            GL.BufferData<Vector2>(BufferTarget.ArrayBuffer, (IntPtr)(this.legend_lines.Count * Vector2.SizeInBytes), this.legend_lines.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 2, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = time indices
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.LegInd]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.legend_lines_indices.Count * sizeof(uint)), this.legend_lines_indices.ToArray(), BufferUsageHint.StaticDraw);

            // Unbind VAO
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

            GL.BindVertexArray(0);

            this.Init_Setup = true;

            Console.WriteLine("-> Plot Legend created");
        }

        public override void Render()
        {
            if (!this.Renderable())
            {
                return;
            }

            this.Render_Legend_Lines();
        }

        private void Render_Legend_Lines()
        {
            GL.PushMatrix();
            {
                this.shaderprog.EnableShader();
                {
                    //Binding VAO
                    GL.BindVertexArray(vao[0]);
                    {
                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.LegInd]);

                        GL.Enable(EnableCap.PrimitiveRestart);

                        GL.LineWidth(2.0f);

                        //#Primitives x #Points per Primitive
                        GL.DrawElements(PrimitiveType.LineStrip, this.legend_lines_indices.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);

                        GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);
                    }
                    GL.BindVertexArray(0);
                }
                this.shaderprog.DisableShader();
            }
            GL.PopMatrix();
        }

        private void Generate_Legend_Lines()
        {
            float inn_rad = 0.02f;
            float out_rad = (float)this.parameter_names.Count * 0.1f + 0.1f;

            float rad_step = (out_rad - inn_rad);
            rad_step = rad_step / this.parameter_names.Count;

            float step = 360.0f / 100.0f;

            float angleCircle = 0;

            uint index = 0;

            float x, y;

            for (float i = inn_rad; i < (out_rad + rad_step); i += rad_step)
            {
                while (!(angleCircle > 361))
                {
                    x = (float)(i * Math.Cos(Utility.toRad(angleCircle)));
                    y = (float)(i * Math.Sin(Utility.toRad(angleCircle)));

                    this.legend_lines.Add(new Vector2(x, y));
                    this.legend_lines_indices.Add(index);

                    index++;

                    angleCircle += step;
                }

                this.legend_lines_indices.Add(uint.MaxValue);

                angleCircle = 0;
            }
        }

        #endregion
    }
}
