﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL;
using OpenTK; 
using NeuroAnalytics.Properties;
using MathWorks.MATLAB.NET.Arrays;
using System.IO;
using ConformalParametrization;
using MapSampling;
//using StatisticAnalysis;
using RegionStatistics;
using ConnectedComponent;
using Boundary;
using MeshRegions;

namespace NeuroAnalytics
{
    public class Map : RenderItem
    {
        #region - Private Variables -

        // Original Triangle Information for first timestep
        private List<Triangle> mesh_triangles;
        private List<Vector3> mesh_vertices;
        private List<Vector3> mesh_normals;

        // Projected Vertex Information
        private List<Triangle> map_triangles_3D;  // orginal 3D triangles
        private List<Vector3> map_vertices_3D; // orginal 3D vertex positions

        // dimensions
        private Vector2 min_dim;
        private Vector2 max_dim;

        private int[] is_aneurys_index;

        private List<Triangle> triangles;

        private List<uint> index_buffer;

        // Indices for projection
        private List<int> dome_indices;
        private List<int> ostium_indices;

        // Dome2D
        private List<Vector3> dome_points_2D;

        // Dome 3D
        private List<Vector3> dome_points_3D;

        // Ostium2D
        private List<Vector3> ostium_points_2D;

        // Ostium 3D
        private List<Vector3> ostium_points_3D;
        private List<Vector3> ostium_normals_3D;

        private Ostium map_ostium;

        // Cluster Rendering
        private Shader isoline_shader_prog;

        private bool render_iso_lines;

        private uint[] isoline_lables;
        private float[] cluster_values;

        private uint[] sel_region_lables; // is 1 for selected region and 0 else

        // Sampling
        private bool is_sampled; 
        private List<int> sample_indices;
        private List<Vector2> sample_positions;

        private Cylinder map_cylinder;

        private Plane map_plane;

        // SSBO Inputs
        private List<float> transform_feedback_list;

        // VBO Initialization
        private enum VBONames { Pos, AneurysmIndex, IndexBuffer };

        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        // SSBO Initialization
        private enum SSBONames { AllParam, TransformFeedback, Isolinedata, ClusterAVGValues, RegSel, BrushedId };

        private int number_ssbo = Enum.GetNames(typeof(SSBONames)).Length;

        private List<float> all_parameters;

        private Shader transformfeedback_shader;

        // Contour Rendering
        private Shader contour_shader_prog;

        private bool render_contour;

        // Shader output
        private float[] brushed_map_points;

        private bool show_initial_brush;

        private int[] inital_vertex_region_ids;

        private List<int> vertex_region_ids;

        private int[] brushed_reg_indices;

        private float[] selected_colors;

        // Translate 
        private Matrix4 translationMatrix;

        #endregion

        #region - Constructors -

        // Generated map from 3D surface mesh
        public Map(List<Triangle> MeshTriangles, List<Vector3> MeshVertices, List<Vector3> MeshNormals, Dictionary<string, Unsteady_Datafield<float>> Map_Scalar_Info,
                   List<int> Dome_Indices, List<int> Ostium_Indices, bool Sampling, List<int> Initial_Vertex_Region_Ids)
            : base(Settings.Default.MapName)
        {
            this.mesh_triangles = MeshTriangles;
            this.mesh_vertices = MeshVertices;
            this.mesh_normals = MeshNormals;
            this.scalar_data = Map_Scalar_Info;

            this.map_triangles_3D = new List<Triangle>();
            this.map_vertices_3D = new List<Vector3>();

            this.is_aneurys_index = new int[MeshVertices.Count];

            this.triangles = new List<Triangle>();
            
            this.index_buffer = new List<uint>();

            this.dome_indices = Dome_Indices;
            this.ostium_indices = Ostium_Indices;

            this.ostium_points_2D = new List<Vector3>();

            this.ostium_points_3D = new List<Vector3>();
            this.ostium_normals_3D = new List<Vector3>();

            this.dome_points_2D = new List<Vector3>();
            this.dome_points_3D = new List<Vector3>();

            this.is_sampled = Sampling;
            this.sample_indices = new List<int>();
            this.sample_positions = new List<Vector2>();

            this.transform_feedback_list = new List<float>();

            this.inital_vertex_region_ids = new int[this.mesh_vertices.Count];

            Initial_Vertex_Region_Ids.CopyTo(this.inital_vertex_region_ids);

            this.vertex_region_ids = Initial_Vertex_Region_Ids;

            this.brushed_reg_indices = new int[this.positions.Count];

            this.show_initial_brush = true;

            this.selected_colors = Init_Vertex_Region_Colors();

            this.isoline_lables = new uint[this.positions.Count * Utility.Num_Timesteps];

            this.cluster_values = new float[this.positions.Count * Utility.Num_Timesteps];

            this.sel_region_lables = new uint[this.positions.Count * Utility.Num_Timesteps];
            
            this.render_contour = true;

            this.render_iso_lines = false;

            //translationMatrix = Matrix4.CreateTranslation(new Vector3(-1.0f, -5f, 0f));

            //translationMatrix = Matrix4.Identity * translationMatrix;

            //this.transformationMatrix = this.transformationMatrix * translationMatrix;

            this.vao = new uint[1];
            this.vbo = new uint[this.number_vbo];
            this.ssbo = new uint[this.number_ssbo];

            this.Calculate_Least_Squares_Parametrization();

            this.Get_Map_Dimensions();
        }

        // Loaded map from File
        public Map(List<Triangle> MeshTriangles, List<Vector3> MeshVertices_3D, List<Vector3> MeshNormals, Dictionary<string, Unsteady_Datafield<float>> Map_Scalar_Info,
                   List<Triangle> MapTriangles, List<Vector3> MapVertices_2D, List<int> Dome_Indices, List<int> Ostium_Indices, bool Sampling, List<int> Initial_Vertex_Region_Ids)
            : base(Settings.Default.MapName)
        {
            this.mesh_triangles = MeshTriangles;
            this.mesh_vertices = MeshVertices_3D;
            this.mesh_normals = MeshNormals;
            this.scalar_data = Map_Scalar_Info;

            this.map_triangles_3D = new List<Triangle>();
            this.map_vertices_3D = new List<Vector3>();

            this.triangles = MapTriangles;
            this.positions = MapVertices_2D;
            this.is_aneurys_index = new int[this.positions.Count];
            this.index_buffer = new List<uint>();

            this.Get_Map_Dimensions();

            this.dome_indices = Dome_Indices;
            this.ostium_indices = Ostium_Indices;

            this.ostium_points_2D = new List<Vector3>();

            this.ostium_points_3D = new List<Vector3>();
            this.ostium_normals_3D = new List<Vector3>();

            this.Construct_Aneurysm_Ostium();

            this.inital_vertex_region_ids = new int[this.mesh_vertices.Count];

            Initial_Vertex_Region_Ids.CopyTo(this.inital_vertex_region_ids);

            this.vertex_region_ids = Initial_Vertex_Region_Ids;

            this.brushed_reg_indices = new int[this.positions.Count];

            this.show_initial_brush = true;

            this.selected_colors = Init_Vertex_Region_Colors();

            this.isoline_lables = new uint[this.positions.Count * Utility.Num_Timesteps];

            this.cluster_values = new float[this.positions.Count * Utility.Num_Timesteps];

            this.sel_region_lables = new uint[this.positions.Count * Utility.Num_Timesteps];

            this.render_iso_lines = false;

            this.dome_points_2D = new List<Vector3>();
            this.dome_points_3D = new List<Vector3>();

            this.is_sampled = Sampling;
            this.sample_indices = new List<int>();
            this.sample_positions = new List<Vector2>();

            this.transform_feedback_list = new List<float>();

            this.render_contour = true;

            //translationMatrix = Matrix4.CreateTranslation(new Vector3(-1.0f, -5f, 0f));

            //translationMatrix = Matrix4.Identity * translationMatrix;

            //this.transformationMatrix = this.transformationMatrix * translationMatrix;

            this.vao = new uint[1];
            this.vbo = new uint[this.number_vbo];
            this.ssbo = new uint[this.number_ssbo];
        }

        #endregion

        #region - Properties -

        public List<Triangle> Map_Triangles3D
        {
            get { return this.map_triangles_3D; }
            set { this.map_triangles_3D = value; }
        }

        public List<Triangle> Map_Triangles2D
        {
            get { return this.triangles; }
            set { this.triangles = value; }
        }

        public List<Vector3> Map_Vertices_2D
        {
            get { return this.positions; }
            set { this.positions = value; }
        }

        public List<Vector3> Map_Vertices_3D
        {
            get { return this.map_vertices_3D; }
            set { this.map_vertices_3D = value; }
        }

        public int[] Is_Aneurys_Index
        {
            get { return is_aneurys_index; }
            set { is_aneurys_index = value; }
        }

        public List<int> Dome_Indices
        {
            get { return this.dome_indices; }
            set { this.dome_indices = value; }
        }

        public List<int> Ostium_Indices
        {
            get { return this.ostium_indices; }
            set { this.ostium_indices = value; }
        }

        public List<Vector3> Ostium_Points_2D
        {
            get { return this.ostium_points_2D; }
            set { this.ostium_points_2D = value; }
        }

        public List<Vector3> Ostium_Points_3D
        {
            get { return this.ostium_points_3D; }
            set { this.ostium_points_3D = value; }
        }

        public List<Vector3> Ostium_Normals_3D
        {
            get { return this.ostium_normals_3D; }
            set { this.ostium_normals_3D = value; }
        }

        public Shader Transformfeedback_Shader
        {
            get { return this.transformfeedback_shader; }
            set { this.transformfeedback_shader = value; }
        }

        public float[] Brushed_Points
        {
            get { return this.brushed_map_points; }
            set { this.brushed_map_points = value; }
        }

        public List<float> TransformFeedbackList
        {
            get { return this.transform_feedback_list; }
            set { this.transform_feedback_list = value; }
        }

        public int[] Inital_Vertex_Region_IDs
        {
            get { return this.inital_vertex_region_ids; }
            set { this.inital_vertex_region_ids = value; }
        }

        public int[] Brushed_Region_Indices
        {
            get { return this.brushed_reg_indices; }
            set { this.brushed_reg_indices = value; }
        }

        public List<int> Vertex_Region_IDs
        {
            get { return this.vertex_region_ids; }
            set { this.vertex_region_ids = value; }
        }

        public List<Vector2> Sample_Positions
        {
            get { return this.sample_positions; }
            set { this.sample_positions = value; }
        }

        public Cylinder Map_Cylinder
        {
            get { return this.map_cylinder; }
            set { this.map_cylinder = value; }
        }

        public Plane Cylinder_Plane
        {
            get { return this.map_plane; }
            set { this.map_plane = value; }
        }

        public bool Render_Cont
        {
            get { return this.render_contour; }
            set { this.render_contour = value; }
        }

        public bool Render_IsoLines
        {
            get { return this.render_iso_lines; }
            set { this.render_iso_lines = value; }
        }

        public uint[] IsoLine_Lables
        {
            get { return this.isoline_lables; }
            set { this.isoline_lables = value; }
        }

        public float[] Cluster_Values
        {
            get { return this.cluster_values; }
            set { this.cluster_values = value; }
        }

        public bool Show_Initial_Brush
        {
            get { return this.show_initial_brush; }
            set { this.show_initial_brush = value; }
        }

        public float[] Selected_Colors
        {
            get { return this.selected_colors; }
            set { this.selected_colors = value; }
        }

        public Shader Isoline_Shader_Prog
        {
            get { return this.isoline_shader_prog; }
            set { this.isoline_shader_prog = value; }
        }

        #endregion

        #region - Methods -

        #region - Rendering -

        /// <summary>
        /// Proofs if the map is ready to render
        /// </summary>
        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            //if (this.contour_shader_prog == null)
            //{
            //    return false;
            //}

            //if (this.contour_shader_prog.Prog == 0)
            //{
            //    return false;
            //}

            return true;
        }

        /// <summary>
        /// Initializes all used VBO's and SSBO's
        /// </summary>
        public override void SetupRender()
        {
            if (this.show_initial_brush)
            {
                this.vertex_region_ids = this.inital_vertex_region_ids.ToList();

                this.selected_colors = Init_Vertex_Region_Colors();
            }

            this.shaderprog.Brushing_Colors = this.selected_colors;

            this.Convert_Scalar_Attributes_To_Lists();

            this.all_parameters = this.Convert_Scalar_Attributes_To_One_List();

            this.transform_feedback_list = this.Init_Transform_Feedback();

            this.Init_Transformfeedback_Shader();

            // Set number scalar fields
            this.shaderprog.Num_Scalar_Fields = this.scalar_data.Count;

            this.shaderprog.Item_Point_Number = this.positions.Count;

            // Set map dimensions
            this.shaderprog.Max_Map_Dim = this.max_dim;
            this.shaderprog.Min_Map_Dim = this.min_dim;

            GL.GenVertexArrays(1, out vao[0]);
            GL.BindVertexArray(vao[0]);

            // vbo [0] = position
            GL.GenBuffers(vbo.Length, vbo);
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Pos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.positions.Count * Vector3.SizeInBytes), this.positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = aneurysm indices
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.AneurysmIndex]);
            GL.BufferData(BufferTarget.ArrayBuffer, (IntPtr)(this.is_aneurys_index.Length * sizeof(int)), this.is_aneurys_index, BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 1, VertexAttribPointerType.Int, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            // vbo [2] = map index buffer
            this.index_buffer = this.Create_Index_Buffer(this.triangles);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
            GL.BufferData(BufferTarget.ElementArrayBuffer, (IntPtr)(this.index_buffer.Count * sizeof(uint)), this.index_buffer.ToArray(), BufferUsageHint.StaticDraw);
            //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

            // Generate SSBO's
            GL.GenBuffers(this.ssbo.Length, this.ssbo);

            // ssbo[0] = scalar_1
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.AllParam]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.all_parameters.Count * sizeof(float)), this.all_parameters.ToArray(), BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            //ssbo[1] = brushed vertices
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.TransformFeedback]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.transform_feedback_list.Count * sizeof(float)), this.transform_feedback_list.ToArray(), BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // ssbo[2] = cluster labels
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.Isolinedata]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.isoline_lables.Length * sizeof(uint)), this.isoline_lables, BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // ssbo[3] = cluster values
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.ClusterAVGValues]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.cluster_values.Length * sizeof(float)), this.cluster_values, BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // ssbo[4] = region selected
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.RegSel]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.sel_region_lables.Length * sizeof(uint)), this.sel_region_lables, BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // ssbo[5] = region selected
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.BrushedId]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.vertex_region_ids.Count * sizeof(int)), this.vertex_region_ids.ToArray(), BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // Unbind VAO
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);
            GL.BindVertexArray(0);

            // Init Contour Shader
            this.Init_Contour_Shader();

            // Init Cluster Rendering
            this.Init_Isoline_Shader();

            this.Init_Setup = true;

            Console.WriteLine("-> Map created");
        }

        /// <summary>
        /// Renders the map using triangles
        /// </summary>
        public override void Render()
        {
            if (!this.Renderable())
            {
                return;
            }

            this.Render_Map();

            if (this.map_ostium != null)
            {
                if (!this.map_ostium.Init_Setup || !this.map_ostium.Init_Shader)
                {
                    this.map_ostium.Initialize_Render_Item();
                }

                this.map_ostium.Render();
            }

            if (this.is_sampled)
            {
                if (this.map_cylinder != null)
                {
                    if (!this.map_cylinder.Init_Setup || !this.map_cylinder.Init_Shader)
                    {
                        this.map_cylinder.Initialize_Render_Item();

                        this.map_cylinder.ShaderProg.FST_Rendered_Prop = this.shaderprog.FST_Rendered_Prop;
                        this.map_cylinder.ShaderProg.Snd_Rendered_Prop = this.shaderprog.Snd_Rendered_Prop;
                        this.map_cylinder.ShaderProg.Max_Map_Dim = this.max_dim;
                        this.map_cylinder.ShaderProg.Min_Map_Dim = this.min_dim;
                        this.map_cylinder.ShaderProg.Fst_Rescale = this.shaderprog.Fst_Rescale;
                        this.map_cylinder.ShaderProg.Snd_Rescale = this.shaderprog.Snd_Rescale;
                    }

                    this.map_cylinder.Render();
                }

                if (this.map_plane != null)
                {
                    if (!this.map_plane.Init_Setup || !this.map_plane.Init_Shader)
                    {
                        this.map_plane.Initialize_Render_Item();

                        this.map_plane.ShaderProg.Max_Map_Dim = this.max_dim;
                        this.map_plane.ShaderProg.Min_Map_Dim = this.min_dim;
                    }

                    this.map_plane.Render();
                }
            }

            if (this.render_contour && !(this.render_iso_lines))
            {
                this.Render_Contour();
            }

            if (this.isoline_shader_prog != null && this.render_iso_lines)
            {
                this.Render_Iso_Lines();
            }
        }

        private void Render_Map()
        {
            // transformfeedback
            if (this.Transformfeedback_Shader.Brushing_On > 0)
            {
                this.transformfeedback_shader.EnableShader();
                {
                    GL.BindVertexArray(vao[0]);
                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);

                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.TransformFeedback, ssbo[(uint)SSBONames.TransformFeedback]);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.BrushedId, ssbo[(uint)SSBONames.BrushedId]);
                    {
                        GL.Enable(EnableCap.RasterizerDiscard);

                        GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
                    }
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.TransformFeedback, 0);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.BrushedId, 0);

                    int len = this.transform_feedback_list.Count;
                    this.brushed_map_points = new float[len];
                    this.brushed_reg_indices = new int[len];

                    //------------------------------------------------------------------------------------------------------------------------------

                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, ssbo[(uint)SSBONames.TransformFeedback]);

                    GL.GetBufferSubData(BufferTarget.ElementArrayBuffer, (IntPtr)0, (IntPtr)(len * sizeof(float)), this.brushed_map_points);

                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

                    //------------------------------------------------------------------------------------------------------------------------------

                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, ssbo[(uint)SSBONames.BrushedId]);

                    GL.GetBufferSubData(BufferTarget.ElementArrayBuffer, (IntPtr)0, (IntPtr)(len * sizeof(int)), this.brushed_reg_indices);

                    GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

                    //------------------------------------------------------------------------------------------------------------------------------

                    GL.BindVertexArray(0);

                    GL.Disable(EnableCap.RasterizerDiscard);
                }

                this.transformfeedback_shader.DisableShader(); 
            }
           
            this.shaderprog.EnableShader();
            {
                GL.BindVertexArray(vao[0]);
                GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);

                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.AllParam, ssbo[(uint)SSBONames.AllParam]);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.TransformFeedback, ssbo[(uint)SSBONames.TransformFeedback]);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.ClusterAVGValues, ssbo[(uint)SSBONames.ClusterAVGValues]);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.RegSel, ssbo[(uint)SSBONames.RegSel]);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.BrushedId, ssbo[(uint)SSBONames.BrushedId]);
                {
                    GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
                }
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.AllParam, 0);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.TransformFeedback, 0);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.ClusterAVGValues, 0);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.RegSel, 0);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.BrushedId, 0);

                GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

                GL.BindVertexArray(0);
            }

            this.shaderprog.DisableShader();
        }

        private void Render_Contour()
        {
            this.contour_shader_prog.EnableShader();
            {
                GL.BindVertexArray(vao[0]);

                GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);

                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.AllParam, ssbo[(uint)SSBONames.AllParam]);
                {
                    GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);
                }
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.AllParam, 0);

                GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

                GL.BindVertexArray(0);
            }
            this.contour_shader_prog.DisableShader();
        }

        private void Render_Iso_Lines()
        {
            this.isoline_shader_prog.EnableShader();
            {
                GL.BindVertexArray(vao[0]);

                GL.BindBuffer(BufferTarget.ElementArrayBuffer, this.vbo[(uint)VBONames.IndexBuffer]);
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.Isolinedata, ssbo[(uint)SSBONames.Isolinedata]);
                {
                    GL.LineWidth(4.0f);

                    GL.DrawElements(PrimitiveType.Triangles, this.index_buffer.Count, DrawElementsType.UnsignedInt, IntPtr.Zero);

                    GL.LineWidth(1.0f);
                }
                GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.Isolinedata, 0);
                GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

                GL.BindVertexArray(0);
            }

            this.isoline_shader_prog.DisableShader();
        }

        public override void Update_Render_Item_Shaders()
        {
            base.Update_Render_Item_Shaders();

            if (this.map_cylinder != null)
            {
                this.map_cylinder.Update_Render_Item_Shaders();

                this.map_cylinder.ShaderProg.Max_Map_Dim = this.max_dim;
                this.map_cylinder.ShaderProg.Min_Map_Dim = this.min_dim;
                this.map_cylinder.ShaderProg.Fst_Rescale = this.shaderprog.Fst_Rescale;
                this.map_cylinder.ShaderProg.Snd_Rescale = this.shaderprog.Snd_Rescale;
            }

            if (this.map_plane != null)
            {
                this.map_plane.Update_Render_Item_Shaders();

                this.map_plane.ShaderProg.Max_Map_Dim = this.max_dim;
                this.map_plane.ShaderProg.Min_Map_Dim = this.min_dim;
            }
        }

        public override void Update_Items_Shader_Variables()
        {
            base.Update_Items_Shader_Variables();

            this.shaderprog.Num_Scalar_Fields = this.scalar_data.Count;

            // Set map dimensions
            this.shaderprog.Max_Map_Dim = this.max_dim;
            this.shaderprog.Min_Map_Dim = this.min_dim;

            if (this.map_ostium != null)
            {
                this.map_ostium.Update_Render_Item_Shaders();
            }
        }

        public override void Update_Child_Render_Objects()
        {
            base.Update_Child_Render_Objects();

            if (this.map_cylinder!= null && this.map_cylinder.ShaderProg != null)
            {
                this.map_cylinder.ShaderProg.FST_Rendered_Prop = this.shaderprog.FST_Rendered_Prop;
                this.map_cylinder.ShaderProg.Snd_Rendered_Prop = this.shaderprog.Snd_Rendered_Prop;

                this.map_cylinder.ShaderProg.Max_Map_Dim = this.max_dim;
                this.map_cylinder.ShaderProg.Min_Map_Dim = this.min_dim;

                this.map_cylinder.ShaderProg.Fst_Rescale = this.shaderprog.Fst_Rescale;
                this.map_cylinder.ShaderProg.Snd_Rescale = this.shaderprog.Snd_Rescale;
            }

            if (this.map_plane != null && this.map_plane.ShaderProg != null)
            {
                this.map_plane.ShaderProg.Max_Map_Dim = this.max_dim;
                this.map_plane.ShaderProg.Min_Map_Dim = this.min_dim;
            }

            if (this.contour_shader_prog != null)
            {
                this.contour_shader_prog.Contour_Val = this.shaderprog.Contour_Val;
                this.contour_shader_prog.Snd_Rendered_Prop = this.shaderprog.Snd_Rendered_Prop;
                this.contour_shader_prog.Fst_Rescale = this.shaderprog.Fst_Rescale;
                this.contour_shader_prog.Snd_Rescale = this.shaderprog.Snd_Rescale;
            }

            if (this.shaderprog.Hatching_Active_Val > 0)
            {
                this.render_contour = true;
            }
            else
            {
                this.render_contour = false;
            }
        }

        public override void Convert_Scalar_Attributes_To_Lists()
        {
            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                if (kvp.Value.Data_Ordered.Count > 0)
                {
                    kvp.Value.Data_Ordered.Clear();
                }

                for (int i = 0; i < kvp.Value.Data_Unordered.Count; i++)
                {
                    for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
                    {
                        kvp.Value.Data_Ordered.Add(kvp.Value.Data_Unordered[i][j]);
                    }
                }
            }

            // normalization
            this.Normalize_Attribute_Lists();
        }

        private List<float> Init_Transform_Feedback()
        {
            List<float> values = new List<float>();

            if (this.brushed_map_points != null)
            {
                for (int i = 0; i < this.brushed_map_points.Length; i++)
                {
                    values.Add(brushed_map_points[i]);
                }
            }
            else
            {
                for (int i = 0; i < this.mesh_vertices.Count; i++)
                {
                    values.Add(0);
                }
            }

            return values;
        }

        public float[] Init_Vertex_Region_Colors()
        {
            float[] values = new float[Utility.Max_Region_Colors * 3];

            for (int i = 0, j = 0; i < Utility.Num_Regions; i++, j += 3)
            {
                values[j] = Utility.Initial_Brush_Region_Colors[i].X;
                values[j + 1] = Utility.Initial_Brush_Region_Colors[i].Y;
                values[j + 2] = Utility.Initial_Brush_Region_Colors[i].Z;
            }

            return values;
        }

        public void Set_Transform_Feedback_Input()
        {
            //GL.BindBuffer(BufferTarget.ElementArrayBuffer, ssbo[(uint)SSBONames.TransformFeedback]);

            //GL.BufferSubData(BufferTarget.ElementArrayBuffer, (IntPtr)0, (IntPtr)(this.transform_feedback_list.Count * sizeof(float)), this.transform_feedback_list.ToArray());

            //GL.BindBuffer(BufferTarget.ElementArrayBuffer, 0);

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.TransformFeedback]);

            GL.BufferSubData(BufferTarget.ShaderStorageBuffer, (IntPtr)0, (IntPtr)(this.transform_feedback_list.Count * sizeof(float)), this.transform_feedback_list.ToArray());

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);
        }

        public void Set_Region_Ids_Input()
        {
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.BrushedId]);

            GL.BufferSubData(BufferTarget.ShaderStorageBuffer, (IntPtr)0, (IntPtr)(this.vertex_region_ids.Count * sizeof(int)), this.vertex_region_ids.ToArray());

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);
        }

        public void Set_IsoLines_Input()
        {
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.Isolinedata]);

            GL.BufferSubData(BufferTarget.ShaderStorageBuffer, (IntPtr)0, (IntPtr)(this.isoline_lables.Length * sizeof(uint)), this.isoline_lables);

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);
        }

        public void ReSet_Region_Ids_Input()
        {
            this.vertex_region_ids = this.inital_vertex_region_ids.ToList();

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, ssbo[(uint)SSBONames.BrushedId]);

            GL.BufferSubData(BufferTarget.ShaderStorageBuffer, (IntPtr)0, (IntPtr)(this.vertex_region_ids.Count * sizeof(int)), this.vertex_region_ids.ToArray());

            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);
        }

        public void Init_Transformfeedback_Shader()
        {
            if (!(this.transformfeedback_shader == null))
            {
                return;
            }

            List<string> shaderpathes = new List<string>();

            string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + Settings.Default.TransformfeedbackPath;

            shaderpathes.Add(shaderpath + "transformfeed2D.vert");

            this.transformfeedback_shader = new Shader(shaderpathes);
        }

        public void Init_Contour_Shader()
        {
            List<string> shaderpathes = new List<string>();

            string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + @"Contour_2D\";

            shaderpathes.Add(shaderpath + "2_contour_2d.vert");
            shaderpathes.Add(shaderpath + "2_contour_2d.geom");
            shaderpathes.Add(shaderpath + "2_contour_2d.frag");

            this.contour_shader_prog = new Shader(shaderpathes);

            this.contour_shader_prog.Item_Point_Number = this.positions.Count;
            this.contour_shader_prog.Snd_Rendered_Prop = this.shaderprog.Snd_Rendered_Prop;
            this.contour_shader_prog.Contour_Val = this.shaderprog.Contour_Val;

            if (this.shaderprog.Hatching_Active_Val > 0)
            {
                this.render_contour = true;
            }
            else
            {
                this.render_contour = false;
            }
        }

        public void Init_Isoline_Shader()
        {
            List<string> shaderpathes = new List<string>();

            string shaderpath = Utility.Get_Relative_Project_Path() + Settings.Default.InitShaderPath + @"Isolines2D\";

            shaderpathes.Add(shaderpath + "2_isolines.vert");
            shaderpathes.Add(shaderpath + "2_isolines.geom");
            shaderpathes.Add(shaderpath + "2_isolines.frag");

            this.isoline_shader_prog = new Shader(shaderpathes);

            this.isoline_shader_prog.Item_Point_Number = this.positions.Count;
        }

        #endregion

        #region - Data Procesing - 

        /// <summary>
        /// Calculates the aneurysma flattening --> 2D points and ostium indices
        /// </summary>
        public void Calculate_Least_Squares_Parametrization()
        {
            ConformalMapping aneurysma_flat = new ConformalMapping();

            double[,] points = new double[3, this.mesh_vertices.Count];
            double[,] triangles = new double[3, this.mesh_triangles.Count];
            double[,] dome_ind = new double[1, this.dome_indices.Count];
            double[,] ostium_ind = new double[1, this.ostium_indices.Count + 1];

            for (int i = 0; i < this.mesh_vertices.Count; i++)
            {
                points.SetValue(mesh_vertices[i].X, 0, i);
                points.SetValue(mesh_vertices[i].Y, 1, i);
                points.SetValue(mesh_vertices[i].Z, 2, i);
            }

            //triangle indices müssen bei 1 beginnen, da matlab 1 basiert ist
            for (int i = 0; i < this.mesh_triangles.Count; i++)
            {
                triangles.SetValue(this.mesh_triangles[i].VIndex_0 + 1, 0, i);
                triangles.SetValue(this.mesh_triangles[i].VIndex_1 + 1, 1, i);
                triangles.SetValue(this.mesh_triangles[i].VIndex_2 + 1, 2, i);
            }

            for (int i = 0; i < this.dome_indices.Count; i++)
            {
                dome_ind.SetValue(this.dome_indices[i] + 1, 0, i);
            }

            for (int i = 0; i < this.ostium_indices.Count; i++)
            {
                ostium_ind.SetValue(this.ostium_indices[i] + 1, 0, i);
            }

            ostium_ind.SetValue(this.ostium_indices.First() + 1, 0, this.ostium_indices.Count);

            MWCellArray cellout2dmap = null;

            cellout2dmap = (MWCellArray)aneurysma_flat.Param_Conformal_Start((MWNumericArray)points, (MWNumericArray)triangles, (MWNumericArray)ostium_ind, (MWNumericArray)dome_ind);

            MWNumericArray flatten_points = (MWNumericArray)cellout2dmap[1];
            MWNumericArray triangulation = (MWNumericArray)cellout2dmap[2];
            MWNumericArray ostium_path = (MWNumericArray)cellout2dmap[3];
            MWNumericArray aneurysm_indices = (MWNumericArray)cellout2dmap[4];

            // Read 2D points and set height for cube calculation
            List<Vector2> points_flat = new List<Vector2>();
            points_flat.Capacity = flatten_points.Dimensions[1];

            Vector2 act_point = Vector2.Zero;
            double x = 0;
            double y = 0;

            // Read 2D map positions
            for (int i = 1; i <= flatten_points.Dimensions[1]; i++)
            {
                x = (double)flatten_points[1, i];
                y = (double)flatten_points[2, i];

                act_point = new Vector2((float)x, (float)y);
                points_flat.Add(act_point);
            }

            Vector2 center = this.Calculate_Center(points_flat);

            points_flat = this.Center_RenderItem(points_flat, center);

            Vector3 proj_point = Vector3.Zero;

            for (int i = 0; i < points_flat.Count; i++)
            {
                proj_point = new Vector3(points_flat[i].X, points_flat[i].Y, 0);

                this.positions.Add(proj_point);

                this.map_vertices_3D.Add(Vector3.Zero);
            }

            // Read 2D Cut Path
            //this.dome_points = this.Read_2D_Path(dome_path, points_flat);

            // Read 2D Ostium Path
            this.ostium_points_2D = this.Read_2D_Path(ostium_path, points_flat);

            double act_in_0 = 0;
            int act_index_0 = 0;

            this.ostium_indices.Clear();

            for (int i = 1; i <= ostium_path.Dimensions[1]; i++)
            {
                act_in_0 = (double)ostium_path[1, i];

                act_index_0 = (int)act_in_0 - 1;

                this.ostium_indices.Add(act_index_0);
            }

            this.Construct_Aneurysm_Ostium();

            // Read 3D ostium path
            this.ostium_points_3D = this.Read_3D_Path(ostium_path);
            this.ostium_normals_3D = this.Read_3D_Normals(ostium_path);

            // Read aneurysm indices
            List<int> aneurysm_ind = new List<int>();

            for (int i = 1; i <= aneurysm_indices.Dimensions[1]; i++)
            {
                act_in_0 = (double)aneurysm_indices[i, 1];

                act_index_0 = (int)act_in_0 - 1;

                aneurysm_ind.Add(act_index_0);
            }

            // Read 2D triangles
            double in_0 = 0;
            double in_1 = 0;
            double in_2 = 0;

            int index_0 = 0;
            int index_1 = 0;
            int index_2 = 0;

            Vector3 p_0_2d;
            Vector3 p_1_2d;
            Vector3 p_2_2d;

            Vector3 p_0_3d;
            Vector3 p_1_3d;
            Vector3 p_2_3d;

            Triangle tri2d, tri3d;

            Array triangulation_2D = triangulation.ToArray();

            for (int i = 0; i < triangulation_2D.GetLength(1); i++)
            {
                in_0 = (double)triangulation_2D.GetValue(0, i);
                in_1 = (double)triangulation_2D.GetValue(1, i);
                in_2 = (double)triangulation_2D.GetValue(2, i);

                index_0 = (int)in_0 - 1;
                index_1 = (int)in_1 - 1;
                index_2 = (int)in_2 - 1;

                p_0_2d = this.positions[index_0];
                p_1_2d = this.positions[index_1];
                p_2_2d = this.positions[index_2];

                p_0_3d = this.mesh_vertices[index_0];
                p_1_3d = this.mesh_vertices[index_1];
                p_2_3d = this.mesh_vertices[index_2];

                tri2d = new Triangle(0, index_0, index_1, index_2, index_0, index_1, index_2, index_0, index_1, index_2, p_0_2d, p_1_2d, p_2_2d);

                tri3d = new Triangle(0, index_0, index_1, index_2, index_0, index_1, index_2, index_0, index_1, index_2, p_0_3d, p_1_3d, p_2_3d);

                this.triangles.Add(tri2d);

                this.map_triangles_3D.Add(tri3d);
            }

            //Generate SSBO's Inputs
            this.transform_feedback_list = this.Init_Transform_Feedback();
        }

        private void Construct_Aneurysm_Ostium()
        {
            if (this.ostium_indices.Count < 1)
            {
                return;
            }

            List<Vector3> positions = new List<Vector3>();
            List<Vector3> normals = new List<Vector3>();

            for (int i = 0; i < this.ostium_indices.Count; i++)
            {
                positions.Add(this.positions[ostium_indices[i]]);

                normals.Add(Vector3.UnitZ);
            }

            this.map_ostium = new Ostium(positions, normals);

            this.map_ostium.Line_Width = 5.0f;
        }

        private void Construct_Aneurysm_Ostium(List<Vector3> ostium_positions, List<Vector3> ostium_colors)
        {
            List<Vector3> ostium_normals = new List<Vector3>();

            for (int i = 0; i < ostium_positions.Count; i++)
            {
                ostium_normals.Add(Vector3.UnitZ);
            }

            this.map_ostium = new Ostium(ostium_positions, ostium_normals, ostium_colors);

            this.map_ostium.Line_Width = 5.0f;
        }

        public void Get_Ostium_From_Map(out List<Vector3> all_ostium__colors)
        {
            List<int> bound_indices = this.Get_Boundary_Indices();

            List<Vector3> map_bound_points = this.Get_Map_Boundary_Points(bound_indices);
            List<Vector3> mesh_bound_points = this.Get_Mesh_Boundary_Points(bound_indices);

            List<Vector3> lower_map_border = new List<Vector3>();
            List<Vector3> top_map_border = new List<Vector3>();
            List<Vector3> sideborder_map_left = new List<Vector3>();
            List<Vector3> sideborder_map_right = new List<Vector3>();

            List<int> lower_map_border_ind = new List<int>();
            List<int> top_map_border_ind = new List<int>();
            List<int> sideborder_map_left_ind = new List<int>();
            List<int> sideborder_map_right_ind = new List<int>();

            this.Get_Boundary_Lists(map_bound_points, out lower_map_border, out top_map_border, out sideborder_map_left, out sideborder_map_right,
                                    bound_indices, out lower_map_border_ind, out top_map_border_ind, out sideborder_map_left_ind, out sideborder_map_right_ind);

            List<Vector3> sorted_map_lower_border = new List<Vector3>();
            List<Vector3> sorted_map_top_border = new List<Vector3>();
            List<Vector3> sorted_map_sideborder_left = new List<Vector3>();
            List<Vector3> sorted_map_sideborder_right = new List<Vector3>();

            List<int> sorted_map_lower_border_ind = new List<int>();
            List<int> sorted_map_top_border_ind = new List<int>();
            List<int> sorted_map_sideborder_left_ind = new List<int>();
            List<int> sorted_map_sideborder_right_ind = new List<int>();

            this.Sort_Point_List(lower_map_border, lower_map_border_ind, "x", out sorted_map_lower_border, out sorted_map_lower_border_ind);
            this.Sort_Point_List(top_map_border, top_map_border_ind, "x", out sorted_map_top_border, out sorted_map_top_border_ind);
            this.Sort_Point_List(sideborder_map_left, sideborder_map_left_ind, "Y", out sorted_map_sideborder_left, out sorted_map_sideborder_left_ind);
            this.Sort_Point_List(sideborder_map_right, sideborder_map_right_ind, "Y", out sorted_map_sideborder_right, out sorted_map_sideborder_right_ind);

            // reverse point listing
            sorted_map_top_border.Reverse();
            sorted_map_sideborder_left.Reverse();

            // reverse index listing
            sorted_map_top_border_ind.Reverse();
            sorted_map_sideborder_left_ind.Reverse();

            // Generate one point list
            List<Vector3> all_map_points = new List<Vector3>();
            List<int> all_map_indices = new List<int>();

            this.Generate_Ordered_Border_List(sorted_map_lower_border, all_map_points, sorted_map_lower_border_ind, all_map_indices);
            this.Generate_Ordered_Border_List(sorted_map_sideborder_right, all_map_points, sorted_map_sideborder_right_ind, all_map_indices);
            this.Generate_Ordered_Border_List(sorted_map_top_border, all_map_points, sorted_map_top_border_ind, all_map_indices);
            this.Generate_Ordered_Border_List(sorted_map_sideborder_left, all_map_points, sorted_map_sideborder_left_ind, all_map_indices);

            // color points
            List<Vector3> colors_lower_border_map = this.Color_Border_Points(sorted_map_lower_border, 0, 3);
            List<Vector3> colors_sideborder_right_map = this.Color_Border_Points(sorted_map_sideborder_right, 1, 3);
            List<Vector3> colors_top_border_map = this.Color_Border_Points(sorted_map_top_border, 2, 3);
            List<Vector3> colors_sideborder_left_map = this.Color_Border_Points(sorted_map_sideborder_left, 1, 3);

            // reverse color listing
            colors_sideborder_left_map.Reverse();

            List<Vector3> all_map__colors = new List<Vector3>();

            this.Generate_Ordered_Color_List(colors_lower_border_map, all_map__colors);
            this.Generate_Ordered_Color_List(colors_sideborder_right_map, all_map__colors);
            this.Generate_Ordered_Color_List(colors_top_border_map, all_map__colors);
            this.Generate_Ordered_Color_List(colors_sideborder_left_map, all_map__colors);

            all_ostium__colors = all_map__colors;

            this.ostium_indices = all_map_indices;

            this.Construct_Aneurysm_Ostium(all_map_points, all_map__colors);
        }

        private List<int> Get_Boundary_Indices()
        {
            double[,] triangles = new double[3, this.triangles.Count];

            //triangle indices müssen bei 1 beginnen, da matlab 1 basiert ist
            for (int i = 0; i < this.triangles.Count; i++)
            {
                triangles.SetValue(this.triangles[i].VIndex_0 + 1, 0, i);
                triangles.SetValue(this.triangles[i].VIndex_1 + 1, 1, i);
                triangles.SetValue(this.triangles[i].VIndex_2 + 1, 2, i);
            }

            MeshBoundary boundary = new MeshBoundary();

            MWNumericArray boundindices = (MWNumericArray)boundary.boundary((MWNumericArray)triangles);

            List<int> bindices = new List<int>();

            double index = 0;

            for (int i = 1; i <= boundindices.Dimensions[0]; i++)
            {
                index = (double)boundindices[i, 1] - 1;

                bindices.Add((int)index);
            }

            return bindices;
        }

        private List<Vector3> Get_Map_Boundary_Points(List<int> bound_indices)
        {
            List<Vector3> bound_points = new List<Vector3>();

            int act_index;

            for (int i = 0; i < bound_indices.Count; i++)
            {
                act_index = bound_indices[i];

                bound_points.Add(this.positions[act_index]);
            }

            return bound_points;
        }

        private List<Vector3> Get_Mesh_Boundary_Points(List<int> bound_indices)
        {
            List<Vector3> bound_points = new List<Vector3>();

            int act_index;

            for (int i = 0; i < bound_indices.Count; i++)
            {
                act_index = bound_indices[i];

                bound_points.Add(this.mesh_vertices[act_index]);
            }

            return bound_points;
        }

        private void Get_Boundary_Lists(List<Vector3> all_map_bound_points, out List<Vector3> lower_map_border, out List<Vector3> top_map__border, out List<Vector3> sideborder_map_left, out List<Vector3> sideborder_map_right,
                                        List<int> all_map_bound_indices, out List<int> lower_map_border_ind, out List<int> top_map_border_ind, out List<int> sideborder_map_left_ind, out List<int> sideborder_map_right_ind)
        {
            // on map
            lower_map_border = new List<Vector3>();
            top_map__border = new List<Vector3>();
            sideborder_map_left = new List<Vector3>();
            sideborder_map_right = new List<Vector3>();

            // on mesh
            lower_map_border_ind = new List<int>();
            top_map_border_ind = new List<int>();
            sideborder_map_left_ind = new List<int>();
            sideborder_map_right_ind = new List<int>();

            Vector2 mindim, maxdim;

            this.Get_Dimensions_Of_MapPoints(out mindim, out maxdim);

            float x, y;

            float y_offset_top = 1.0f;
            float y_offset_low = 1.5f;

            for (int i = 0; i < all_map_bound_points.Count; i++)
            {
                x = all_map_bound_points[i].X;
                y = all_map_bound_points[i].Y;

                if (y < (mindim.Y + y_offset_low))
                {
                    lower_map_border.Add(all_map_bound_points[i]);
                    lower_map_border_ind.Add(all_map_bound_indices[i]);
                }
                else if (y > (maxdim.Y - y_offset_top))
                {
                    top_map__border.Add(all_map_bound_points[i]);
                    top_map_border_ind.Add(all_map_bound_indices[i]);
                }
                else
                {
                    if (x < (maxdim.X / 2))
                    {
                        sideborder_map_left.Add(all_map_bound_points[i]);
                        sideborder_map_left_ind.Add(all_map_bound_indices[i]);
                    }
                    else
                    {
                        sideborder_map_right.Add(all_map_bound_points[i]);
                        sideborder_map_right_ind.Add(all_map_bound_indices[i]);
                    }
                }
            }
        }

        private void Sort_Point_List(List<Vector3> map_points, List<int> map_indices, string sort_dim, out List<Vector3> sorted_map_points, out List<int> sorted_map_indices)
        {
            sorted_map_points = new List<Vector3>();
            sorted_map_indices = new List<int>();

            List<float> sort_comp = new List<float>();

            if (sort_dim == "x" || sort_dim == "X")
            {
                for (int i = 0; i < map_points.Count; i++)
                {
                    sort_comp.Add(map_points[i].X);
                }
            }

            else if (sort_dim == "y" || sort_dim == "Y")
            {
                for (int i = 0; i < map_points.Count; i++)
                {
                    sort_comp.Add(map_points[i].Y);
                }
            }

            if (sort_dim == "z" || sort_dim == "Z")
            {
                for (int i = 0; i < map_points.Count; i++)
                {
                    sort_comp.Add(map_points[i].Z);
                }
            }

            int N = sort_comp.Count;

            int[] index = Enumerable.Range(0, N).ToArray<int>();

            Array.Sort<int>(index, (a, b) => sort_comp[a].CompareTo(sort_comp[b]));

            int act_insert_index;

            for (int i = 0; i < index.Length; i++)
            {
                act_insert_index = index[i];

                sorted_map_points.Add(map_points[act_insert_index]);
                sorted_map_indices.Add(map_indices[act_insert_index]); 
            }
        }

        private List<Vector3> Color_Border_Points(List<Vector3> map_points, int border_part, int num_border_parts) // borderpart start at 0
        {
            List<Vector3> map_colors = new List<Vector3>();

            Vector3[] bound_colors = new Vector3[]{
                                          new Vector3(0,0,108)/255f,
                                          new Vector3(0,30,135)/255f,
                                          new Vector3(0,88,176)/255f,
                                          new Vector3(0,141,170)/255f,
                                          new Vector3(29,185,90)/255f,
                                          new Vector3(133,204,7)/255f,
                                          new Vector3(216,192,0)/255f,
                                          new Vector3(250,151,14)/255f,
                                          new Vector3(250,63,67)/255f};

            int num_col_per_part = bound_colors.Length / num_border_parts;

            List<Vector3> act_used_colors = new List<Vector3>();

            int start_index = border_part * num_col_per_part;

            for (int i = start_index; i < (num_col_per_part + start_index); i++)
            {
                act_used_colors.Add(bound_colors[i]);
            }
         
            int num_points_per_color = map_points.Count/act_used_colors.Count;

            int col_index;

            for (int i = 0; i < map_points.Count; i++)
            {
                col_index = i / num_points_per_color;

                if (col_index < act_used_colors.Count)
                {
                    map_colors.Add(act_used_colors[col_index]);
                }
                else
                {
                    map_colors.Add(act_used_colors.Last());
                }
            }

            return map_colors;
        }

        private void Generate_Ordered_Border_List(List<Vector3> map_points, List<Vector3> all_map_points, List<int> map_indices, List<int> all_map_indices)
        {
            for (int i = 0; i < map_points.Count; i++)
            {
                all_map_points.Add(map_points[i]);
                all_map_indices.Add(map_indices[i]);
            }
        }

        private void Generate_Ordered_Color_List(List<Vector3> colors, List<Vector3> allcolors)
        {
            for (int i = 0; i < colors.Count; i++)
            {
                allcolors.Add(colors[i]);
            }
        }

        //public void Rescale_Scalar_Data_To_Aneurysm_Part()
        //{
        //    float min = float.MaxValue;
        //    float max = 0;

        //    float avg_val = 0;
        //    float counter = 0;

        //    foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
        //    {
        //        if (kvp.Value.Data_Ordered.Count > 0)
        //        {
        //            kvp.Value.Data_Ordered.Clear();
        //        }

        //        min = float.MaxValue;
        //        max = 0;

        //        avg_val = 0;
        //        counter = 0;

        //        for (int i = 0; i < kvp.Value.Data_Unordered.Count; i++)
        //        {
        //            for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
        //            {
        //                if (this.is_aneurys_index[j] == 1)
        //                {
        //                    kvp.Value.Data_Ordered.Add(kvp.Value.Data_Unordered[i][j]);

        //                    avg_val += kvp.Value.Data_Unordered[i][j];
        //                    counter++;

        //                    if (kvp.Value.Data_Unordered[i][j] < min)
        //                    {
        //                        min = kvp.Value.Data_Unordered[i][j];
        //                    }

        //                    if (kvp.Value.Data_Unordered[i][j] > max)
        //                    {
        //                        max = kvp.Value.Data_Unordered[i][j];
        //                    }
        //                }
        //                else
        //                {
        //                    kvp.Value.Data_Ordered.Add(float.MinValue);
        //                }
        //            }
        //        }

        //        kvp.Value.Min_Value = min;
        //        kvp.Value.Max_Value = max;
        //        kvp.Value.Avg_Value = avg_val / counter;

        //        this.Normalize_Attribute(kvp.Value.Data_Ordered, kvp.Value.Min_Value, kvp.Value.Max_Value);
        //    }

        //    this.all_parameters = this.Reorder_All_Attribute_List();
        //}

        //private List<float> Reorder_All_Attribute_List()
        //{
        //    List<float> values = new List<float>();

        //    foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
        //    {
        //        for (int i = 0; i < kvp.Value.Data_Ordered.Count; i++)
        //        {
        //            values.Add(kvp.Value.Data_Ordered[i]);
        //        }
        //    }

        //    return values;
        //}

        private List<Vector3> Read_2D_Path(MWNumericArray path, List<Vector2> points_flat)
        {
            double in_0 = 0;

            int index_0 = 0;

            float x = 0;
            float y = 0;

            List<Vector3> path_points = new List<Vector3>();
            Vector3 np = Vector3.Zero;

            for (int i = 1; i <= path.Dimensions[1]; i++)
            {
                in_0 = (double)path[1, i];

                index_0 = (int)in_0 - 1;

                x = points_flat[index_0].X;
                y = points_flat[index_0].Y;

                np = new Vector3(points_flat[index_0].X, points_flat[index_0].Y, 0);

                path_points.Add(np);
            }

            return path_points;
        }

        private List<Vector3> Read_3D_Path(MWNumericArray path)
        {
            double in_0 = 0;
            int index_0 = 0;

            List<Vector3> threed_points = new List<Vector3>();
            Vector3 np = Vector3.Zero;

            for (int i = 1; i <= path.Dimensions[1]; i++)
            {
                in_0 = (double)path[1, i];

                index_0 = (int)in_0 - 1;

                np = new Vector3(mesh_vertices[index_0].X, mesh_vertices[index_0].Y, mesh_vertices[index_0].Z);

                threed_points.Add(np);
            }

            return threed_points;
        }

        private List<Vector3> Read_3D_Normals(MWNumericArray path)
        {
            double in_0 = 0;

            int index_0 = 0;

            List<Vector3> threed_normals = new List<Vector3>();
            Vector3 np = Vector3.Zero;

            for (int i = 1; i <= path.Dimensions[1]; i++)
            {
                in_0 = (double)path[1, i];

                index_0 = (int)in_0 - 1;

                np = new Vector3(mesh_normals[index_0].X, mesh_normals[index_0].Y, mesh_normals[index_0].Z);

                threed_normals.Add(np);
            }

            return threed_normals;
        }

        private void Get_Map_Dimensions()
        {
            float xmax = 0;
            float ymax = 0;
            float xmin = float.MaxValue;
            float ymin = float.MaxValue;

            for (int i = 0; i < this.positions.Count; i++)
            {
                if (this.positions[i].X > xmax)
                {
                    xmax = this.positions[i].X;
                }
                if (this.positions[i].X < xmin)
                {
                    xmin = this.positions[i].X;
                }
                if (this.positions[i].Y > ymax)
                {
                    ymax = this.positions[i].Y;
                }
                if (this.positions[i].Y < ymin)
                {
                    ymin = this.positions[i].Y;
                }
            }


            this.max_dim = new Vector2(xmax, ymax);
            this.min_dim = new Vector2(xmin, ymin);
        }

        private void Get_Dimensions_Of_MapPoints(out Vector2 mindim, out Vector2 maxdim)
        {
            mindim = Vector2.Zero;
            maxdim = Vector2.Zero;

            float xmax = 0;
            float ymax = 0;
            float xmin = float.MaxValue;
            float ymin = float.MaxValue;

            int index0, index1, index2;

            for (int i = 0; i < this.triangles.Count; i++)
            {
                index0 = this.triangles[i].VIndex_0;
                index1 = this.triangles[i].VIndex_1;
                index2 = this.triangles[i].VIndex_2;

                if (this.positions[index0].X > xmax)
                {
                    xmax = this.positions[index0].X;
                }
                if (this.positions[index1].X > xmax)
                {
                    xmax = this.positions[index1].X;
                }
                if (this.positions[index2].X > xmax)
                {
                    xmax = this.positions[index2].X;
                }

                if (this.positions[index0].X < xmin)
                {
                    xmin = this.positions[index0].X;
                }
                if (this.positions[index1].X < xmin)
                {
                    xmin = this.positions[index1].X;
                }
                if (this.positions[index2].X < xmin)
                {
                    xmin = this.positions[index2].X;
                }

                if (this.positions[index0].Y > ymax)
                {
                    ymax = this.positions[index0].Y;
                }
                if (this.positions[index1].Y > ymax)
                {
                    ymax = this.positions[index1].Y;
                }
                if (this.positions[index2].Y > ymax)
                {
                    ymax = this.positions[index2].Y;
                }

                if (this.positions[index0].Y < ymin)
                {
                    ymin = this.positions[index0].Y;
                }
                if (this.positions[index1].Y < ymin)
                {
                    ymin = this.positions[index1].Y;
                }
                if (this.positions[index2].Y < ymin)
                {
                    ymin = this.positions[index2].Y;
                }
            }

            mindim = new Vector2(xmin, ymin);
            maxdim = new Vector2(xmax, ymax);
        }

        public void Update_Scalarfield(string attribute_field, List<List<float>> scalar_field_org, float min_val, float max_val)
        {
            this.scalar_data[attribute_field].Data_Ordered.Clear();

            this.scalar_data[attribute_field].Data_Unordered = scalar_field_org;

            float range = max_val - min_val;

            float val_sf = 0;

            for (int i = 0; i < this.scalar_data[attribute_field].Data_Unordered.Count; i++)
            {
                for (int j = 0; j < this.scalar_data[attribute_field].Data_Unordered[i].Count; j++)
                {
                    val_sf = this.scalar_data[attribute_field].Data_Unordered[i][j];

                    this.scalar_data[attribute_field].Data_Ordered.Add(val_sf);
                }
            }
        }

        public void Region_Analysis(int sel_id, string sel_sf)
        {
            double[,] triangles = new double[3, this.triangles.Count];

            //triangle indices müssen bei 1 beginnen, da matlab 1 basiert ist
            for (int i = 0; i < this.triangles.Count; i++)
            {
                triangles.SetValue(this.triangles[i].VIndex_0 + 1, 0, i);
                triangles.SetValue(this.triangles[i].VIndex_1 + 1, 1, i);
                triangles.SetValue(this.triangles[i].VIndex_2 + 1, 2, i);
            }

            double num_bins = 8;

            MWCellArray sclar_cell = new MWCellArray(1, Utility.Num_Timesteps);

            float act_scal;

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                double[,] scalar_values = new double[1, this.positions.Count];

                for (int j = 0; j < this.scalar_data[sel_sf].Data_Unordered[i].Count; j++)
                {
                    act_scal = this.scalar_data[sel_sf].Data_Unordered[i][j];

                    scalar_values.SetValue(act_scal, 0, j);
                }

                sclar_cell[1, i+1] = (MWNumericArray)scalar_values;
            }

            int act_time = (int)Shader.Ani_time;

            float min = Utility.norm_values[sel_sf].X;
            float max = Utility.norm_values[sel_sf].Y;

            // Caculate Connected Components
            CComponent reg_analysis = new CComponent();

            MWNumericArray region_labels = new MWNumericArray();

            region_labels = (MWNumericArray)reg_analysis.getConnectedComponent((MWNumericArray)(sel_id + 1), (MWNumericArray)(act_time + 1), (MWNumericArray)triangles, sclar_cell, (MWNumericArray)num_bins, (MWNumericArray)min, (MWNumericArray) max);

            double index = 0;
            int act_index = 0;

            for (int i = 1; i < region_labels.Dimensions[1]; i++)
            {
                index = (double)region_labels[1, i];

                act_index = (int)index;

                this.sel_region_lables[(i - 1)] = (uint)act_index;
            }

            this.Get_Statistical_Analysis();

            this.shaderprog.Sel_Val = (this.scalar_data[sel_sf].Data_Unordered[act_time][sel_id] - min)/(max-min);

            this.Init_Setup = false;
        }

        public void Cluster_Analysis(int sel_id, List<string> sel_sfields)
        {
            double[,] triangles = new double[3, this.triangles.Count];

            //triangle indices müssen bei 1 beginnen, da matlab 1 basiert ist
            for (int i = 0; i < this.triangles.Count; i++)
            {
                triangles.SetValue(this.triangles[i].VIndex_0 + 1, 0, i);
                triangles.SetValue(this.triangles[i].VIndex_1 + 1, 1, i);
                triangles.SetValue(this.triangles[i].VIndex_2 + 1, 2, i);
            }

            double num_bins = 8;

            MWCellArray sclar_cell = new MWCellArray(1, Utility.Num_Timesteps);

            float act_scal;

            int act_id;

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                double[,] scalar_values = new double[1, this.positions.Count];

                for (int j = 0; j < this.positions.Count; j++)
                {
                    act_id = (i * this.positions.Count) + j;

                    act_scal = this.cluster_values[act_id];

                    scalar_values.SetValue(act_scal, 0, j);
                }

                sclar_cell[1, i + 1] = (MWNumericArray)scalar_values;
            }

            int act_time = (int)Shader.Ani_time;

            float min = this.cluster_values.Min();
            float max = this.cluster_values.Max();

            // Caculate Connected Components
            CComponent reg_analysis = new CComponent();

            MWNumericArray region_labels = new MWNumericArray();

            region_labels = (MWNumericArray)reg_analysis.getConnectedComponent((MWNumericArray)(sel_id + 1), (MWNumericArray)(act_time + 1), (MWNumericArray)triangles, sclar_cell, (MWNumericArray)num_bins, (MWNumericArray)min, (MWNumericArray)max);

            double index = 0;
            int act_index = 0;

            for (int i = 1; i < region_labels.Dimensions[1]; i++)
            {
                index = (double)region_labels[1, i];

                act_index = (int)index;

                this.sel_region_lables[(i - 1)] = (uint)act_index;
            }

            this.Get_Statistical_Analysis(sel_sfields);

            act_id = (act_time * this.positions.Count) + sel_id;

            this.shaderprog.Sel_Val = this.cluster_values[act_id];

            this.Init_Setup = false;
        }

        private void Get_Statistical_Analysis()
        {
            MWCellArray sclar_cell = new MWCellArray(1, Utility.Num_Timesteps);

            int ns_counter = 0;

            int cellindex = 1;

            float act_scal;

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                double[,] scalar_values = new double[this.scalar_data.Count, this.positions.Count];

                foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
                {
                    for (int j = 0; j < kvp.Value.Data_Unordered[i].Count; j++)
                    {
                        act_scal = kvp.Value.Data_Unordered[i][j];

                        scalar_values.SetValue(act_scal, ns_counter, j);
                    }

                    ns_counter++;
                }

                sclar_cell[1, cellindex] = (MWNumericArray)scalar_values;

                ns_counter = 0;

                cellindex++;
            }

            cellindex = 1;

            MWCellArray sclar_names = new MWCellArray(1, this.scalar_data.Count);

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data)
            {
                sclar_names[1, cellindex] = (MWCharArray)kvp.Key.ToString();

                cellindex++;
            }

            cellindex = 1;

            MWCellArray time_vertices = new MWCellArray(1, Utility.Num_Timesteps);

            int act_id;

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                double[,] vertices = new double[1, mesh_vertices.Count];

                for (int j = 0; j < this.mesh_vertices.Count; j++)
                {
                    act_id = (i * this.mesh_vertices.Count) + j;

                    if (this.sel_region_lables[act_id] > 0)
                    {
                        vertices.SetValue(1, 0, j);
                    }
                    else
                    {
                        vertices.SetValue(0, 0, j);
                    }
                }

                time_vertices[1, cellindex] = (MWNumericArray)vertices;

                cellindex++;
            }

            Statistics st = new Statistics();

            st.getStatistics((MWCellArray)time_vertices, (MWCellArray)sclar_cell, (MWCellArray)sclar_names);
        }

        private void Get_Statistical_Analysis(List<string> sel_sfields)
        {
            List<int> sel_points = new List<int>();

            MWCellArray sclar_cell = new MWCellArray(1, Utility.Num_Timesteps);

            int ns_counter = 0;

            int cellindex = 1;

            float act_scal;

            int act_id;

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                double[,] scalar_values = new double[sel_sfields.Count, this.positions.Count];

                foreach (string item in sel_sfields)
                {
                    for (int j = 0; j < this.scalar_data[item].Data_Unordered[i].Count; j++)
                    {
                        act_id = (i * this.positions.Count) + j;

                        if (this.sel_region_lables[act_id] > 0)
                        {
                            act_scal = this.scalar_data[item].Data_Unordered[i][j];

                            if (!sel_points.Contains(j))
                            {
                                sel_points.Add(j);
                            }
                        }
                        else
                        {
                            act_scal = 0;
                        }

                        scalar_values.SetValue(act_scal, ns_counter, j);
                    }

                    ns_counter++;
                }

                sclar_cell[1, cellindex] = (MWNumericArray)scalar_values;

                ns_counter = 0;

                cellindex++;
            }

            cellindex = 1;

            MWCellArray sclar_names = new MWCellArray(1, sel_sfields.Count);

            for (int i = 0; i < sel_sfields.Count; i++)
            {
                sclar_names[1, cellindex] = (MWCharArray)sel_sfields[i];

                cellindex++;
            }
           
            double[,] vertices = new double[1, sel_points.Count];

            for (int i = 0; i < sel_points.Count; i++)
            {
                vertices.SetValue(sel_points[i] + 1, 0, i);
            }

            Statistics st = new Statistics();

            st.getStatistics((MWNumericArray)vertices, (MWCellArray)sclar_cell, (MWCellArray)sclar_names);
        }

        public void Update_Isoline_Data(int region_id) // region_id was added with 1 to avoid shader problems
        {
            uint regid = (uint)region_id;

            int counter = 0;

            int[] act_vertex_ids = new int[this.positions.Count];

            if (this.show_initial_brush)
            {
                act_vertex_ids = this.inital_vertex_region_ids;
            }
            else
            {
                act_vertex_ids = this.brushed_reg_indices;
            }

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                for (int j = 0; j < this.positions.Count; j++)
                {
                    if (act_vertex_ids[j] == (region_id - 1))
                    {
                        this.isoline_lables[counter] = regid;
                    }
                    else
                    {
                        this.isoline_lables[counter] = 0;
                    }

                    counter++;
                }
            }

            this.Set_IsoLines_Input();
        }

        public List<int> Generate_Quad_Shaped_Regions()
        {
            List<int> ids = new List<int>();

            for (int i = 0; i < this.positions.Count; i++)
            {
                ids.Add(-1);
            }

            Vector2 mindim, maxdim;

            this.Get_Dimensions_Of_MapPoints(out mindim, out maxdim);

            int index0, index1, index2;

            Vector3 act_point_0, act_point_1, act_point_2;

            int id0, id1, id2;

            float width = (maxdim.X - mindim.X);
            float height = (maxdim.Y - mindim.Y);

            for (int i = 0; i < this.triangles.Count; i++)
            {
                index0 = this.triangles[i].VIndex_0;
                index1 = this.triangles[i].VIndex_1;
                index2 = this.triangles[i].VIndex_2;

                act_point_0 = this.positions[index0];
                act_point_1 = this.positions[index1];
                act_point_2 = this.positions[index2];

                if (ids[index0] < 0)
                {
                    id0 = Get_Region_ID(act_point_0, mindim.X, width, mindim.Y, height);

                    ids[index0] = id0;
                }

                if (ids[index1] < 0)
                {
                    id1 = Get_Region_ID(act_point_1, mindim.X, width, mindim.Y, height);

                    ids[index1] = id1;
                }

                if (ids[index2] < 0)
                {
                    id2 = Get_Region_ID(act_point_2, mindim.X, width, mindim.Y, height);

                    ids[index2] = id2;
                }
            }

            return ids;
        }

        private int Get_Region_ID(Vector3 pos, float minx, float w, float miny, float h)
        {
            int id = -1;

            if (pos.X <= (minx+ (w/2)) && pos.Y <= (miny+(h/3)))
            {
                id = 0;
            }
            else if (pos.X <= (minx + (w / 2)) && pos.Y > (miny + (h/3)) && pos.Y <= (miny + 2*(h/3)))
            {
                id = 1;
            }
            else if (pos.X <= (minx + (w / 2)) && pos.Y > (miny + 2 * (h / 3)))
            {
                id = 2;
            }
            else if (pos.X > (minx + (w / 2)) && pos.Y <= (miny + (h / 3)))
            {
                id = 3;
            }

            else if (pos.X > (minx + (w / 2)) && pos.Y > (miny + (h / 3)) && pos.Y <= (miny + 2 * (h / 3)))
            {
                id = 4;
            }
            else
            {
                id = 5;
            }

            return id;
        }

        public List<int> Generate_Circular_Shaped_Regions()
        {
            List<int> ids = new List<int>();

            double[,] mesh_points = new double[3, this.mesh_vertices.Count];
            double[,] triangles = new double[3, this.triangles.Count];
            double[,] map_points = new double[2, this.positions.Count];

            for (int i = 0; i < this.mesh_vertices.Count; i++)
            {
                mesh_points.SetValue(this.mesh_vertices[i].X, 0, i);
                mesh_points.SetValue(this.mesh_vertices[i].Y, 1, i);
                mesh_points.SetValue(this.mesh_vertices[i].Z, 2, i);
            }

            for (int i = 0; i < this.triangles.Count; i++)
            {
                triangles.SetValue(this.triangles[i].VIndex_0 + 1, 0, i);
                triangles.SetValue(this.triangles[i].VIndex_1 + 1, 1, i);
                triangles.SetValue(this.triangles[i].VIndex_2 + 1, 2, i);
            }

            for (int i = 0; i < this.positions.Count; i++)
            {
                map_points.SetValue(this.positions[i].X, 0, i);
                map_points.SetValue(this.positions[i].Y, 1, i);
            }

            Regions aneurysm_regions = new Regions();

            MWNumericArray a_regions = (MWNumericArray)aneurysm_regions.getRegionIndices((MWNumericArray)mesh_points, (MWNumericArray)triangles, (MWNumericArray)map_points);

            double index = 0;

            for (int i = 1; i <= a_regions.Dimensions[1]; i++)
            {
                index = (double)a_regions[1, i] - 1;

                ids.Add((int)index);
            }

            return ids;
        }

        #endregion

        #region - Map Cylinder -

        public override void Sample_Map()
        {
            if (this.is_sampled)
            {
                Sampling map_samples = new Sampling();

                double[,] map_points = new double[2, this.positions.Count];
                double[,] triangles = new double[3, this.triangles.Count];
               
                for (int i = 0; i < this.positions.Count; i++)
                {
                    map_points.SetValue(this.positions[i].X, 0, i);
                    map_points.SetValue(this.positions[i].Y, 1, i);
                }

                 //triangle indices müssen bei 1 beginnen, da matlab 1 basiert ist
                for (int i = 0; i < this.triangles.Count; i++)
                {
                    triangles.SetValue(this.triangles[i].VIndex_0 + 1, 0, i);
                    triangles.SetValue(this.triangles[i].VIndex_1 + 1, 1, i);
                    triangles.SetValue(this.triangles[i].VIndex_2 + 1, 2, i);
                }

                MWCellArray celloutsamples = null;

                float percent_res = 12.0f;

                Vector2 mindim, maxdim;

                this.Get_Dimensions_Of_MapPoints(out mindim, out maxdim);

                //double x_res = (Math.Abs(this.max_dim.X - this.min_dim.X) * percent_res) / 100.0f;
                //double y_res = (Math.Abs(this.max_dim.Y - this.min_dim.Y) * percent_res) / 100.0f;
                double x_res = (Math.Abs(maxdim.X - mindim.X) * percent_res) / 100.0f;
                double y_res = (Math.Abs(maxdim.Y - mindim.Y) * percent_res) / 100.0f;

                double thres = -0.01;

                celloutsamples = (MWCellArray)map_samples.getSamplePoints((MWNumericArray)map_points, (MWNumericArray)triangles, (MWNumericArray)x_res, (MWNumericArray)y_res, (MWNumericArray)thres);
                //celloutsamples = (MWCellArray)map_samples.getSamplePoints((MWNumericArray)map_points, (MWNumericArray)triangles, (MWNumericArray)1, (MWNumericArray)1, (MWNumericArray)thres);
                MWNumericArray nrindex = (MWNumericArray)celloutsamples[1];
                MWNumericArray labels = (MWNumericArray)celloutsamples[2];
                MWNumericArray cpoints = (MWNumericArray)celloutsamples[3];

                List<int> newarest_indices = new List<int>();

                double index = 0;
                int act_index = 0;

                for (int i = 1; i <= nrindex.Dimensions[0]; i++)
                {
                    index = (double)nrindex[i, 1] - 1;

                    act_index = (int)index;

                    newarest_indices.Add(act_index);
                }

                List<Vector2> sam_pos = new List<Vector2>();
                Vector2 act_point = Vector2.Zero;
                double x = 0;
                double y = 0;

                for (int i = 1; i <= cpoints.Dimensions[1]; i++)
                {
                    x = (double)cpoints[1, i];
                    y = (double)cpoints[2, i];
                    act_point = new Vector2((float)x, (float)y);
                    sam_pos.Add(act_point);
                }

                List<int> new_indices = new List<int>();

                index = 0;
                act_index = 0;

                for (int i = 1; i <= labels.Dimensions[1]; i++)
                {
                    index = (double)labels[1, i] - 1;

                    act_index = (int)index;

                    new_indices.Add(act_index);
                }

                for (int i = 0; i < new_indices.Count; i++)
                {
                    act_index = new_indices[i];

                    this.sample_indices.Add(newarest_indices[act_index]);
                    this.sample_positions.Add(sam_pos[act_index]);
                }
               
                Utility.Map_Sample_Number = this.sample_positions.Count;

                Dictionary<string, Unsteady_Datafield<float>> cy_scal_data = this.Generate_Cylinder_Scalarfields();

                this.map_cylinder = new Cylinder(this.sample_positions, cy_scal_data);

                this.map_plane = new Plane(this.min_dim, this.max_dim, this.sample_positions.Count, this.sample_positions);
            }
        }

        //private void Sample_Map()
        //{
        //    if (this.is_sampled)
        //    {
        //        MapClustering.MapSampling map_samples = new MapClustering.MapSampling();

        //        List<Vector3> points = new List<Vector3>();

        //        for (int i = 0; i < this.mesh_vertices.Count; i++)
        //        {
        //            points.Add(Vector3.Zero);
        //        }

        //        for (int i = 0; i < this.triangles.Count; i++)
        //        {
        //            points[this.triangles[i].VIndex_0] = this.mesh_vertices[this.triangles[i].VIndex_0];
        //            points[this.triangles[i].VIndex_1] = this.mesh_vertices[this.triangles[i].VIndex_1];
        //            points[this.triangles[i].VIndex_2] = this.mesh_vertices[this.triangles[i].VIndex_2];
        //        }


        //        double[,] map_points = new double[3, this.positions.Count];
        //        double[,] triangles = new double[3, this.triangles.Count];
        //        double[,] scalarfield = new double[1, this.scalar_data.First().Value.Data_Unordered.First().Count];

        //        for (int i = 0; i < points.Count; i++)
        //        {
        //            map_points.SetValue(points[i].X, 0, i);
        //            map_points.SetValue(points[i].Y, 1, i);
        //            map_points.SetValue(points[i].Z, 2, i);
        //        }

        //        //triangle indices müssen bei 1 beginnen, da matlab 1 basiert ist
        //        for (int i = 0; i < this.triangles.Count; i++)
        //        {
        //            triangles.SetValue(this.triangles[i].VIndex_0 + 1, 0, i);
        //            triangles.SetValue(this.triangles[i].VIndex_1 + 1, 1, i);
        //            triangles.SetValue(this.triangles[i].VIndex_2 + 1, 2, i);
        //        }

        //        float val;

        //        for (int i = 0; i < this.scalar_data.First().Value.Data_Unordered.First().Count; i++)
        //        {
        //            val = this.scalar_data.First().Value.Data_Unordered.First()[i];

        //            scalarfield.SetValue(val, 0, i);
        //        }

        //        MWCellArray celloutsamples = null;

        //        celloutsamples = (MWCellArray)map_samples.getMeshCluster((MWNumericArray)map_points, (MWNumericArray)triangles, (MWNumericArray)scalarfield, (MWNumericArray)1000);

        //        MWNumericArray labels = (MWNumericArray)celloutsamples[1];
        //        MWNumericArray reps = (MWNumericArray)celloutsamples[2];

        //        Vector2 act_point = Vector2.Zero;
        //        double index = 0;
        //        float x = 0;
        //        float y = 0;

        //        for (int i = 1; i <= reps.Dimensions[1]; i++)
        //        {
        //            index = (double)reps[1, i] - 1;
        //            this.sample_indices.Add((int)index);

        //            x = this.positions[(int)index].X;
        //            y = this.positions[(int)index].Y;
        //            act_point = new Vector2(x, y);
        //            this.sample_positions.Add(act_point);
        //        }

        //        Utility.Map_Sample_Number = this.sample_positions.Count;

        //        Dictionary<string, Unsteady_Datafield<float>> cy_scal_data = this.Generate_Cylinder_Scalarfields();

        //        this.map_cylinder = new Cylinder(this.sample_positions, cy_scal_data);
        //    }
        //}

        private Dictionary<string, Unsteady_Datafield<float>> Generate_Cylinder_Scalarfields()
        {
            Dictionary<string, Unsteady_Datafield<float>> cy_scal_data = new Dictionary<string, Unsteady_Datafield<float>>();

            int actindex = 0;

            List<List<float>> scal_values_all_samples; // scalar values for one scalar field over time for all samples
            float act_scal_val = 0;

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.scalar_data) // current scalar field
            {
                scal_values_all_samples = new List<List<float>>();

                for (int i = 0; i < this.sample_indices.Count; i++) // current sample point
                {
                    actindex = this.sample_indices[i];

                    List<float> scal_values_sample = new List<float>(); // scalar values for one scalar field per sample over time

                    for (int j = 0; j < kvp.Value.Data_Unordered.Count; j++) // current time step
                    {
                        act_scal_val = kvp.Value.Data_Unordered[j][actindex];

                        scal_values_sample.Add(act_scal_val);
                    }

                    scal_values_all_samples.Add(scal_values_sample);
                }

                Unsteady_Datafield<float> field = new Unsteady_Datafield<float>(scal_values_all_samples);

                field.Max_Value = Utility.norm_values[kvp.Key].Y;
                field.Min_Value = Utility.norm_values[kvp.Key].X;

                cy_scal_data.Add(kvp.Key, field);
            }
         
            return cy_scal_data;
        }

        public void Add_Sample_Point(Vector3 near_point, Vector3 ray_dir)
        {
            Vector3 hit_point = Vector3.Zero;
            Vector3 hit_norm = Vector3.Zero;

            int index = this.Calculate_Picked_Triangle(near_point, ray_dir, out hit_point, out hit_norm);

            if (index != -1)
            {
                if (!this.sample_indices.Contains(index))
                {
                    this.sample_indices.Add(index);
                    this.sample_positions.Add(hit_point.Xy);

                    Utility.Map_Sample_Number = this.sample_positions.Count;

                    if (this.map_cylinder != null)
                    {
                        this.map_cylinder.Dispose();

                        this.map_cylinder = null;
                    }

                    Dictionary<string, Unsteady_Datafield<float>> cy_scal_data = this.Generate_Cylinder_Scalarfields();

                    this.map_cylinder = new Cylinder(this.sample_positions, cy_scal_data);

                    this.map_plane = new Plane(this.min_dim, this.max_dim, this.sample_positions.Count, this.sample_positions);
                }
            }
        }

        public void Get_Value_On_Click(Vector3 near_point, Vector3 ray_dir, string fst_sf, string snd_sf, out string fst_val, out string snd_val)
        {
            fst_val = "";
            snd_val = "";

            int act_time = (int)Shader.Ani_time;

            Vector3 hit_point = Vector3.Zero;
            Vector3 hit_norm = Vector3.Zero;

            int index = this.Calculate_Picked_Triangle(near_point, ray_dir, out hit_point, out hit_norm);

            if (index != -1)
            {
                if (this.scalar_data.ContainsKey(fst_sf))
                {
                    fst_val = string.Format("{0:F2}", this.scalar_data[fst_sf].Data_Unordered[act_time][index]);
                }
                if (this.scalar_data.ContainsKey(snd_sf))
                {
                    snd_val = string.Format("{0:F2}", this.scalar_data[snd_sf].Data_Unordered[act_time][index]);
                }
            }
        }

        #endregion

        #region - Interaction -

        public override int Calculate_Picked_Triangle(Vector3 P, Vector3 d, out Vector3 hit_point, out Vector3 hit_normal)
        {
            List<Triangle> intersected_Tri = this.Calculate_Ray_Intersection(P, d);

            if (!(intersected_Tri.Count > 0))
            {
                hit_point = Vector3.Zero;
                hit_normal = Vector3.Zero;

                return -1;
            }

            Triangle nearest_tri = intersected_Tri.First();

            if (this.Get_Nearest_Picked_Triangle(intersected_Tri, P, out nearest_tri))
            {
                float d0 = (P - this.positions[nearest_tri.VIndex_0]).LengthSquared;
                float d1 = (P - this.positions[nearest_tri.VIndex_1]).LengthSquared;
                float d2 = (P - this.positions[nearest_tri.VIndex_2]).LengthSquared;

                if (d0 <= d1 && d0 <= d2)
                {
                    hit_point = this.positions[nearest_tri.VIndex_0];
                    hit_normal = this.positions[nearest_tri.VIndex_0];

                    return nearest_tri.VIndex_0;
                }
                else if (d1 <= d0 && d1 <= d2)
                {
                    hit_point = this.positions[nearest_tri.VIndex_1];
                    hit_normal = this.positions[nearest_tri.VIndex_1];

                    return nearest_tri.VIndex_1;
                }
                else
                {
                    hit_point = this.positions[nearest_tri.VIndex_2];
                    hit_normal = this.positions[nearest_tri.VIndex_2];

                    return nearest_tri.VIndex_2;
                }
            }
            else
            {
                hit_point = Vector3.Zero;
                hit_normal = Vector3.Zero;

                return -1;
            }
        }

        private List<Triangle> Calculate_Ray_Intersection(Vector3 P, Vector3 d)
        {
            Vector3 u = Vector3.Zero;
            Vector3 v = Vector3.Zero;
            Vector3 w = Vector3.Zero;

            int index_0 = 0;
            int index_1 = 0;
            int index_2 = 0;

            List<Triangle> intersected_Tri = new List<Triangle>();

            for (int i = 0; i < this.triangles.Count; i++)
            {
                index_0 = this.triangles[i].VIndex_0;
                index_1 = this.triangles[i].VIndex_1;
                index_2 = this.triangles[i].VIndex_2;

                u = this.positions[index_1] - this.positions[index_0];
                v = this.positions[index_2] - this.positions[index_0];
                w = P - this.positions[index_0];

                Vector3 cross_dv = Vector3.Cross(d, v);
                Vector3 cross_wu = Vector3.Cross(w, u);

                float scalar_prod_u = Vector3.Dot(cross_dv, u);
                float scalar_prod_v = Vector3.Dot(cross_wu, v);
                float scalar_prod_w = Vector3.Dot(cross_dv, w);
                float scalar_prod_d = Vector3.Dot(cross_wu, d);

                Vector3 para_coords = (1.0f / scalar_prod_u) * new Vector3(scalar_prod_v, scalar_prod_w, scalar_prod_d);

                if (para_coords.Y >= 0.0f && para_coords.Y <= 1.0f && para_coords.Z >= 0.0f && para_coords.Z <= 1.0f && (para_coords.Y + para_coords.Z) <= 1.0f)
                {
                    intersected_Tri.Add(this.triangles[i]);
                }
            }

            return intersected_Tri;
        }

        private bool Get_Nearest_Picked_Triangle(List<Triangle> triangles, Vector3 Near_Plane, out Triangle nearest_tri)
        {
            float dist = float.MaxValue;
            float act_dist = 0;

            if (!(triangles.Count > 0))
            {
                nearest_tri = new Triangle(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Vector3.Zero, Vector3.Zero, Vector3.Zero);

                return false;
            }

            try
            {
                nearest_tri = triangles.First();

                for (int i = 0; i < triangles.Count; i++)
                {
                    act_dist = (triangles[i].Center - Near_Plane).Length;

                    if (act_dist < dist)
                    {
                        dist = act_dist;

                        nearest_tri = triangles[i];
                    }
                }

                return true;
            }
            catch (Exception)
            {
                nearest_tri = triangles.First();

                return false;
            }
        }

        //public void Calculate_Brushing_Area(float mouse_x, float mouse_y)
        //{
        //    float x = 0;
        //    float y = 0;
        //    float z = 0;

        //    for (int i = 0; i < this.positions.Count; i++)
        //    {
        //        Matrix4 modelviewproj = (Utility.Picking_Mat_Projection_2D * Utility.Picking_Mat_ModelView_2D);

        //        x = this.positions[i].X;
        //        y = this.positions[i].Y;
        //        z = this.positions[i].Z;

        //        Vector4 current_pos = new Vector4(x, y, z, 1.0f);

        //        Vector4 transfomed_pos = Vector4.Transform(current_pos, modelviewproj);
        //    }
        //}

        #endregion

        #region - Export -

        public override void Export_to_VTP(string path)
        {
            string file_dir = path + @"\mesh_info.txt";

            int numfiles = Utility.Num_Timesteps;

            string filename;

            using (StreamWriter sw = File.CreateText(file_dir))
            {
                for (int i = 0; i < numfiles; i++)
                {
                    filename = "Mesh_" + (i) + ".vtp";

                    sw.WriteLine(filename);
                }

                sw.Flush();

                sw.Close();
            }

            VTKWriter writer;

            for (int i = 0; i < numfiles; i++)
            {
                writer = new VTKWriter();

                filename = "Mesh_" + (i) + ".vtp";

                filename = path + @"\" + filename;

                writer.Save_PolyData(filename, this.triangles, this.positions, this, i);
            }
        }

        /// <summary>
        /// Write mesh to an OBJ-File
        /// </summary>
        public override void Export_to_OBJ(string path)
        {
            string file_dir = path + @"\mesh_info.txt";

            using (StreamWriter sw = File.CreateText(file_dir))
            {
                for (int i = 0; i < Utility.Num_Timesteps; i++)
                {
                    string filename = "Mesh_" + (i) + ".obj";

                    sw.WriteLine(filename);
                }

                sw.Flush();

                sw.Close();
            }

            for (int i = 0; i < Utility.Num_Timesteps; i++)
            {
                OBJWriter writer = new OBJWriter();

                string filename = @"\Mesh_" + (i) + ".obj";

                writer.Write_Mesh(path + filename, this.triangles, this.positions, this);
            }
        }

        #endregion

        #endregion

        #region IDisposable Member

        public override void Dispose()
        {
            base.Dispose();

            try
            {
                this.mesh_triangles = null;
                this.mesh_vertices = null;
                this.mesh_normals = null;

                this.map_triangles_3D = null;
                this.map_vertices_3D = null;

                this.triangles = null;

                this.scalar_data = null;
                this.all_parameters = null;

                this.index_buffer = null;
                this.dome_indices = null;
                this.ostium_indices = null;

                this.dome_points_2D = null;
                this.dome_points_3D = null;

                this.ostium_points_2D = null;
                this.ostium_points_3D = null;
            }
            catch (Exception)
            {
                Console.WriteLine("Exception for Map Dispositing");
            }
        }

        public override void Clear_Brushing()
        {
            this.Render_IsoLines = false;

            if (this.brushed_map_points != null && this.brushed_map_points.Length > 0)
            {
                for (int i = 0; i < this.brushed_map_points.Length; i++)
                {
                    this.brushed_map_points[i] = 0;
                }
            }

            if (this.transform_feedback_list != null && this.transform_feedback_list.Count > 0)
            {
                for (int i = 0; i < this.transform_feedback_list.Count; i++)
                {
                    this.transform_feedback_list[i] = 0;
                }
            }

            if (this.brushed_reg_indices != null && this.brushed_reg_indices.Length > 0)
            {
                for (int i = 0; i < this.brushed_reg_indices.Length; i++)
                {
                    this.brushed_reg_indices[i] = -1;
                }
            }

            if (this.vertex_region_ids != null && this.vertex_region_ids.Count > 0)
            {
                for (int i = 0; i < this.vertex_region_ids.Count; i++)
                {
                    this.vertex_region_ids[i] = -1;
                }
            }

            this.Update_Render_Item();
        }

        #endregion
    }
}
