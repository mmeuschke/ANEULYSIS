﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuroAnalytics
{
    public class TXTReader : Reader
    {
        #region - Private Variables -

        #endregion

        #region - Constructors -

        public TXTReader()
            : base("TXTReader")
        {

        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public override bool Load(string filename, bool first_timestep)
        {
            try
            {
                if (filename.Contains("Indices"))
                {
                    this.Read_Indices(filename);
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("## Error on Textfile Load: " + e.ToString());

                throw;
            }

            return true;
        }

        private void Read_Indices(string filename)
        {
            if (this.line_indices.Count > 0)
            {
                this.line_indices.Clear();
            }

            StreamReader file = new StreamReader(filename);

            string line;

            char[] splitChars = { ' ' };

            int val = 0;

            while (!file.EndOfStream)
            {
                line = file.ReadLine();

                string[] parameters = line.Split(splitChars, StringSplitOptions.RemoveEmptyEntries);

                if (parameters.Length > 0)
                {
                    val = int.Parse(parameters[0], Utility.NumberFormat);

                    this.line_indices.Add(val);
                }
            }
        }

        #endregion
    }
}
