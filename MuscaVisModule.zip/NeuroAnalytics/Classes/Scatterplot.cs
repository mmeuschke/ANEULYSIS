﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL;
using NeuroAnalytics.Properties;
using System.Drawing.Imaging;
using System.Drawing;
using OpenTK;

namespace NeuroAnalytics
{
    public class Scatterplot
    {
        #region - Private Variables -

        private Shader render_shader;
        private Shader brushing_shader;

        private uint textureimage3D;
        private uint textureimageBR3D;
        private uint textureimageBR2D;
        private uint textureimageBRMap;
        private uint textureimageHistoFstCase;

        private int texture_width;
        private int texture_height;
        private int default_size = 200;

        private int texture_histo_size;

        private uint[] texture_clear_data;
        private uint[] texture_render_data;

        private uint[] texture_histo_data_fst_case;

        private bool equalize_histo;
        private bool clear_textures;

        #endregion

        #region - Constructors -

        public Scatterplot()
        {
            this.texture_width = this.default_size;
            this.texture_height = this.default_size;

            this.Init_Histogramm_Data();

            this.equalize_histo = false;
            this.clear_textures = true;
        }

        #endregion

        #region - Properties -

        public Shader Render_Shader
        {
            get { return this.render_shader; }
            set { this.render_shader = value; }
        }

        public Shader Brushing_Shader
        {
            get { return this.brushing_shader; }
            set { this.brushing_shader = value; }
        }

        public int Default_Size
        {
            get { return this.default_size; }
            set { this.default_size = value; }
        }

        public int Texture_Width
        {
            get { return this.texture_width; }
            set { this.texture_width = value; }
        }

        public int Texture_Height
        {
            get { return this.texture_height; }
            set { this.texture_height = value; }
        }

        public bool Equalize_Histo
        {
            get { return this.equalize_histo; }
            set { this.equalize_histo = value; }
        }

        public bool Clear_Textures
        {
            get { return this.clear_textures; }
            set { this.clear_textures = value; }
        }

        public uint[] Texture_Histo_Data_First_Case
        {
            get { return this.texture_histo_data_fst_case; }
            set { 
                  this.texture_histo_data_fst_case = value;
                  this.texture_histo_size = this.texture_histo_data_fst_case.Length;
                }
        }

        //public uint[] Texture_Histo_Data_Snd_Case
        //{
        //    get { return this.texture_histo_data_snd_case; }
        //    set
        //    {
        //        this.texture_histo_data_snd_case = value;
        //        this.texture_histo_size = this.texture_histo_data_snd_case.Length;
        //    }
        //}

        #endregion

        #region - Methods -

        #region - Setup Textures -

        /// <summary>
        /// Clears texture with white
        /// </summary>   
        private void Init_Texture_Clear_Data()
        {
            this.texture_width = this.default_size * Utility.Num_Scalarfields;
            this.texture_height = this.default_size * Utility.Num_Scalarfields;

            this.texture_clear_data = new uint[this.texture_width * this.texture_height];
            this.texture_render_data = new uint[this.texture_width * this.texture_height];

            for (int i = 0; i < this.texture_clear_data.Length; i++)
            {
                this.texture_clear_data[i] = 0;

                this.texture_render_data[i] = 0;
            }
        }

        private void Init_Histogramm_Data()
        {
            this.texture_histo_size = (Utility.Max_Num_Hist * Utility.Num_Timesteps)*170;

            this.texture_histo_data_fst_case = new uint[this.texture_histo_size];
            //this.texture_histo_data_snd_case = new uint[this.texture_histo_size];

            for (int i = 0; i < this.texture_histo_size; i++)
            {
                this.texture_histo_data_fst_case[i] = 50;
                //this.texture_histo_data_snd_case[i] = 50;
            }
        }

        /// <summary>
        /// Initializes the buffer for scatterplot rendering
        /// </summary>     
        public void Setup_Textures()
        {
            this.Init_Texture_Clear_Data();

            GL.DeleteTextures(1, ref this.textureimage3D);
            GL.DeleteTextures(1, ref this.textureimageBR3D);

            // Density Plots Image
            GL.GenTextures(1, out this.textureimage3D);

            GL.BindTexture(TextureTarget.Texture2D, this.textureimage3D);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.R32f, this.texture_width, this.texture_height, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_clear_data);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Repeat);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Repeat);

            GL.BindImageTexture(3, this.textureimage3D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.BindTexture(TextureTarget.Texture2D, 0);

            // Brushing Image 3D to 2D
            GL.GenTextures(1, out this.textureimageBR3D);

            GL.BindTexture(TextureTarget.Texture2D, this.textureimageBR3D);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.R32f, this.texture_width, this.texture_height, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_clear_data);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Repeat);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Repeat);

            GL.BindImageTexture(4, this.textureimageBR3D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.BindTexture(TextureTarget.Texture2D, 0);

            // Brushing Image 2D to 3D
            GL.GenTextures(1, out this.textureimageBR2D);

            GL.BindTexture(TextureTarget.Texture2D, this.textureimageBR2D);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.R32f, this.texture_width, this.texture_height, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_clear_data);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Clamp);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Clamp);

            GL.BindImageTexture(5, this.textureimageBR2D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.BindTexture(TextureTarget.Texture2D, 0);

            // Brushing Image map to 3D and 2D
            GL.GenTextures(1, out this.textureimageBRMap);

            GL.BindTexture(TextureTarget.Texture2D, this.textureimageBRMap);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.R32f, this.texture_width, this.texture_height, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_clear_data);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Clamp);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Clamp);

            GL.BindImageTexture(6, this.textureimageBRMap, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.BindTexture(TextureTarget.Texture2D, 0);

            // Image for Histogramm Data of First Case
            GL.GenTextures(1, out this.textureimageHistoFstCase);

            GL.BindTexture(TextureTarget.Texture1D, this.textureimageHistoFstCase);

            GL.TexImage1D(TextureTarget.Texture1D, 0, PixelInternalFormat.R32f, this.texture_histo_size, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_histo_data_fst_case);

            GL.TexParameter(TextureTarget.Texture1D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
            GL.TexParameter(TextureTarget.Texture1D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);

            GL.TexParameter(TextureTarget.Texture1D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Clamp);
            GL.TexParameter(TextureTarget.Texture1D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Clamp);

            GL.BindImageTexture(7, this.textureimageHistoFstCase, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.BindTexture(TextureTarget.Texture1D, 0);

            // Shader
            List<string> renderpathes = new List<string>();

            // get relative path
            string projectPath = Utility.Get_Relative_Project_Path();

            renderpathes.Add(projectPath + Settings.Default.ScatterPlotVertRenderPath);
            renderpathes.Add(projectPath + Settings.Default.ScatterPlotFragRenderPath);

            this.render_shader = new Shader(renderpathes);

            this.render_shader.Scatter_Size = this.Default_Size * Utility.Num_Scalarfields;
            this.render_shader.Num_Scalar_Fields = Utility.Num_Scalarfields;

            renderpathes = new List<string>();
            renderpathes.Add(projectPath + Settings.Default.ScatterPlotVertBrushingPath);
            renderpathes.Add(projectPath + Settings.Default.ScatterPlotFragBrushingPath);

            this.brushing_shader = new Shader(renderpathes);

            this.brushing_shader.Scatter_Size = this.Default_Size * Utility.Num_Scalarfields;

            Console.WriteLine("# GL Error Check  : " + GL.GetError().ToString());
            Console.WriteLine("# Used Texture ID: {0}", this.textureimage3D);
        }

        #endregion

        #region - Rendering 

        /// <summary>
        /// Renders the texutre content
        /// </summary>
        public void RenderScatterplotBufferContent()
        {
            this.RenderBrushingplot();

            if (this.equalize_histo)
            {
                this.Equalize_Texture_Histogram();
            }

            this.RenderScatterplot();
        }

        private void RenderScatterplot()
        {
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();

            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadIdentity();

            // Draw Content of FBO
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            //Save_Scatterplot_Texture(@"C:\Users\Monique\Desktop\test.jpg", ImageFormat.Jpeg);

            GL.BindTexture(TextureTarget.Texture2D, this.textureimage3D);
            //GL.BindTexture(TextureTarget.Texture2D, this.textureimageMa);

            //GL.BindImageTexture(3, this.textureimage3D, 0, true, 0, TextureAccess.ReadWrite, SizedInternalFormat.Rgba32f);
            GL.BindImageTexture(3, this.textureimage3D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);
            GL.BindImageTexture(4, this.textureimageBR3D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);
            GL.BindImageTexture(5, this.textureimageBR2D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);
            GL.BindImageTexture(6, this.textureimageBRMap, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);
            GL.BindImageTexture(7, this.textureimageHistoFstCase, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.Enable(EnableCap.Blend);
            GL.BlendFunc(BlendingFactorSrc.SrcAlpha, BlendingFactorDest.OneMinusSrcAlpha);

            GL.Disable(EnableCap.DepthTest);

            this.render_shader.EnableShader();

            GL.DrawArrays(PrimitiveType.Quads, 0, 4);

            this.render_shader.DisableShader();

            GL.BindTexture(TextureTarget.Texture2D, 0);
            GL.BindTexture(TextureTarget.Texture1D, 0);

            GL.Disable(EnableCap.Blend);
            GL.Enable(EnableCap.DepthTest);
        }

        private void RenderBrushingplot()
        {
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();

            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadIdentity();

            // Draw Content of FBO
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            GL.BindTexture(TextureTarget.Texture2D, this.textureimageBR3D);

            GL.BindImageTexture(5, this.textureimageBR2D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            this.brushing_shader.EnableShader();

            GL.DrawArrays(PrimitiveType.Quads, 0, 4);

            this.brushing_shader.DisableShader();

            GL.BindTexture(TextureTarget.Texture2D, 0);
        }

        #endregion

        #region - Redraw -

        public virtual void Update_Shaders()
        {
            // Shader
            List<string> renderpathes = new List<string>();

            // get relative path
            string projectPath = Utility.Get_Relative_Project_Path();

            renderpathes.Add(projectPath + Settings.Default.ScatterPlotVertRenderPath);
            renderpathes.Add(projectPath + Settings.Default.ScatterPlotFragRenderPath);

            this.render_shader = new Shader(renderpathes);

            this.render_shader.Scatter_Size = this.Default_Size * Utility.Num_Scalarfields;
            this.render_shader.Num_Scalar_Fields = Utility.Num_Scalarfields;

            renderpathes = new List<string>();
            renderpathes.Add(projectPath + Settings.Default.ScatterPlotVertBrushingPath);
            renderpathes.Add(projectPath + Settings.Default.ScatterPlotFragBrushingPath);

            this.brushing_shader = new Shader(renderpathes);

            this.brushing_shader.Scatter_Size = this.Default_Size * Utility.Num_Scalarfields;
        }

        #endregion

        #region - Texture Manipulation

        public void Set_Brushing_Regions(int pos_x, int pos_y)
        {
            if (pos_x > -1 && pos_y > -1 && pos_x < this.texture_width && pos_y < this.texture_height)
            {
                this.brushing_shader.Brushed_Point = new Vector2(pos_x, this.texture_height - pos_y);
            }

            this.RenderScatterplotBufferContent();
        }

        public Vector2 Get_Scatterplot_Coordinates(int mouse_x, int mouse_y, int view_width, int view_height)
        {
            float actx = ((float)mouse_x / (float)view_width) * (float)this.texture_width;

            float acty = ((float)mouse_y / (float)view_height) * (float)this.texture_height;

            Vector2 scatterplot_pos = new Vector2(actx, acty);

            return scatterplot_pos;
        }

        private void Equalize_Texture_Histogram()
        {
            GL.BindTexture(TextureTarget.Texture2D, this.textureimage3D);
            GL.BindImageTexture(3, this.textureimage3D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.GetTexImage(TextureTarget.Texture2D, 0, OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_render_data);

            GL.BindTexture(TextureTarget.Texture2D, 0);

            List<uint> existent_values = new List<uint>();
            List<uint> sorted_values = new List<uint>();
            List<uint> counts = new List<uint>();
            List<uint> sum_values = new List<uint>();
            List<uint> equal_values = new List<uint>();

            int index = 0;

            for (int i = 0; i < this.texture_render_data.Length; i++)
            {
                if (this.texture_render_data[i] != 0)
                {
                    if (!existent_values.Contains(this.texture_render_data[i]))
                    {
                        existent_values.Add(this.texture_render_data[i]);
                        counts.Add(1);
                    }
                    else
                    {
                        index = existent_values.IndexOf(this.texture_render_data[i]);

                        counts[index]++;
                    }
                }
            }

            Console.WriteLine("Min: " + existent_values.Min());
            Console.WriteLine("Max: " + existent_values.Max());

            if (existent_values.Count < 1)
            {
                return;
            }

            existent_values.ForEach((item) =>
            {
                sorted_values.Add(item);
            });

            sorted_values.Sort();

            int ind_0;
            uint act_sum;

            for (int i = 0; i < sorted_values.Count; i++)
            {
                ind_0 = existent_values.IndexOf(sorted_values[i]);

                if (i == 0)
                {
                    sum_values.Add(counts[ind_0]);
                }
                else
                {
                    act_sum = sum_values.Last() + counts[ind_0];

                    sum_values.Add(act_sum);
                }
            }

            uint min = sum_values.Min();
            uint max = sum_values.Max();
            uint range = max-min;
            float fin_value;

            for (int i = 0; i < sum_values.Count; i++)
            {
                fin_value = 255.0f * (((float)sum_values[i] - (float)min) / (float)range);

                equal_values.Add((uint)fin_value);
            }

            int fin_index;

            for (int i = 0; i < this.texture_render_data.Length; i++)
            {
                if (existent_values.Contains(this.texture_render_data[i]))
                {
                    fin_index = sorted_values.IndexOf(this.texture_render_data[i]);

                    this.texture_render_data[i] = equal_values[fin_index];
                }
                else
                {
                    this.texture_render_data[i] = 500;
                }
            }

            GL.BindTexture(TextureTarget.Texture2D, this.textureimage3D);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.R32f, this.texture_width, this.texture_height, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_render_data);

            GL.BindImageTexture(3, this.textureimage3D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.BindTexture(TextureTarget.Texture2D, 0);

            this.equalize_histo = false;
        }

        #endregion

        #region - Clear -

        public void Clear_Texture_Buffers()
        {
            this.ClearScatterplotBufferContent();

            this.ClearBrushing3DBufferContent();
        }

        /// <summary>
        /// Clears the texture before the next render passes starts
        /// </summary>
        public void ClearScatterplotBufferContent()
        {
            if (this.clear_textures)
            {
                GL.BindTexture(TextureTarget.Texture2D, this.textureimage3D);

                GL.BindImageTexture(3, this.textureimage3D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

                GL.ClearTexImage(this.textureimage3D, 0, OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_clear_data);

                GL.BindTexture(TextureTarget.Texture2D, 0);
            }
        }

        private void ClearBrushing3DBufferContent()
        {
            GL.BindTexture(TextureTarget.Texture2D, this.textureimageBR3D);

            GL.BindImageTexture(4, this.textureimageBR3D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.ClearTexImage(this.textureimageBR3D, 0, OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_clear_data);

            GL.BindTexture(TextureTarget.Texture2D, 0);
        }

        public void ClearBrushing2DBufferContent()
        {
            GL.BindTexture(TextureTarget.Texture2D, this.textureimageBR2D);

            GL.BindImageTexture(5, this.textureimageBR2D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.ClearTexImage(this.textureimageBR2D, 0, OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_clear_data);

            GL.BindTexture(TextureTarget.Texture2D, 0);
        }

        public void ClearBrushingMapBufferContent()
        {
            GL.BindTexture(TextureTarget.Texture2D, this.textureimageBRMap);

            GL.BindImageTexture(6, this.textureimageBRMap, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.ClearTexImage(this.textureimageBRMap, 0, OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_clear_data);

            GL.BindTexture(TextureTarget.Texture2D, 0);
        }

        /// <summary>
        /// Delets the used textures for scatterplot rendering
        /// </summary>
        public void ClearBuffers()
        {
            GL.DeleteTextures(1, ref this.textureimage3D);
            GL.DeleteTextures(1, ref this.textureimageBR3D);
            GL.DeleteTextures(1, ref this.textureimageBR2D);
            GL.DeleteTextures(1, ref this.textureimageBRMap);
            GL.DeleteTextures(1, ref this.textureimageHistoFstCase);
            //GL.DeleteTextures(1, ref this.textureimageHistoSndCase);
        }

        #endregion

        #region - Export -

        public void Save_Scatterplot_Texture(string filename, ImageFormat format)
        {
            GL.BindTexture(TextureTarget.Texture2D, this.textureimage3D);
            GL.BindImageTexture(3, this.textureimage3D, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.GetTexImage(TextureTarget.Texture2D, 0, OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, this.texture_render_data);
            GL.BindTexture(TextureTarget.Texture2D, 0);

            Bitmap b_map = new Bitmap(this.texture_width, this.texture_height);

            Console.WriteLine(this.texture_render_data.Max());

            //int i = 0;
            //int j = 0;

            //int length = (this.texture_render_data.Length);

            //int r = 0;
            //int g = 0;
            //int b = 0;
            //int a = 0;

            //try
            //{
            //    for (int k = 0; k < length; k++)
            //    {
            //        j = k / this.texture_width;
            //        i = k % this.texture_height;

            //        j = (this.texture_height - 1) - j;

            //        //r = (int)(this.texture_render_data[k * 4] * 255);
            //        //g = (int)(this.texture_render_data[(k * 4) + 1] * 255);
            //        //b = (int)(this.texture_render_data[(k * 4) + 2] * 255);
            //        //a = (int)(this.texture_render_data[(k * 4) + 3] * 255);

            //        //r = (int)(this.texture_render_data[k] * 255);
            //        r = (int)(this.texture_render_data[k]);
            //        //g = (int)(this.texture_render_data[(k) + 1] * 255);
            //        //b = (int)(this.texture_render_data[(k) + 2] * 255);
            //        //a = (int)(this.texture_render_data[(k) + 3] * 255);

            //        if (r < 1)
            //        {
            //            b_map.SetPixel(i, j, Color.FromArgb(255, 255, 255, 255));
            //        }
            //        else
            //        {
            //            r = 255;

            //            b_map.SetPixel(i, j, Color.FromArgb(255, r, 0, 0));
            //        }

            //    }

            //    b_map.Save(filename, format);
            //}
            //catch (Exception e)
            //{

            //    Console.WriteLine(e);
            //}
        }

        #endregion

        #endregion
    }
}
