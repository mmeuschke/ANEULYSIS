﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NeuroAnalytics.Properties;
using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace NeuroAnalytics
{
    public class Plane : RenderItem
    {
        #region - Private Variables -

        private int number_planes;

        private List<Vector2> planes_Pos;

        private List<Vector2> texture_coords;

        // VBO Initialization
        private enum VBONames { Pos, TexCoords };

        private int number_vbo = Enum.GetNames(typeof(VBONames)).Length;

        // SSBO Initialization
        private enum SSBONames { PlanesPos };

        private int number_ssbo = Enum.GetNames(typeof(SSBONames)).Length;

        // SSBO Inputs
        private List<float> planes_pos;

        #endregion

        #region - Constructors -

        public Plane(Vector2 MinDim, Vector2 MaxDim, int numberPos, List<Vector2> Plane_Positions)
            : base(Settings.Default.PlaneName)
        {
            this.texture_coords = new List<Vector2>();
            this.positions = this.Init_Plane_Positions(MinDim, MaxDim);
            this.number_planes = numberPos;
            this.planes_Pos = Plane_Positions;
            this.planes_pos = new List<float>();

            this.vao = new uint[1];
            this.vbo = new uint[this.number_vbo];
            this.ssbo = new uint[this.number_ssbo];

            this.Generate_SSBO_Inputs();
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public override bool Renderable()
        {
            if (this.vao == null)
            {
                return false;
            }

            if (this.shaderprog == null)
            {
                return false;
            }

            if (this.shaderprog.Prog == 0)
            {
                return false;
            }

            if (this.hide_rendering)
            {
                return false;
            }

            return true;
        }

        public override void SetupRender()
        {
            GL.GenVertexArrays(1, out vao[0]);
            GL.BindVertexArray(vao[0]);

            // vbo [0] = position
            GL.GenBuffers(vbo.Length, vbo);
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.Pos]);
            GL.BufferData<Vector3>(BufferTarget.ArrayBuffer, (IntPtr)(this.positions.Count * Vector3.SizeInBytes), this.positions.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(0);

            // vbo [1] = tex coords
            GL.BindBuffer(BufferTarget.ArrayBuffer, this.vbo[(uint)VBONames.TexCoords]);
            GL.BufferData<Vector2>(BufferTarget.ArrayBuffer, (IntPtr)(this.texture_coords.Count * Vector2.SizeInBytes), this.texture_coords.ToArray(), BufferUsageHint.StaticDraw);

            GL.VertexAttribPointer(1, 2, VertexAttribPointerType.Float, false, 0, 0);
            GL.EnableVertexAttribArray(1);

            //-----------------------------------------------------------------------------------------------------------------------------------------------------------

            // Generate SSBO's
            GL.GenBuffers(this.ssbo.Length, this.ssbo);

            // ssbo[0] = cylinder positions
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, this.ssbo[(uint)SSBONames.PlanesPos]);
            GL.BufferData(BufferTarget.ShaderStorageBuffer, (IntPtr)(this.planes_pos.Count * sizeof(float)), this.planes_pos.ToArray(), BufferUsageHint.DynamicDraw);
            GL.BindBuffer(BufferTarget.ShaderStorageBuffer, 0);

            // Unbind VAO
            GL.BindBuffer(BufferTarget.ArrayBuffer, 0);

            GL.BindVertexArray(0);

            this.Init_Setup = true;

            Console.WriteLine("-> Plane created");

        }

        public override void Render()
        {
            if (!Renderable())
            {
                return;
            }

            GL.PushMatrix();
            {
                this.shaderprog.EnableShader();
                {
                    GL.BindVertexArray(vao[0]);
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, 0, ssbo[(uint)SSBONames.PlanesPos]);
                    {
                        // #Primitives x #Points per Primitive
                        GL.DrawArraysInstanced(PrimitiveType.Quads, 0, 4, this.number_planes);
                    }
                    GL.BindBufferBase(BufferRangeTarget.ShaderStorageBuffer, (uint)SSBONames.PlanesPos, 0);
                    GL.BindVertexArray(0);
                }
                this.shaderprog.DisableShader();
            }
            GL.PopMatrix();;
        }

        private void Generate_SSBO_Inputs()
        {
            this.planes_pos = new List<float>();

            for (int i = 0; i < this.planes_Pos.Count; i++)
            {
                this.planes_pos.Add(this.planes_Pos[i].X);
                this.planes_pos.Add(this.planes_Pos[i].Y);
            }
        }

        private List<Vector3> Init_Plane_Positions(Vector2 mindim, Vector2 maxdim)
        {
            List<Vector3> positions = new List<Vector3>();

            float pos = 0.4f;

            positions.Add(new Vector3(-pos, -pos, 0.0f)); // left,front
            positions.Add(new Vector3(-pos, pos, 0.0f)); // left, back
            positions.Add(new Vector3(pos, pos, 0.0f)); // right, back
            positions.Add(new Vector3(pos, -pos, 0.0f)); // right front

            this.texture_coords.Add(new Vector2(-1f, -1f));
            this.texture_coords.Add(new Vector2(-1f, 1f));
            this.texture_coords.Add(new Vector2(1f, 1f));
            this.texture_coords.Add(new Vector2(1f, -1f));

            //positions.Add(new Vector3(mindim.X, mindim.Y, 0.0f)); // left,front
            //positions.Add(new Vector3(mindim.X, maxdim.Y, 0.0f)); // left, back
            //positions.Add(new Vector3(maxdim.X, maxdim.Y, 0.0f)); // right, back
            //positions.Add(new Vector3(maxdim.X, mindim.Y, 0.0f)); // right front

            return positions;
        }

        #endregion

    }
}
