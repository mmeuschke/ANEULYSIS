﻿using OpenTK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NeuroAnalytics
{
    public abstract class Writer : IDisposable
    {
        #region - Private Variables -

        #endregion

        #region - Constructors -

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public abstract void Write_Lines(string path, string filename, List<List<uint>> lines_indices, List<Vector3> positions, List<float> scalar_value, RenderItem rend_item);

        public abstract void Write_Mesh(string path, List<Triangle> faces, List<Vector3> positions, RenderItem rend_item);

        #endregion

        public void Dispose()
        {
        }
    }
}
