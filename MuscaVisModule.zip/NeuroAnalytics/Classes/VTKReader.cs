﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kitware.VTK;
using OpenTK;
using NeuroAnalytics.Properties;

namespace NeuroAnalytics
{
    public class VTKReader : Reader
    {
        #region - Private Variables -

        #endregion

        #region - Constructors -

        public VTKReader()
            : base("VTKReader")
        {
        }

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public override bool Load(string filename, bool first_timestep)
        {
            try
            {
                if (filename.EndsWith(".vtp"))
                {
                    this.Read_Poly_Data_File(filename, first_timestep);
                }
                else if (filename.EndsWith(".vtu"))
                {
                    this.Read_Unstructured_Grid_File(filename, first_timestep);
                }
                else if (filename.EndsWith(".vtk"))
                {
                    this.Read_Unstructured_Grid_File(filename, first_timestep);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("## Error on VTK Load: " + e.ToString());

                throw;
            }

            return true;
        }

        public override bool Load(string filename, bool first_timestep, int timesteps, int act_time)
        {
            try
            {
                if (filename.EndsWith(".vtp"))
                {
                    this.Read_Poly_Data_File(filename, first_timestep, timesteps, act_time);
                }
                else if (filename.EndsWith(".vtu"))
                {
                    this.Read_Unstructured_Grid_File(filename, first_timestep, timesteps, act_time);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("## Error on VTK File Load: " + e.ToString());

                throw;
            }

            return true;
        }

        private bool Read_Poly_Data_File(string filename, bool time_dep_line_data)
        {
            //Initalize VTK Reader
            vtkXMLPolyDataReader reader = new vtkXMLPolyDataReader();

            reader.SetFileName(filename);

            reader.Update();

            vtkPolyData polydata = reader.GetOutput();

            if (polydata == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid Poly data Input");

                return false;
            }

            // Read Point Coordinates
            int numPoints = (int)polydata.GetNumberOfPoints();

            if (numPoints != 0)
            {
                if (time_dep_line_data)
                {
                    double[] pt;

                    for (int i = 0; i < numPoints; i++)
                    {
                        pt = polydata.GetPoint(i);

                        this.positions.Add(new Vector3((float)pt[0], (float)pt[1], (float)pt[2]));
                    }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("---------------No Points existent");
            }

            // Read Point Indices
            int numpolydatacells = (int)polydata.GetNumberOfCells();

            vtkCell polydataCell;
            vtkIdList pts;

            if (numpolydatacells != 0)
            {
                if (time_dep_line_data)
                {
                    int counter = 0;

                    for (int i = 0; i < numpolydatacells; i++)
                    {
                        polydataCell = polydata.GetCell((long)i);

                        int numCellPoints = (int)polydataCell.GetNumberOfPoints();

                        if (numCellPoints == 3)
                        {
                            pts = polydataCell.GetPointIds();

                            this.Get_Triangle(counter, pts);

                            counter++;
                        }
                    }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("---------------No Triangles existent");
            }

            // Read point data
            vtkPointData pointData = polydata.GetPointData();

            // Load point attributes
            this.Load_Point_Attributes(pointData);

            //vtkCellDataToPointData data = new vtkCellDataToPointData();
            //data.SetInput(polydata);
            //data.PassCellDataOn();
            //data.Update();

            //vtkPolyData test = data.GetPolyDataOutput();

            //vtkPointData testData = test.GetPointData();

            //// Load point attributes
            //this.Load_Point_Attributes(testData);


            // Caculate normals
            if (this.vector_data.ContainsKey("Normals"))
            {
                this.normals = this.vector_data["Normals"].Data_Unordered[0];

                this.vector_data.Remove("Normals");
            }
            else
            {
                this.Calculate_Triangle_Normals_per_Vertex(time_dep_line_data);
            }

            this.Add_Artificial_Time_Points();

            return true;
        }

        private bool Read_Poly_Data_File(string filename, bool first_timestep, int timesteps, int act_time)
        {
            //Initalize VTK Reader
            vtkXMLPolyDataReader reader = new vtkXMLPolyDataReader();

            reader.SetFileName(filename);

            reader.Update();

            vtkPolyData polydata = reader.GetOutput();

            if (polydata == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid Poly data Input");

                return false;
            }

            // Read Point Coordinates
            int numPoints = (int)polydata.GetNumberOfPoints();

            if (numPoints != 0)
            {
                if (first_timestep)
                {
                    double[] pt;

                    for (int i = 0; i < numPoints; i++)
                    {
                        pt = polydata.GetPoint(i);

                        this.positions.Add(new Vector3((float)pt[0], (float)pt[1], (float)pt[2]));
                    }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("---------------No Points existent");
            }

            // Read Point Indices
            int numpolydatacells = (int)polydata.GetNumberOfCells();

            vtkCell polydataCell;
            vtkIdList pts;

            if (numpolydatacells != 0)
            {
                if (first_timestep)
                {
                    int counter = 0;

                    for (int i = 0; i < numpolydatacells; i++)
                    {
                        polydataCell = polydata.GetCell((long)i);

                        int numCellPoints = (int)polydataCell.GetNumberOfPoints();

                        if (numCellPoints == 3)
                        {
                            pts = polydataCell.GetPointIds();

                            this.Get_Triangle(counter, pts);

                            counter++;
                        }
                    }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("---------------No Triangles existent");
            }

            // Read point data
            vtkPointData pointData = polydata.GetPointData();

            // Load point attributes
            this.Load_Point_Attributes(pointData, timesteps, act_time);

            if (this.vector_data.ContainsKey("Normals"))
            {
                this.normals = this.vector_data["Normals"].Data_Unordered[0];

                this.vector_data.Remove("Normals");
            }
            else
            {
                this.Calculate_Triangle_Normals_per_Vertex(first_timestep);
            }

            return true;
        }

        private void Read_Unstructured_Grid_File(string filename, bool first_timestep)
        {
            // Initalize VTK Reader
            vtkXMLUnstructuredGridReader reader = new vtkXMLUnstructuredGridReader();

            reader.SetFileName(filename);

            reader.Update();

            vtkUnstructuredGrid grid = reader.GetOutput();

            // Read Point Coordinates
            vtkPoints points = grid.GetPoints();

            int numPoints = (int)points.GetNumberOfPoints();

            if (numPoints != 0)
            {
                if (first_timestep)
                {
                    // Read Point Data
                    double[] pt;

                    for (int i = 0; i < numPoints; i++)
                    {
                        pt = points.GetPoint(i);

                        this.positions.Add(new Vector3((float)pt[0], (float)pt[1], (float)pt[2]));
                    }

                    // Read Triangle Data
                    vtkCellArray triangleCells = grid.GetCells();

                    this.Read_Triangles(triangleCells);
                }
            }

            vtkPointData pointData = grid.GetPointData();

            // Load point attributes
            this.Load_Point_Attributes(pointData);

            // Caculate normal per vertex
            this.Calculate_Triangle_Normals_per_Vertex(first_timestep);
        }

        private void Read_Unstructured_Grid_File(string filename, bool first_timestep, int timesteps, int act_time)
        {
            // Initalize VTK Reader
            vtkXMLUnstructuredGridReader reader = new vtkXMLUnstructuredGridReader();

            reader.SetFileName(filename);

            reader.Update();

            vtkUnstructuredGrid grid = reader.GetOutput();

            // Read Point Coordinates
            vtkPoints points = grid.GetPoints();

            int numPoints = (int)points.GetNumberOfPoints();

            List<Vector3> point_dat = new List<Vector3>();

            if (numPoints != 0)
            {
                if (first_timestep)
                {
                    // Read Point Data
                    double[] pt;

                    for (int i = 0; i < numPoints; i++)
                    {
                        pt = points.GetPoint(i);

                        this.positions.Add(new Vector3((float)pt[0], (float)pt[1], (float)pt[2]));
                    }

                    // Read Triangle Data
                    vtkCellArray triangleCells = grid.GetCells();

                    this.Read_Triangles(triangleCells);
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("---------------No Points existent");
            }

            vtkPointData pointData = grid.GetPointData();

            // Load point attributes
            this.Load_Point_Attributes(pointData, timesteps, act_time);

            // Caculate normal per vertex
            //this.Calculate_Triangle_Normals_per_Vertex(first_timestep);
        }

        private void Read_Triangles(vtkCellArray triangleCells)
        {
            vtkIdList pts = new vtkIdList();

            int counter = 0;

            while (triangleCells.GetNextCell(pts) != 0)
            {
                List<float> cell = new List<float>();

                for (int i = 0; i < pts.GetNumberOfIds(); i++)
                {
                    cell.Add(pts.GetId(i));
                }

                if (cell.Count == 3)
                {
                    this.Get_Triangle(counter, cell);

                    counter++;
                }

                if (cell.Count == 4)
                {
                    List<Triangle> tris = this.Get_Triangles_from_Quad(cell, counter);

                    this.triangles.Add(tris[0]);
                    this.triangles.Add(tris[1]);

                    counter += 2;
                }
            }
        }

        private List<Triangle> Get_Triangles_from_Quad(List<float> parameters, int ID)
        {
            List<Triangle> triangles = new List<Triangle>();

            triangles.Capacity = 2;

            int id_0 = (int)parameters[0];
            int id_1 = (int)parameters[1];
            int id_2 = (int)parameters[2];

            Vector3 p_0 = this.positions[id_0];
            Vector3 p_1 = this.positions[id_1];
            Vector3 p_2 = this.positions[id_2];

            Triangle tri_first = new Triangle(ID, id_0, id_1, id_2,
                                       id_0, id_1, id_2,
                                       id_0, id_1, id_2,
                                       p_0, p_1, p_2);

            triangles.Add(tri_first);

            id_0 = (int)parameters[2];
            id_1 = (int)parameters[3];
            id_2 = (int)parameters[0];

            p_0 = this.positions[id_0];
            p_1 = this.positions[id_1];
            p_2 = this.positions[id_2];

            Triangle tri_snd = new Triangle(ID + 1, id_0, id_1, id_2,
                                       id_0, id_1, id_2,
                                       id_0, id_1, id_2,
                                       p_0, p_1, p_2);

            triangles.Add(tri_snd);

            return triangles;
        }

        private void Get_Triangle(int ID, vtkIdList pts)
        {
            int id_0 = (int)pts.GetId(0);
            int id_1 = (int)pts.GetId(1);
            int id_2 = (int)pts.GetId(2);

            Vector3 p_0 = this.positions[id_0];
            Vector3 p_1 = this.positions[id_1];
            Vector3 p_2 = this.positions[id_2];

            Triangle tri = new Triangle(ID, id_0, id_1, id_2,
                                       id_0, id_1, id_2,
                                       id_0, id_1, id_2,
                                       p_0, p_1, p_2);

            this.triangles.Add(tri);
        }

        private void Get_Triangle(int ID, List<float> ids)
        {
            int id_0 = (int)ids[0];
            int id_1 = (int)ids[1];
            int id_2 = (int)ids[2];

            Vector3 p_0 = this.positions[id_0];
            Vector3 p_1 = this.positions[id_1];
            Vector3 p_2 = this.positions[id_2];

            Triangle tri = new Triangle(ID, id_0, id_1, id_2,
                                       id_0, id_1, id_2,
                                       id_0, id_1, id_2,
                                       p_0, p_1, p_2);

            this.triangles.Add(tri);
        }

        private void Load_Point_Attributes(vtkPointData pointData)
        {
            if (pointData == null)
            {
                Console.WriteLine("## Error: 'Get_Attribute_Values' PointData null");

                return;
            }

            int numArrays = pointData.GetNumberOfArrays();

            List<float> scalar_dat;
            List<Vector3> vector_dat;

            vtkDataArray dataArray;

            string arrayName;

            int arraysize = 0;

            List<string> delete_names = new List<string>();
            delete_names.Add("Deformation");
            delete_names.Add("Stress_Mises");

            float actvalue = 0;

            for (int i = 0; i < numArrays; i++)
            {
                scalar_dat = new List<float>();
                vector_dat = new List<Vector3>();

                dataArray = pointData.GetArray(i);

                arrayName = pointData.GetArrayName(i);

                if (delete_names.Contains(arrayName))
                {
                    continue;
                }

                arraysize = (int)dataArray.GetNumberOfTuples();

                if (dataArray.GetNumberOfComponents() == 1)
                {
                    for (int j = 0; j < arraysize; j++)
                    {
                        actvalue = (float)dataArray.GetTuple1(j);

                        scalar_dat.Add(actvalue);
                    }

                    if (this.scalar_data.ContainsKey(arrayName))
                    {
                        this.scalar_data[arrayName].Data_Unordered.Add(scalar_dat);
                    }
                    else
                    {
                        this.scalar_data.Add(arrayName, new Unsteady_Datafield<float>(scalar_dat));
                    }
                }
                else if (dataArray.GetNumberOfComponents() == 3)
                {
                    for (int j = 0; j < arraysize; j++)
                    {
                        double[] vec = dataArray.GetTuple3(j);

                        vector_dat.Add(new Vector3((float)vec[0], (float)vec[1], (float)vec[2]));
                    }

                    if (this.vector_data.ContainsKey(arrayName))
                    {
                        this.vector_data[arrayName].Data_Unordered.Add(vector_dat);
                    }
                    else
                    {
                        this.vector_data.Add(arrayName, new Unsteady_Datafield<Vector3>(vector_dat));
                    }
                }
            }
        }

        private void Load_Point_Attributes(vtkPointData pointData, int timesteps, int act_time)
        {
            if (pointData == null)
            {
                Console.WriteLine("## Error: 'Get_Attribute_Values' PointData null");

                return;
            }

            int numArrays = pointData.GetNumberOfArrays();

            List<float> scalar_dat;
            List<Vector3> vector_dat;

            vtkDataArray dataArray;

            string arrayName;

            int arraysize = 0;

            float actvalue = 0;

            List<string> delete_names = new List<string>();
            delete_names.Add("Deformation");
            delete_names.Add("Stress_Mises");

            for (int i = 0; i < numArrays; i++)
            {
                scalar_dat = new List<float>();
                vector_dat = new List<Vector3>();

                dataArray = pointData.GetArray(i);

                arrayName = pointData.GetArrayName(i);

                if (delete_names.Contains(arrayName))
                {
                    continue;
                }

                arraysize = (int)dataArray.GetNumberOfTuples();

                if (dataArray.GetNumberOfComponents() == 1)
                {
                    for (int j = 0; j < arraysize; j++)
                    {
                        actvalue = (float)dataArray.GetTuple1(j);

                        scalar_dat.Add(actvalue);
                    }

                    if (this.scalar_data.ContainsKey(arrayName))
                    {
                        this.scalar_data[arrayName].Data_Unordered[act_time] = scalar_dat;
                    }
                    else
                    {
                        this.scalar_data.Add(arrayName, new Unsteady_Datafield<float>(timesteps));

                        this.scalar_data[arrayName].Data_Unordered[act_time] = scalar_dat;
                    }
                }
                else if (dataArray.GetNumberOfComponents() == 3)
                {
                    for (int j = 0; j < arraysize; j++)
                    {
                        double[] vec = dataArray.GetTuple3(j);

                        vector_dat.Add(new Vector3((float)vec[0], (float)vec[1], (float)vec[2]));
                    }

                    if (this.vector_data.ContainsKey(arrayName))
                    {
                        this.vector_data[arrayName].Data_Unordered[act_time] = vector_dat;
                    }
                    else
                    {
                        this.vector_data.Add(arrayName, new Unsteady_Datafield<Vector3>(timesteps));

                        this.vector_data[arrayName].Data_Unordered[act_time] = vector_dat;
                    }
                }
            }
        }

        #endregion
    }
}
