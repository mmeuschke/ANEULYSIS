﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL;
using NeuroAnalytics.Properties;

namespace NeuroAnalytics
{
    public class ABuffer
    {
        #region - Private Variables -

        private Shader abuffer_shader;
        private Shader abuffer_clear_shader;

        private uint abufferimage;
        private uint abufferdepth;
        private uint abuffercounter;

        private int abuffer_width = 64;
        private int abuffer_height = 64;
        private int abuffer_size = 16;

        #endregion

        #region - Constructors -

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        /// <summary>
        /// Initializes the buffers for ABuffer Rendering used for OIT
        /// </summary>
        public void SetupABuffer()
        {
            GL.DeleteTextures(1, ref this.abufferimage);
            GL.DeleteTextures(1, ref this.abufferdepth);
            GL.DeleteTextures(1, ref this.abuffercounter);

            // ABuffer Image
            GL.GenTextures(1, out this.abufferimage);

            GL.BindTexture(TextureTarget.Texture2DArray, this.abufferimage);

            GL.TexImage3D(TextureTarget.Texture2DArray, 0, PixelInternalFormat.Rgba32f, this.abuffer_width, this.abuffer_height, this.abuffer_size, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Rgba, PixelType.Float, IntPtr.Zero);

            GL.TexParameter(TextureTarget.Texture2DArray, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
            GL.TexParameter(TextureTarget.Texture2DArray, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);

            GL.BindImageTexture(0, this.abufferimage, 0, true, 0, TextureAccess.ReadWrite, SizedInternalFormat.Rgba32f);

            GL.BindTexture(TextureTarget.Texture2DArray, 0);

            //ABuffer Depth

            //GL.GenTextures(1, out this.abufferdepth);

            //GL.BindTexture(TextureTarget.Texture2DArray, this.abufferdepth);

            //GL.TexImage3D(TextureTarget.Texture2DArray, 0, PixelInternalFormat.R32f, this.abuffer_width, this.abuffer_height, this.abuffer_size, 0,
            //    OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, IntPtr.Zero);

            //GL.TexParameter(TextureTarget.Texture2DArray, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
            //GL.TexParameter(TextureTarget.Texture2DArray, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);

            //GL.BindImageTexture(1, this.abufferdepth, 0, true, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32f);

            //GL.BindTexture(TextureTarget.Texture2DArray, 0);

            GL.GenTextures(1, out this.abufferdepth);

            GL.BindTexture(TextureTarget.Texture2DArray, this.abufferdepth);

            GL.TexImage3D(TextureTarget.Texture2DArray, 0, PixelInternalFormat.Rgba32f, this.abuffer_width, this.abuffer_height, this.abuffer_size, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Rgba, PixelType.Float, IntPtr.Zero);

            GL.TexParameter(TextureTarget.Texture2DArray, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
            GL.TexParameter(TextureTarget.Texture2DArray, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);

            GL.BindImageTexture(1, this.abufferdepth, 0, true, 0, TextureAccess.ReadWrite, SizedInternalFormat.Rgba32f);

            GL.BindTexture(TextureTarget.Texture2DArray, 0);


            //ABuffer Counter

            GL.GenTextures(1, out this.abuffercounter);

            GL.BindTexture(TextureTarget.Texture2D, this.abuffercounter);

            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.R32f, this.abuffer_width, this.abuffer_height, 0,
                OpenTK.Graphics.OpenGL.PixelFormat.Red, PixelType.Float, IntPtr.Zero);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.ClampToBorder);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.ClampToBorder);

            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);

            GL.BindImageTexture(2, this.abuffercounter, 0, false, 0, TextureAccess.ReadWrite, SizedInternalFormat.R32ui);

            GL.BindTexture(TextureTarget.Texture2D, 0);

            // Shader
            List<string> pathes = new List<string>();
            List<string> clearpathes = new List<string>();

            // get relative path
            string projectPath = Utility.Get_Relative_Project_Path();

            pathes.Add(projectPath + Settings.Default.ABufferFSVert);
            pathes.Add(projectPath + Settings.Default.ABufferFSFrag);

            clearpathes.Add(projectPath + Settings.Default.ABufferClearVert);
            clearpathes.Add(projectPath + Settings.Default.ABufferClearFrag);

            this.abuffer_shader = new Shader(pathes);
            this.abuffer_clear_shader = new Shader(clearpathes);

            Console.WriteLine("# GL Error Check  : " + GL.GetError().ToString());
            Console.WriteLine("# Used ABuffer IDs: {0}, {1}, {2}", this.abufferimage, this.abufferdepth, this.abuffercounter);
        }

        /// <summary>
        /// Sets the size of the ABuffer
        /// </summary>
        public void SetABufferSize(int width, int height)
        {
            this.abuffer_width = width;
            this.abuffer_height = height;
        }

        /// <summary>
        /// Clears the ABuffer before the next render passes starts
        /// </summary>
        public void ClearABufferContent()
        {
            abuffer_clear_shader.EnableShader();

            GL.DrawArrays(PrimitiveType.Quads, 0, 4);

            abuffer_clear_shader.DisableShader();

            GL.MemoryBarrier(MemoryBarrierFlags.ShaderImageAccessBarrierBit);
        }

        /// <summary>
        /// Renders the ABuffer content in correct order
        /// </summary>
        public void RenderABufferContent()
        {
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();

            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadIdentity();

            // Draw Content of FBO
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

            //GL.ActiveTexture(TextureUnit.Texture0);
            //GL.BindTexture(TextureTarget.Texture2DArray, abufferimage);

            //GL.ActiveTexture(TextureUnit.Texture1);
            //GL.BindTexture(TextureTarget.Texture2DArray, abufferdepth);

            //GL.ActiveTexture(TextureUnit.Texture2);
            //GL.BindTexture(TextureTarget.Texture2D, abuffercounter);

            this.abuffer_shader.EnableShader();

            GL.DrawArrays(PrimitiveType.Quads, 0, 4);

            this.abuffer_shader.DisableShader();
        }

        /// <summary>
        /// Delets the used textures for ABuffering
        /// </summary>
        public void ClearBuffers()
        {
            // ABuffer
            GL.DeleteTextures(1, ref this.abufferimage);
            GL.DeleteTextures(1, ref this.abufferdepth);
            GL.DeleteTextures(1, ref this.abuffercounter);
        }

        #endregion
    }
}
