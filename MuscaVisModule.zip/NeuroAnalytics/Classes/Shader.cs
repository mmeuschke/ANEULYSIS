﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using NeuroAnalytics.Properties;
using System.IO;

namespace NeuroAnalytics
{
    public class Shader : IDisposable
    {
        #region - Class Members -

        // Animation time
        private static float ani_time = 0;

        #endregion

        #region - Class Properties -

        public static float Ani_time
        {
            get { return Shader.ani_time; }
            set { Shader.ani_time = value; }
        }

        #endregion

        #region - Private Variables -

        private int prog;

        private List<string> shader_pathes;

        // Standard locs
        private int pr_matrix_loc;
        private int mv_matrix_loc;
        private int viewport_loc;

        // View Locs
        private int view_direc_3d_loc;
        private int view_direc_2d_loc;
        private int cam_pos_vplots_loc;

        // ABuffer
        private int abuffer_img_loc;
        private int abuffer_depth_img_loc;
        private int abuffercounter_img_loc;

        // Scatterplot
        private int scatter_img_loc;

        private int scatter_size;
        private int scatter_size_loc;

        private int render_scatter_hist;
        private int render_scatter_hist_loc;

        private int write_scatter_plot; // disabled for equalization
        private int write_scatter_plot_loc;

        private int draw_global_scat;
        private int draw_global_scat_loc;

        private int invert_scatter_plot; // inverted rendering of the scatterplot
        private int invert_scatter_plot_loc;

        private int difference_scatter_plot; // difference rendering of the scatterplot
        private int difference_scatter_plot_loc;

        private int hist_bin_img_loc;
        private int num_bins; // number bin of each histogram 
        private int num_bins_loc;

        private int fps;
        private int fps_loc;

        // Brushing Image
        private int brushing_img_loc;
        private int brushingplot_img_loc;
        private int brushingmap_img_loc;

        private int brushed_point_loc;
        private Vector2 brushed_point;

        // Number Timesteps
        private int time_steps_loc;
        private int time_steps;

        // Animation time
        private int ani_time_loc;

        // Render Item Properties
        private int item_point_number;
        private int item_point_number_loc;

        private int map_sample_number;
        private int map_sample_number_loc;

        // Mesh Properties
        private float mesh_opacity;
        private int mesh_opacity_loc;

        private int stent_selected;
        private int stent_selected_loc;

        private int discrete_col_selection;
        private int discete_col_selection_loc;

        private int num_toon_colors;
        private int num_toon_colors_loc;

        private int num_scalar_fields;
        private int num_scalar_fields_loc;

        private int fst_rendered_prop;
        private int fst_rendered_prop_loc;

        private int snd_rendered_prop;
        private int snd_rendered_prop_loc;

        private Vector2 fst_rescale_val;
        private int fst_rescale_val_loc;

        private Vector2 snd_rescale_val;
        private int snd_rescale_val_loc;

        private int rendered_mesh;
        private int rendered_mesh_loc;

        private int render_cluster;
        private int render_cluster_loc;

        // Rendering Contour
        private float contour_val;
        private int contour_val_loc;

        private float focus_value;
        private int focus_value_loc;

        private int hatching_active_val;
        private int hatching_active_val_loc;

        private int brushing_on;
        private int brushing_on_loc;

        // Map Properties
        private Vector2 max_map_dim;
        private Vector2 min_map_dim;

        private int max_map_dim_loc;
        private int min_map_dim_loc;

        private Vector2 grid_dim;
        private int grid_dim_loc;

        private float sel_val;
        private int sel_val_loc;

        // plot Properties
        private int plot_texture_img_loc;

        // Region Brushing
        private int show_brushing;
        private int show_brushing_loc;

        private int show_brushing_isolines;
        private int show_brushing_isolines_loc;

        private float[] brushing_col;
        private int brushing_col_loc;

        private int brushing_region_id;
        private int brushing_region_id_loc;

        private int brush_size;
        private int brush_size_loc;

        #endregion

        #region - Constructors -

        public Shader(List<string> pathes)
        {
            this.shader_pathes = pathes;

            this.time_steps = Utility.Num_Timesteps;

            this.item_point_number = 0;

            this.map_sample_number = Utility.Map_Sample_Number;

            this.mesh_opacity = 1.0f;

            this.stent_selected = 0;

            this.discrete_col_selection = 0;
            this.num_toon_colors = 5;

            this.num_scalar_fields = 1;

            this.fst_rendered_prop = 0;
            this.snd_rendered_prop = 1;

            this.fst_rescale_val = new Vector2(0.0f, 1.0f);
            this.snd_rescale_val = new Vector2(0.0f, 1.0f);

            this.rendered_mesh = 1;
            this.render_cluster = 0;

            this.contour_val = 0.5f;
            this.focus_value = 0.5f;
            this.hatching_active_val = 1;

            this.scatter_size = Utility.Matrix_Size;

            this.num_bins = Utility.Num_Bins;

            this.brushed_point = new Vector2(-1,-1);

            this.brushing_on = 0;

            this.brush_size = 10;

            this.max_map_dim = new Vector2(2, 2);
            this.min_map_dim = new Vector2(-2, -2);

            this.grid_dim = new Vector2(20, 20);

            this.sel_val = 0;

            this.render_scatter_hist = 0;

            this.write_scatter_plot = 1;

            this.draw_global_scat = 0;

            this.invert_scatter_plot = 0;

            this.difference_scatter_plot = 0;

            this.fps = 1;

            this.show_brushing = 0;
            this.show_brushing_isolines = 0;
            this.brushing_col = new float[(Utility.Max_Region_Colors*3)]; // 20 colors
            this.brushing_region_id = -1;

            this.SetupProgram();
        }

        #endregion

        #region - Properties -

        public int Prog
        {
            get { return this.prog; }
            set { this.prog = value; }
        }

        public float Mesh_Opacity
        {
            get { return this.mesh_opacity; }
            set
            {
                this.mesh_opacity = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.mesh_opacity_loc, this.mesh_opacity);

                GL.UseProgram(0);
            }
        }

        public int Stent_Selected
        {
            get { return this.stent_selected; }
            set
            {
                this.stent_selected = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.stent_selected_loc, this.stent_selected);

                GL.UseProgram(0);

            }
        }

        public int Discrete_Col_Selection
        {
            get { return this.discrete_col_selection; }
            set
            {
                this.discrete_col_selection = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.discete_col_selection_loc, this.discrete_col_selection);

                GL.UseProgram(0);
            }
        }

        public int FST_Rendered_Prop
        {
            get { return this.fst_rendered_prop; }
            set { this.fst_rendered_prop = value;
            
                  GL.UseProgram(this.prog);

                  GL.Uniform1(this.fst_rendered_prop_loc, this.fst_rendered_prop);

                  GL.UseProgram(0);
            }
        }

        public int Snd_Rendered_Prop
        {
            get { return this.snd_rendered_prop; }
            set
            {
                this.snd_rendered_prop = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.snd_rendered_prop_loc, this.snd_rendered_prop);

                GL.UseProgram(0);
            }
        }

        public Vector2 Fst_Rescale
        {
            get { return this.fst_rescale_val; }
            set
            {
                this.fst_rescale_val = value;

                GL.UseProgram(this.prog);

                GL.Uniform2(this.fst_rescale_val_loc, this.fst_rescale_val);

                GL.UseProgram(0);
            }
        }

        public Vector2 Snd_Rescale
        {
            get { return this.snd_rescale_val; }
            set
            {
                this.snd_rescale_val = value;

                GL.UseProgram(this.prog);

                GL.Uniform2(this.snd_rescale_val_loc, this.snd_rescale_val);

                GL.UseProgram(0);
            }
        }

        public int Rendered_Mesh
        {
            get { return this.rendered_mesh; }
            set
            {
                this.rendered_mesh = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.rendered_mesh_loc, this.rendered_mesh);

                GL.UseProgram(0);
            }
        }

        public int Render_Cluster
        {
            get { return this.render_cluster; }
            set
            {
                this.render_cluster = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.render_cluster_loc, this.render_cluster);

                GL.UseProgram(0);
            }
        }

        public float Focus_Value
        {
            get { return this.focus_value; }
            set
            {
                this.focus_value = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.focus_value_loc, this.focus_value);

                GL.UseProgram(0);
            }
        }

        public float Contour_Val
        {
            get { return this.contour_val; }
            set
            {
                this.contour_val = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.contour_val_loc, this.contour_val);

                GL.UseProgram(0);
            }
        }

        public int Hatching_Active_Val
        {
            get { return this.hatching_active_val; }
            set
            {
                this.hatching_active_val = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.hatching_active_val_loc, this.hatching_active_val);

                GL.UseProgram(0);
            }
        }

        public int Num_Toon_Colors
        {
            get { return this.num_toon_colors; }
            set
            {
                this.num_toon_colors = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.num_toon_colors_loc, this.num_toon_colors);

                GL.UseProgram(0);
            }
        }

        public int Num_Scalar_Fields
        {
            get { return this.num_scalar_fields; }
            set { 
                this.num_scalar_fields = value; 
            
                GL.UseProgram(this.prog);

                GL.Uniform1(this.num_scalar_fields_loc, this.num_scalar_fields);

                GL.UseProgram(0);
            }
        }

        public int Scatter_Size
        {
            get { return this.scatter_size; }
            set
            {
                this.scatter_size = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.scatter_size_loc, this.scatter_size);

                GL.UseProgram(0);
            }
        }

        public int Num_Bins
        {
            get { return this.num_bins; }
            set
            {
                this.num_bins = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.num_bins_loc, this.num_bins);

                GL.UseProgram(0);
            }

        }

        public Vector2 Brushed_Point
        {
            get { return this.brushed_point; }
            set
            {
                this.brushed_point = value;

                GL.UseProgram(this.prog);

                GL.Uniform2(this.brushed_point_loc, this.brushed_point);

                GL.UseProgram(0);
            }
        }

        public int Brushing_On
        {
            get { return this.brushing_on; }
            set
            {
                this.brushing_on = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.brushing_on_loc, this.brushing_on);

                GL.UseProgram(0);
            }
        }

        public Vector2 Max_Map_Dim
        {
            get { return this.max_map_dim; }
            set
            {
                this.max_map_dim = value;

                GL.UseProgram(this.prog);

                GL.Uniform2(this.max_map_dim_loc, this.max_map_dim);

                GL.UseProgram(0);
            }
        }

        public Vector2 Map_Grid_Dim
        {
            get { return this.grid_dim; }
            set
            {
                this.grid_dim = value;

                GL.UseProgram(this.prog);

                GL.Uniform2(this.grid_dim_loc, this.grid_dim);

                GL.UseProgram(0);
            }
        }

        public Vector2 Min_Map_Dim
        {
            get { return this.min_map_dim; }
            set
            {
                this.min_map_dim = value;

                GL.UseProgram(this.prog);

                GL.Uniform2(this.min_map_dim_loc, this.min_map_dim);

                GL.UseProgram(0);
            }
        }

        public float Sel_Val
        {
            get { return this.sel_val; }
            set
            {
                this.sel_val = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.sel_val_loc, this.sel_val);

                GL.UseProgram(0);
            }
        }

        public int Render_Scatter_Hist
        {
            get { return this.render_scatter_hist; }
            set
            {
                this.render_scatter_hist = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.render_scatter_hist_loc, this.render_scatter_hist);

                GL.UseProgram(0);
            }
        }

        public int Write_ScatterPlot
        {
            get { return this.write_scatter_plot; }
            set
            {
                this.write_scatter_plot = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.write_scatter_plot_loc, this.write_scatter_plot);

                GL.UseProgram(0);
            }
        }

        public int Draw_Global_ScatterPlot
        {
            get { return this.draw_global_scat; }
            set
            {
                this.draw_global_scat = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.draw_global_scat_loc, this.draw_global_scat);

                GL.UseProgram(0);
            }
        }

        public int Invert_ScatterPlot
        {
            get { return this.invert_scatter_plot; }
            set
            {
                this.invert_scatter_plot = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.invert_scatter_plot_loc, this.invert_scatter_plot);

                GL.UseProgram(0);
            }
        }

        public int Difference_ScatterPlot
        {
            get { return this.difference_scatter_plot; }
            set
            {
                this.difference_scatter_plot = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.difference_scatter_plot_loc, this.difference_scatter_plot);

                GL.UseProgram(0);
            }
        }

        public int Item_Point_Number
        {
            get { return this.item_point_number; }
            set
            {
                this.item_point_number = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.item_point_number_loc, this.item_point_number);

                GL.UseProgram(0);
            }
        }

        public int Map_Sample_Number
        {
            get { return this.map_sample_number; }
            set
            {
                this.map_sample_number = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.map_sample_number_loc, this.map_sample_number);

                GL.UseProgram(0);
            }
        }

        public int FPS_Counter
        {
            get { return this.fps; }
            set
            {
                this.fps = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.fps_loc, this.fps);

                GL.UseProgram(0);
            }
        }

        public int Show_Brushing
        {
            get { return this.show_brushing; }
            set
            {
                this.show_brushing = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.show_brushing_loc, this.show_brushing);

                GL.UseProgram(0);
            }
        }

        public int Show_Brushing_Isolines
        {
            get { return this.show_brushing_isolines; }
            set
            {
                this.show_brushing_isolines = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.show_brushing_isolines_loc, this.show_brushing_isolines);

                GL.UseProgram(0);
            }
        }

        public int Brush_Size
        {
            get { return this.brush_size; }
            set
            {
                this.brush_size = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.brush_size_loc, this.brush_size);

                GL.UseProgram(0);
            }
        }

        public float[] Brushing_Colors
        {
            get { return this.brushing_col; }
            set 
            {   
                this.brushing_col = value;

                GL.UseProgram(this.prog);

                GL.Uniform3(this.brushing_col_loc, (Utility.Max_Region_Colors*3), this.brushing_col);

                GL.UseProgram(0);
            }
        }

        public int Brushing_Region_Id
        {
            get { return this.brushing_region_id; }
            set
            {
                this.brushing_region_id = value;

                GL.UseProgram(this.prog);

                GL.Uniform1(this.brushing_region_id_loc, this.brushing_region_id);

                GL.UseProgram(0);
            }
        }

        #endregion

        #region - Methods -

        private static void SetupShader(string path, ref int prog)
        {
            int shader = 0;

            StreamReader shader_reader = new StreamReader(path);

            string shader_source = shader_reader.ReadToEnd();

            shader_reader.Close();

            if (path.EndsWith(".vert"))
            {
                shader = GL.CreateShader(ShaderType.VertexShader);
            }
            else if (path.EndsWith(".tesc"))
            {
                shader = GL.CreateShader(ShaderType.TessControlShader);
            }
            else if (path.EndsWith(".tese"))
            {
                shader = GL.CreateShader(ShaderType.TessEvaluationShader);
            }
            else if (path.EndsWith(".geom"))
            {
                shader = GL.CreateShader(ShaderType.GeometryShader);
            }
            else if (path.EndsWith(".frag"))
            {
                shader = GL.CreateShader(ShaderType.FragmentShader);
            }
            else if (path.EndsWith(".comp"))
            {
                shader = GL.CreateShader(ShaderType.ComputeShader);
            }

            if (shader == 0)
            {
                Console.WriteLine("## Shader:\t\t\tUnsupported Shader Type\n");

                return;
            }

            GL.ShaderSource(shader, shader_source);
            GL.CompileShader(shader);

            GL.AttachShader(prog, shader);

            string log = GL.GetShaderInfoLog(shader);

            if (log.Length > 0)
            {
                Console.WriteLine("-> Shader: " + path + "\t\t\tShader Info:\n" + log);
            }

            GL.DeleteShader(shader);
        }

        private void SetupProgram()
        {
            this.prog = GL.CreateProgram();

            for (int i = 0; i < this.shader_pathes.Count; i++)
            {
                Shader.SetupShader(this.shader_pathes[i], ref this.prog);
            }

            GL.LinkProgram(this.prog);

            GL.UseProgram(this.prog);

            // Setup bindless textures
            this.Setup_Images();

            // Setup basic render variables
            this.Setup_Basic_Variables();

            // Setup camera animation variables
            this.Setup_Animation_Variables();

            // Setup more general render properties
            this.Set_General_Render_Props();

            // Setup mesh variables
            this.Setup_Mesh_Variables();

            // Setup map variables
            this.Set_Map_Variables();

            GL.UseProgram(0);
#if DEBUG
            // DEBUG OUTPUT
            if (pr_matrix_loc != -1)
            {
                Console.WriteLine("-> Shader:\t\t\tFound: PR Matrix Uniform");
            }

            if (mv_matrix_loc != -1)
            {
                Console.WriteLine("-> Shader:\t\t\tFound: MV Matrix Uniform");
            }

            string log = GL.GetProgramInfoLog(this.prog);

            if (log.Length > 0)
            {
                Console.WriteLine("-> Shader:\t\t\tShader Prog Info:\n" + log);
            }
#endif
        }

        private void Setup_Basic_Variables()
        {
            this.pr_matrix_loc = this.GetUniformLocation("pr_matrix");
            this.mv_matrix_loc = this.GetUniformLocation("mv_matrix");
            this.viewport_loc = this.GetUniformLocation("Viewport");

            this.view_direc_3d_loc = this.GetUniformLocation("view_direc_3d");
            this.cam_pos_vplots_loc = this.GetUniformLocation("cam_pos_vplots");
            this.view_direc_2d_loc = this.GetUniformLocation("view_direc_2d");
        }

        private void Setup_Images()
        {
            // All Image Locations

            // ABuffer
            this.abuffer_img_loc = this.GetUniformLocation("abufferImg");
            this.abuffer_depth_img_loc = this.GetUniformLocation("abufferdepthImg");
            this.abuffercounter_img_loc = this.GetUniformLocation("abufferCounterImg");

            // Scatterplot
            this.scatter_img_loc = this.GetUniformLocation("scatterplotImg");

            this.num_bins_loc = this.GetUniformLocation("num_bins");
            GL.Uniform1(this.num_bins_loc, this.num_bins);

            // Brushing Image 3D
            this.brushing_img_loc = this.GetUniformLocation("brushingImg");

            // Brushing Image 2D
            this.brushingplot_img_loc = this.GetUniformLocation("brushingplotImg");

            // Brushing Image Map
            this.brushingmap_img_loc = this.GetUniformLocation("brushingmapImg");

            // Image for Histogramm Heights
            this.hist_bin_img_loc = this.GetUniformLocation("binheightsImg");

            // Texture for Plot Texture
            this.plot_texture_img_loc = this.GetUniformLocation("PlotTexture");

            // ABuffer Image (Color)
            if (this.abuffer_img_loc > -1)
                GL.Uniform1(this.abuffer_img_loc, 0);
            else
                Console.WriteLine("##\tError: ABuffer Image (Color): " + this.abuffer_img_loc);

            // ABuffer Image (Depth)
            if (this.abuffer_depth_img_loc > -1)
                GL.Uniform1(this.abuffer_depth_img_loc, 1);
            else
                Console.WriteLine("##\tError: ABuffer Image (Depth): " + this.abuffer_depth_img_loc);

            // ABuffer Image (Counter)
            if (this.abuffercounter_img_loc > -1)
                GL.Uniform1(this.abuffercounter_img_loc, 2);
            else
                Console.WriteLine("##\tError: ABuffer Image (Counter): " + this.abuffercounter_img_loc);

            // Scatterplot Image
            if (this.scatter_img_loc > -1)
                GL.Uniform1(this.scatter_img_loc, 3);
            else
                Console.WriteLine("##\tError: Scatterplot Image: " + this.scatter_img_loc);

            // Brushing Image 3D
            if (this.brushing_img_loc > -1)
                GL.Uniform1(this.brushing_img_loc, 4);
            else
                Console.WriteLine("##\tError: Brushing 3D Image: " + this.brushing_img_loc);

            // Brushing Image 2D
            if (this.brushingplot_img_loc > -1)
                GL.Uniform1(this.brushingplot_img_loc, 5);
            else
                Console.WriteLine("##\tError: Brushing Plot Image: " + this.brushingplot_img_loc);

            // Brushing Image Map
            if (this.brushingmap_img_loc > -1)
                GL.Uniform1(this.brushingmap_img_loc, 6);
            else
                Console.WriteLine("##\tError: Brushing Map Image: " + this.brushingmap_img_loc);

            // Histogramm Heights Image for First Case
            if (this.hist_bin_img_loc > -1)
                GL.Uniform1(this.hist_bin_img_loc, 7);
            else
                Console.WriteLine("##\tError: Histogramm Heights Image: " + this.hist_bin_img_loc);

            // Texture for vessel plot
            if (this.plot_texture_img_loc > -1)
                GL.Uniform1(this.plot_texture_img_loc, 8);
            else
                Console.WriteLine("##\tError: Plot Texture: " + this.plot_texture_img_loc);
        }

        private void Setup_Animation_Variables()
        {
            this.time_steps_loc = this.GetUniformLocation("time_steps");
            GL.Uniform1(this.time_steps_loc, this.time_steps);

            this.ani_time_loc = this.GetUniformLocation("ani_time");
        }

        private void Set_General_Render_Props()
        {
            // number points of render item 
            this.item_point_number_loc = this.GetUniformLocation("number_points");
            GL.Uniform1(this.item_point_number_loc, this.item_point_number);

            this.discete_col_selection_loc = this.GetUniformLocation("discretecolor");
            GL.Uniform1(this.discete_col_selection_loc, this.discrete_col_selection);

            this.fst_rendered_prop_loc = this.GetUniformLocation("rendered_prop");
            GL.Uniform1(this.fst_rendered_prop_loc, this.fst_rendered_prop);

            this.snd_rendered_prop_loc = this.GetUniformLocation("snd_rendered_prop");
            GL.Uniform1(this.snd_rendered_prop_loc, this.snd_rendered_prop);

            this.fst_rescale_val_loc = this.GetUniformLocation("fst_rescale");
            GL.Uniform2(this.fst_rescale_val_loc, this.fst_rescale_val);

            this.snd_rescale_val_loc = this.GetUniformLocation("snd_rescale");
            GL.Uniform2(this.snd_rescale_val_loc, this.snd_rescale_val);

            this.contour_val_loc = this.GetUniformLocation("contour_value");
            GL.Uniform1(this.contour_val_loc, this.contour_val);
        }

        private void Setup_Mesh_Variables()
        {
            // mesh attributes
            this.mesh_opacity_loc = this.GetUniformLocation("mesh_opacity");
            GL.Uniform1(this.mesh_opacity_loc, this.mesh_opacity);

            this.stent_selected_loc = this.GetUniformLocation("stent_select");
            GL.Uniform1(this.stent_selected_loc, this.stent_selected);

            this.rendered_mesh_loc = this.GetUniformLocation("rendered_mesh");
            GL.Uniform1(this.rendered_mesh_loc, this.rendered_mesh);

            this.render_cluster_loc = this.GetUniformLocation("render_cluster");
            GL.Uniform1(this.render_cluster_loc, this.render_cluster);

            this.hatching_active_val_loc = this.GetUniformLocation("hatching");
            GL.Uniform1(this.hatching_active_val_loc, this.hatching_active_val);

            this.num_toon_colors_loc = this.GetUniformLocation("numcol");
            GL.Uniform1(this.num_toon_colors_loc, this.num_toon_colors);

            this.draw_global_scat_loc = this.GetUniformLocation("draw_global_sp");
            GL.Uniform1(this.draw_global_scat_loc, this.draw_global_scat);

            this.num_scalar_fields_loc = this.GetUniformLocation("number_scalar_fields");
            GL.Uniform1(this.num_scalar_fields_loc, this.num_scalar_fields);

            this.scatter_size_loc = this.GetUniformLocation("size_scatter_plot");
            GL.Uniform1(this.scatter_size_loc, this.scatter_size);

            this.brushed_point_loc = this.GetUniformLocation("brushed_point");
            GL.Uniform2(this.brushed_point_loc, this.brushed_point);

            this.brushing_on_loc = this.GetUniformLocation("brushing_on");
            GL.Uniform1(this.brushing_on_loc, this.brushing_on);

            this.show_brushing_loc = this.GetUniformLocation("show_brush");
            GL.Uniform1(this.show_brushing_loc, this.show_brushing);

            this.show_brushing_isolines_loc = this.GetUniformLocation("show_brush_iso");
            GL.Uniform1(this.show_brushing_isolines_loc, this.show_brushing_isolines);

            this.brushing_col_loc = this.GetUniformLocation("brushing_col");
            GL.Uniform1(this.brushing_col_loc, (Utility.Max_Region_Colors*3), this.brushing_col);

            this.brushing_region_id_loc = this.GetUniformLocation("brushing_id");
            GL.Uniform1(this.brushing_region_id_loc, this.brushing_region_id);

            this.brush_size_loc = this.GetUniformLocation("brush_size");
            GL.Uniform1(this.brush_size_loc, this.brush_size);

            this.render_scatter_hist_loc = this.GetUniformLocation("render_histo");
            GL.Uniform1(this.render_scatter_hist_loc, this.render_scatter_hist);

            this.write_scatter_plot_loc = this.GetUniformLocation("write_scatterplot");
            GL.Uniform1(this.write_scatter_plot_loc, this.write_scatter_plot);

            this.invert_scatter_plot_loc = this.GetUniformLocation("invert_scatterplot");
            GL.Uniform1(this.invert_scatter_plot_loc, this.invert_scatter_plot);

            this.difference_scatter_plot_loc = this.GetUniformLocation("difference_scatterplot");
            GL.Uniform1(this.difference_scatter_plot_loc, this.difference_scatter_plot);

            this.fps_loc = this.GetUniformLocation("fps_counter");
            GL.Uniform1(this.fps_loc, this.fps);
        }

        private void Set_Map_Variables()
        {
            // number of sampled map points
            this.map_sample_number_loc = this.GetUniformLocation("sample_num");
            GL.Uniform1(this.map_sample_number_loc, this.map_sample_number);

            this.focus_value_loc = this.GetUniformLocation("focus_value");
            GL.Uniform1(this.focus_value_loc, this.focus_value);

            this.max_map_dim_loc = this.GetUniformLocation("max_map_dim");
            GL.Uniform2(this.max_map_dim_loc, this.max_map_dim);

            this.min_map_dim_loc = this.GetUniformLocation("min_map_dim");
            GL.Uniform2(this.min_map_dim_loc, this.min_map_dim);

            this.grid_dim_loc = this.GetUniformLocation("grid_dim");
            GL.Uniform2(this.grid_dim_loc, this.grid_dim);

            this.sel_val_loc = this.GetUniformLocation("sel_val");
            GL.Uniform1(this.sel_val_loc, this.sel_val);
        }

        /// <summary>
        /// Gets a Uniform Location of the actual shader program
        /// </summary>
        /// <param name="uniformName"></param>
        /// <returns></returns>
        public int GetUniformLocation(string uniformName)
        {
            int uniformLoc = GL.GetUniformLocation(this.prog, uniformName);

            Console.WriteLine("-> Shader:\t\tUniform Location of {0} is {1}", uniformName, uniformLoc);

            return uniformLoc;
        }

        public void EnableShader()
        {
            GL.UseProgram(this.prog);

            GL.GetFloat(GetPName.ModelviewMatrix, out Utility.Mat_ModelView);
            GL.GetFloat(GetPName.ProjectionMatrix, out Utility.Mat_Projection);
            GL.GetFloat(GetPName.Viewport, out Utility.Viewport);

            GL.UniformMatrix4(this.mv_matrix_loc, false, ref Utility.Mat_ModelView);
            GL.UniformMatrix4(this.pr_matrix_loc, false, ref Utility.Mat_Projection);
            GL.Uniform4(this.viewport_loc, ref Utility.Viewport);

            GL.Uniform3(this.view_direc_3d_loc, ref Utility.View_Direction_3D);
            GL.Uniform3(this.view_direc_2d_loc, ref Utility.View_Direction_2D);
            GL.Uniform3(this.cam_pos_vplots_loc, ref Utility.Cam_Pos_MapGlyphs);

            GL.Uniform1(this.ani_time_loc, Shader.ani_time);

            GL.Uniform1(this.brushing_col_loc, (Utility.Max_Region_Colors*3), this.brushing_col);
        }

        public void DisableShader()
        {
            GL.UseProgram(0);
        }

        #endregion

        #region IDisposable Member

        public void Dispose()
        {
            Console.WriteLine("-> Shader:\t\t\tdisposing (" + this.prog + ")");

            GL.DeleteProgram(this.prog);
        }

        #endregion
    }
}
