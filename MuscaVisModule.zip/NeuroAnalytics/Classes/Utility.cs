﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK;
using System.Drawing;
using System.IO;

namespace NeuroAnalytics
{
    public class Utility
    {
        #region - Private Variables -

        // number controling
        public static readonly NumberFormatInfo NumberFormat = (new CultureInfo("en-US")).NumberFormat;

        // Standard Rendering Matrices 
        public static Matrix4 Mat_ModelView;
        public static Matrix4 Mat_Projection;
        public static Vector4 Viewport;

        // View Directions
        public static Vector3 View_Direction_3D;
        public static Vector3 Cam_Pos_MapGlyphs;
        public static Vector3 View_Direction_2D;

        // Stent Information
        public static List<string> Stents = new List<string>();

        // Norm Factors
        public static Dictionary<string, Vector2> norm_values = new Dictionary<string, Vector2>();
        public static Dictionary<string, Vector2> norm_hist_values = new Dictionary<string, Vector2>();

        // Time Controling
        public static bool Animation_On = true;
        public static int Num_Timesteps = 1;
        public static float Timespan = 0;
        public static float Cycle_Time = 0;
        public static float Systolic_Peak_Time = 0;
        public static int Num_Scalarfields = 1;
        public static int Num_Bins = 5;

        // Case Controlling
        public static string Case_ID = "2";
        public static string Study_ID = "3";

        // Animation Controlling
        public static float Animation_increase = 0.05f; // 0.005f;

        // 3D Picking Matrices
        public static Matrix4 Picking_Mat_ModelView_3D;
        public static Matrix4 Picking_Mat_Projection_3D;

        // 2D Picking Matrices
        public static Matrix4 Picking_Mat_ModelView_2DBEPPlot;
        public static Matrix4 Picking_Mat_Projection_2DBEPPlot;

        public static Matrix4 Picking_Mat_ModelView_2DSamMap;
        public static Matrix4 Picking_Mat_Projection_2DSamMap;

        //public static int Mesh_Point_Number = 0;
        public static int Map_Sample_Number = 0;

        // Scatterplot Rendering
        public static int Max_Num_Bins = 10;
        public static int Max_num_Scalar_Fields = 5;
        public static int Max_Num_Hist = Utility.Max_Num_Bins * Utility.Max_num_Scalar_Fields; // max 10 scalarfields a 20 bins 
        public static int Matrix_Size = 200; // size of one matrix subspace representing one density plot or histogram

        public static int Max_Region_Colors = 20;
        public static int Num_Regions = 0;

        public static Vector3[] Initial_Brush_Region_Colors = {
                                   new Vector3(251.0f, 180.0f, 174.0f)/255.0f,     // Light red
                                   new Vector3(128.0f, 177.0f, 221.0f)/255.0f,     // Light blue
                                   new Vector3(204.0f, 235.0f, 197.0f)/255.0f,     // Light green
                                   new Vector3(255.0f, 255.0f, 204.0f)/255.0f,     // Light yellow
                                   new Vector3(222.0f, 203.0f, 228.0f)/255.0f,     // Light purple
                                   new Vector3(254.0f, 217.0f, 166.0f)/255.0f     // Light orange
                                   };     

        #endregion

        #region - Constructors -

        #endregion

        #region - Properties -

        #endregion

        #region - Methods -

        public static Vector3 ConvertToCartCoord(ref Vector3 polar)
        {
            Vector3 cartcoord = Vector3.Zero;

            cartcoord.X = polar.X * (float)Math.Sin(polar.Y) * (float)Math.Cos(polar.Z);

            cartcoord.Y = polar.X * (float)Math.Sin(polar.Y) * (float)Math.Sin(polar.Z);

            cartcoord.Z = polar.X * (float)Math.Cos(polar.Y);

            return cartcoord;
        }

        public static Vector3 ConvertToCartCoord(Vector3 polar)
        {
            Vector3 cartcoord = Vector3.Zero;

            cartcoord.X = polar.X * (float)Math.Sin(polar.Y) * (float)Math.Cos(polar.Z);

            cartcoord.Y = polar.X * (float)Math.Sin(polar.Y) * (float)Math.Sin(polar.Z);

            cartcoord.Z = polar.X * (float)Math.Cos(polar.Y);

            return cartcoord;
        }

        public static Vector3 ConvertToEllipCartCoord(ref Vector3 polar, ref Vector3 e1, ref Vector3 e2, ref Vector3 e3)
        {
            Vector3 cartcoord = Vector3.Zero;

            float stretch = 5f;

            cartcoord.X = polar.X * (float)Math.Sin(polar.Y) * (float)Math.Cos(polar.Z);

            cartcoord.Y = polar.X * (float)Math.Sin(polar.Y) * (float)Math.Sin(polar.Z);

            cartcoord.Z = polar.X * (float)Math.Cos(polar.Y);

            cartcoord = stretch * cartcoord.X * e1 + stretch * cartcoord.Y * e2 + stretch * cartcoord.Z * e3;

            return cartcoord;
        }

        public static Vector3 ConvertToPolarCoord(Vector3 kart)
        {
            Vector3 polar_coords = Vector3.Zero;

            polar_coords.X = (float)Math.Sqrt(Math.Pow(kart.X, 2) + Math.Pow(kart.Y, 2) + Math.Pow(kart.Z, 2));

            polar_coords.Y = (float)Math.Acos((kart.Z / polar_coords.X));

            polar_coords.Z = (float)Math.Atan2(kart.Y, kart.X);

            return polar_coords;
        }

        public static Vector2 ConvertToPolarCoord(Vector2 kart)
        {
            Vector2 polar_coords = Vector2.Zero;

            float radius = (float)Math.Sqrt(Math.Pow(kart.X, 2) + Math.Pow(kart.Y, 2));

            double phihelp = Math.Acos(Math.Abs(kart.X)/radius);

            double phi = 0;

            if (kart.Y > 0.0)
            {
                phi = Math.Acos(kart.X / radius);
            }
            else if (kart.X < 0.0 && kart.Y > 0.0)
            {
                phi = Math.Acos(kart.X / radius);
            }
            else if (kart.X < 0.0 && kart.Y < 0.0)
            {
                phi = Math.PI + phihelp;
            }
            else
            {
                phi = 2.0 * Math.PI - phihelp;
            }

            polar_coords.X = radius;
            polar_coords.Y = (float)phi;

            return polar_coords;
        }

        public static float toRad(float angle)
        {
            return angle * ((float)Math.PI / 180.0f);
        }

        public static float toDeg(float rad)
        {
            return (rad * 180.0f) / (float)Math.PI;
        }

        /// <summary>
        /// Get relative project path up to the first path level
        /// </summary>
        public static string Get_Relative_Project_Path()
        {
            string projectPath = Environment.CurrentDirectory;

            string projectDirectory = Directory.GetParent(projectPath).Parent.FullName;

            string[] direc = projectDirectory.Split('\\');

            string path = direc[0];

            for (int i = 1; i < direc.Length - 2; i++)
            {
                path += @"\" + direc[i];
            }

            return path;
        }

        public static Vector3 Vector_Matrix_Multiplikation(Matrix3 m, Vector3 v)
        {
            Vector3 result = new Vector3();

            result.X = m.M11 * v.X + m.M12 * v.Y + m.M13 * v.Z;
            result.Y = m.M21 * v.X + m.M22 * v.Y + m.M23 * v.Z;
            result.Z = m.M31 * v.X + m.M32 * v.Y + m.M33 * v.Z;

            return result;
        }

        public static Vector2 Vector_Matrix_Multiplikation(Matrix2 m, Vector2 v)
        {
            Vector2 result = new Vector2();

            result.X = m.M11 * v.X + m.M12 * v.Y;
            result.Y = m.M21 * v.X + m.M22 * v.Y;

            return result;
        }

        public static Vector2 Vector_Matrix_Multiplikation(Matrix2x3 m, Vector3 v)
        {
            Vector2 result = new Vector2();

            result.X = m.M11 * v.X + m.M12 * v.Y + m.M13 * v.Z;
            result.Y = m.M21 * v.X + m.M22 * v.Y + m.M23 * v.Z;

            return result;
        }

        public static Matrix3 Vector_VectorTransposed_Multiplikation(Vector3 vec)
        {
            Matrix3 result = new Matrix3();

            result.M11 = vec.X * vec.X;
            result.M21 = vec.Y * vec.X;
            result.M31 = vec.Z * vec.X;

            result.M12 = vec.X * vec.Y;
            result.M22 = vec.Y * vec.Y;
            result.M32 = vec.Z * vec.Y;

            result.M13 = vec.X * vec.Z;
            result.M23 = vec.Y * vec.Z;
            result.M33 = vec.Z * vec.Z;

            return result;
        }

        public static float VectorTransposed_Vector_Multiplikation(Vector3 vectrans, Vector3 vec)
        {
            float result = 0;

            result = (vectrans.X * vec.X) + (vectrans.Y * vec.Y) + (vectrans.Z * vec.Z);

            return result;
        }

        public static Matrix3 Matrix_Subtraction(Matrix3 m1, Matrix3 m2)
        {
            Matrix3 result = new Matrix3();

            result.M11 = m1.M11 - m2.M11;
            result.M21 = m1.M21 - m2.M21;
            result.M31 = m1.M31 - m2.M31;

            result.M12 = m1.M12 - m2.M12;
            result.M22 = m1.M22 - m2.M22;
            result.M32 = m1.M32 - m2.M32;

            result.M13 = m1.M13 - m2.M13;
            result.M23 = m1.M23 - m2.M23;
            result.M33 = m1.M33 - m2.M33;

            return result;
        }

        public static float GetQuantile(float p, IOrderedEnumerable<float> list)
        {
            float quantilValue = GetQuantile(list, p);

            Console.WriteLine("Quantile: " + p + " = " + quantilValue);

            return quantilValue;
        }

        private static float GetQuantile(IOrderedEnumerable<float> list, float quantile)
        {
            float result;

            if (quantile >= 1.0f)
            {
                result = Utility.GetQuantile(list, 0.999999f);

                return result;
            }

            if (quantile <= 0.0f)
            {
                return 0.000f;
            }

            // Get roughly the index
            float index = quantile * list.Count();

            // Get the remainder of that index value if exists
            float remainder = index % 1;

            int indexnp;
            int indexnp1;

            if (remainder.Equals(0))
            {
                // Get the integer value of that index
                index = (float)Math.Floor(index) - 1;

                indexnp = (int)index;
                indexnp1 = (int)index + 1;

                result = 0.5f * (list.ElementAt(indexnp) + list.ElementAt(indexnp1));
            }
            else
            {
                index = (float)Math.Ceiling(index) - 1;

                result = list.ElementAt((int)index);
            }

            return result;
        }

        /// <summary>
        /// Calculate the minimum value of a symmetric matrix
        /// </summary>
        public static float CalculateMinimumValue(float[,] actmatrix)
        {
            float min = float.MaxValue;

            for (int i = 0; i < actmatrix.GetLength(0); i++)
            {
                for (int j = i + 1; j < actmatrix.GetLength(1); j++)
                {
                    if (actmatrix[i, j] < min)
                    {
                        min = actmatrix[i, j];
                    }
                }
            }

            return min;
        }

        public static void Dispose()
        {
            Utility.Mat_ModelView = Matrix4.Identity;
            Utility.Mat_Projection = Matrix4.Identity;
            Utility.Viewport = Vector4.UnitX;

            Utility.Picking_Mat_ModelView_3D = Matrix4.Identity;
            Utility.Picking_Mat_Projection_3D = Matrix4.Identity;

            Utility.Num_Timesteps = 0;

            Utility.Timespan = 0;

            Utility.Cycle_Time = 0;

            //Utility.Mesh_Point_Number = 0;

            Console.WriteLine("-> Utility:\t\tdisposed");
        }

        #endregion
    }
}
