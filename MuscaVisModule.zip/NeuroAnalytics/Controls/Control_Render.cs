﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenTK;
using OpenTK.Graphics.OpenGL;

namespace NeuroAnalytics
{
    public partial class Control_Render : GLControl
    {
        #region - Private Variables -

        private bool loaded = false;

        // function pointer 
        public delegate void CameraPointer(int width, int height);
        private CameraPointer camPtr;

        public delegate void RenderPointer();
        private RenderPointer rndPtr;

        // Abuffer
        public delegate void SetupABufferPointer();
        private SetupABufferPointer setABPtr;

        public delegate void ClearABufferPointer();
        private ClearABufferPointer clearABPtr;

        public delegate void SetABufferSizePointer(int width, int height);
        private SetABufferSizePointer setABSizePtr;

        public delegate void ClearABContentPointer();
        private ClearABContentPointer clearABContentPtr;

        public delegate void RenderABContentPointer();
        private RenderABContentPointer rndABContentPtr;

        //Scatterplot
        public delegate void SetupScatterBufferPointer();
        private SetupScatterBufferPointer setScatterPtr;

        public delegate void ClearScatterContentPointer();
        private ClearScatterContentPointer clearScatterContentPtr;

        public delegate void RenderScatterContentPointer();
        private RenderScatterContentPointer rndScatterContentPtr;

        // Framebuffer
        public delegate void SetupFBufferPointer();
        private SetupFBufferPointer setFBPtr;

        public delegate void SetFBufferSizePointer(int width, int height);
        private SetFBufferSizePointer setFBSizePtr;

        #endregion

        #region - Constructors -

        public Control_Render()
        {
            this.InitializeComponent();
        }

        #endregion

        #region - Properties -

        public CameraPointer Camerapnt
        {
            get { return this.camPtr; }
            set { this.camPtr = value; }
        }

        public RenderPointer Rndpnt
        {
            get { return this.rndPtr; }
            set { this.rndPtr = value; }
        }

        public SetupABufferPointer SetABPtr
        {
            get { return this.setABPtr; }
            set { this.setABPtr = value; }
        }

        public ClearABufferPointer ClearABPtr
        {
            get { return this.clearABPtr; }
            set { this.clearABPtr = value; }
        }

        public SetABufferSizePointer SetABSizePtr
        {
            get { return this.setABSizePtr; }
            set { this.setABSizePtr = value; }
        }

        public ClearABContentPointer ClearABContentPtr
        {
            get { return this.clearABContentPtr; }
            set { this.clearABContentPtr = value; }
        }

        public RenderABContentPointer RndABContentPtr
        {
            get { return this.rndABContentPtr; }
            set { this.rndABContentPtr = value; }
        }

        public SetupScatterBufferPointer SetSPPtr
        {
            get { return this.setScatterPtr; }
            set { this.setScatterPtr = value; }
        }

        public ClearScatterContentPointer ClearSPContentPtr
        {
            get { return this.clearScatterContentPtr; }
            set { this.clearScatterContentPtr = value; }
        }

        public RenderScatterContentPointer RndABSPContentPtr
        {
            get { return this.rndScatterContentPtr; }
            set { this.rndScatterContentPtr = value; }
        }

        public SetupFBufferPointer SetFBPtr
        {
            get { return this.setFBPtr; }
            set { this.setFBPtr = value; }
        }

        public SetFBufferSizePointer SetFBSizePtr
        {
            get { return this.setFBSizePtr; }
            set { this.setFBSizePtr = value; }
        }

        #endregion

        #region - Methods -

        private void SetupViewport()
        {
            int w = this.Width;
            int h = this.Height;

            GL.Viewport(0, 0, w, h); // Use all of the glControl painting area
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            this.MakeCurrent();

            GL.ClearColor(Color.White);
            GL.Enable(EnableCap.DepthTest); ;

            //GL.BlendFunc(BlendingFactorSrc.SrcAlpha, BlendingFactorDest.OneMinusSrcAlpha);

            GL.PrimitiveRestartIndex(uint.MaxValue);

            this.SetupViewport();

            if (this.camPtr != null)
            {
                this.camPtr(this.Width, this.Height);
            }

            if (this.setABPtr != null)
            {
                this.setABPtr();
            }

            if (this.setScatterPtr != null)
            {
                this.setScatterPtr();
            }

            if (this.setFBPtr != null)
            {
                this.setFBPtr();
            }

            // GL is Ready
            this.loaded = true;
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);

            this.MakeCurrent();

            if (this.setABSizePtr != null)
            {
                this.setABSizePtr(this.Width, this.Height);
            }

            if (this.clearABPtr != null)
            {
                this.clearABPtr();
            }

            if (this.setFBSizePtr != null)
            {
                this.setFBSizePtr(this.Width, this.Height);
            }

            this.SetupViewport();

            if (this.camPtr != null)
            {
                this.camPtr(this.Width, this.Height);
            }

            if (this.setABPtr != null)
            {
                this.setABPtr();
            }

            if (this.setFBPtr != null)
            {
                this.setFBPtr();
            }
        }

        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
        {
            base.OnPaint(e);

            this.MakeCurrent();

            if (!loaded) // Play nice
            {
                return;
            }

            try
            {
                GL.Enable(EnableCap.DepthTest);
                GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

                // ============================================================================================================ \\
                // Clear A Buffer Content
                // ============================================================================================================ \\
                if (this.clearABContentPtr != null)
                {
                    this.clearABContentPtr();
                }

                // ============================================================================================================ \\
                // Clear Scatter Plot Content
                // ============================================================================================================ \\
                if (this.clearScatterContentPtr != null)
                {
                    this.clearScatterContentPtr();
                }

                // ============================================================================================================ \\
                // Render new Frame
                // ============================================================================================================ \\
                if (this.camPtr != null)
                {
                    this.camPtr(this.Width, this.Height);
                }

                if (this.rndPtr != null)
                {
                    this.rndPtr();
                }

                // ============================================================================================================ \\
                // Write ABuffer Content to Full Screen Quad on Screen
                // ============================================================================================================ \\
                if (this.rndABContentPtr != null)
                {
                    this.rndABContentPtr();
                }

                // ============================================================================================================ \\
                // Write Scatterplot Content to Full Screen Quad on Screen
                // ============================================================================================================ \\
                if (this.rndScatterContentPtr != null)
                {
                    this.rndScatterContentPtr();
                }

                this.SwapBuffers();
            }
            catch (Exception)
            {
            }
        }

        public void Update_Scatter_Plot_Size()
        {
            if (this.setScatterPtr != null)
            {
                this.setScatterPtr();
            }
        }

        #endregion
    }
}
