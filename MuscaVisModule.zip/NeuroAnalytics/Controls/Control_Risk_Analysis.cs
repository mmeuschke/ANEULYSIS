﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.OpenGL;
using NeuroAnalytics.Properties;
using System.IO;
using System.Diagnostics;

namespace NeuroAnalytics
{
    public partial class Control_Risk_Analysis : UserControl
    {
        #region - Private Variables -

        // Forms
        private Form_Clustering form_clust_weights;
        private Form_BEPParameters form_bep_parameters;

        // Views
        private Control_Render View3D;
        private Control_Render ViewBEPPlot;
        private Control_Render ViewMatrix;
        private Control_Render ViewMapGlyphs;
        private Control_Render ViewBEPLegend;

        private Control_Render ViewColorLeg_1;
        private Control_Render ViewColorLeg_2;

        private SelectionRangeSlider range_fst_slider;
        private SelectionRangeSlider range_snd_slider;

        private Vector3[] colors_leg_1 = new Vector3[]
            {
                new Vector3(247,252,185)/255.0f, 
                new Vector3(217,240,163)/255.0f, 
                new Vector3(173,221,142)/255.0f, 
                new Vector3(120,198,121)/255.0f,
                new Vector3(65,171,93)/255.0f,
                new Vector3(35,132,67)/255.0f,
                new Vector3(0,104,55)/255.0f,
                new Vector3(0,69,41)/255.0f
            };

        private Vector3[] colors_leg_2 = new Vector3[]
            {
                new Vector3(224,236,244)/255.0f, 
                new Vector3(191,211,230)/255.0f, 
                new Vector3(158,188,218)/255.0f, 
                new Vector3(140,150,198)/255.0f,
                new Vector3(140,107,177)/255.0f,
                new Vector3(136,65,157)/255.0f,
                new Vector3(129,15,124)/255.0f,
                new Vector3(77,0,75)/255.0f
            };

        private float offset = 100.0f / 7.0f;
        private float offset2 = 99.0f / 4.0f;

        //Cameras
        private Camera cam_3D;
        private Camera cam_bepplot;
        private Camera cam_beplegend;
        private Camera cam_matrix;
        private Camera cam_mapglyphs;

        Random xoff = new Random(1);
        Random yoff = new Random(5);

        Random seed = new Random();

        int frame_counter = 0;

        //ABuffer
        private ABuffer abuf_3D;
        private ABuffer abuf_2D;

        //Framebuffer
        private Framebuffer fbuf_2D;

        // Scatterplot
        private Scatterplot scat_plot;
        private bool brushing_on;

        // number of frames per second
        private uint fps = 0;

        // Data
        private string selected_dataset_path;

        private RenderCollection renderdata;

        // Map generation
        private List<int> ostium_indices;
        private List<int> dome_indices;

        private bool ostium_selected = false;
        private bool dome_selected = false;

        // Map Info
        private bool map_selected = false;

        // Map Region Analysis
        private bool map_region_analysis = false;

        //Rendering
        private string act_render_mesh_fst;
        private string act_render_smap_fst;

        private string act_render_mesh_snd;
        private string act_render_smap_snd;

        private string act_fst_sel_sf; // first selected scalar field --> color
        private string act_snd_sel_sf; // second selected scalar fiels --> hatching

        private TextBox act_sel_pos_val; // Label that shows map values on selected position

        // 3D Camera Drive Interaction
        private int single_point_cam_drive_index;

        private float camera_animation_time = 0;

        private bool single_point_camera_drive = false;

        private bool animation_selected = false;

        private bool glyph_adding = false;

        private float bep_plot_zooming;

        // Region brushing

        private int act_region_id;

        private Color act_region_col;

        private List<Vector3> sel_brush_colors;

        #endregion

        #region - Constructors -

        public Control_Risk_Analysis()
        {
            this.InitializeComponent();

            this.form_clust_weights = new Form_Clustering();
            this.form_clust_weights.Parent_Control = this;

            this.form_bep_parameters = new Form_BEPParameters();
            this.form_bep_parameters.Parent_Control = this;

            this.cam_3D = new Camera(new Vector3(30.0f, (float)Math.PI / 4.0f, 1.5f * (float)Math.PI), 5 * Vector3.UnitZ, Vector3.UnitZ, 1f, 100.0f);
            this.cam_bepplot = new Camera(Utility.ConvertToPolarCoord(Vector3.UnitZ), Vector3.Zero, Vector3.UnitY, -10, 10.0f);
            this.cam_beplegend = new Camera(Utility.ConvertToPolarCoord(Vector3.UnitZ), Vector3.Zero, Vector3.UnitY, -10, 10.0f);
            this.cam_matrix = new Camera(Utility.ConvertToPolarCoord(2*Vector3.UnitZ), Vector3.Zero, Vector3.UnitY, 1f, 10.0f);
            //this.cam_mapglyphs = new Camera(new Vector3(30.0f, (float)Math.PI / 4.0f, (float)(Math.PI/2.0f)), Vector3.UnitZ, Vector3.UnitZ, 0.1f, 100.0f);
            this.cam_mapglyphs = new Camera(new Vector3(30.0f, (float)Math.PI / 4.0f, 1.5f * (float)Math.PI), Vector3.UnitZ, Vector3.UnitZ, 1f, 100.0f);

            this.bep_plot_zooming = -0.003f;

            this.abuf_3D = new ABuffer();
            this.abuf_2D = new ABuffer();

            this.fbuf_2D = new Framebuffer();

            this.scat_plot = new Scatterplot();
            this.brushing_on = false;

            this.selected_dataset_path = "";

            this.ostium_indices = new List<int>();
            this.dome_indices = new List<int>();

            this.act_render_mesh_fst = "";
            this.act_render_smap_fst = "";

            this.act_fst_sel_sf = "";
            this.act_snd_sel_sf = "";

            this.act_sel_pos_val = new TextBox();
            this.act_sel_pos_val.Multiline = true;
            this.act_sel_pos_val.Visible = false;
            this.Pnl_View_MapGlyph.Controls.Add(this.act_sel_pos_val);

            this.act_region_id = -1;
            this.act_region_col = Color.White;
            this.sel_brush_colors = new List<Vector3>();
        }

        #endregion

        #region - Properties -

        public string Selected_Dataset_Path
        {
            get { return this.selected_dataset_path; }
            set { this.selected_dataset_path = value; }
        }

        public RenderCollection RenderData
        {
            get { return this.renderdata; }
            set { this.renderdata = value; }
        }

        #endregion

        #region - Methods -

        #region - Rendering -

        #region - Init Render Context -

        private void Control_Risk_Analysis_Load(object sender, EventArgs e)
        {
            this.Init_Gui_Elements();

            this.Load_OpenGL_Render_Context();
        }

        private void Init_Gui_Elements()
        {
            this.Update_Matrix_Gui();

            this.Init_Time_Plot();

            this.range_fst_slider = new SelectionRangeSlider();
            this.range_fst_slider.Min = 0;
            this.range_fst_slider.Max = 100;
            this.range_fst_slider.Width = this.Grp_Bx_Fst_Color_Scale.Width - 29; ;
            this.range_fst_slider.Height = 20;
            this.range_fst_slider.Value = 100;

            this.range_fst_slider.Location = new Point(2, 163);
            this.range_fst_slider.Anchor = AnchorStyles.Left;
            this.range_fst_slider.Anchor = AnchorStyles.Right;

            this.range_fst_slider.MouseClick += new MouseEventHandler(this.View_Color_Scale_Fst_Rerange_Click);

            this.range_snd_slider = new SelectionRangeSlider();
            this.range_snd_slider.Min = 0;
            this.range_snd_slider.Max = 100;
            this.range_snd_slider.Width = this.Grp_Bx_Snd_Color_Scale.Width - 29;
            this.range_snd_slider.Height = 20;
            this.range_snd_slider.Value = 100;

            this.range_snd_slider.Location = new Point(2, 163);
            this.range_snd_slider.Anchor = AnchorStyles.Left;
            this.range_snd_slider.Anchor = AnchorStyles.Right;

            this.range_snd_slider.MouseClick += new MouseEventHandler(this.View_Color_Scale_Snd_Rerange_Click);
         
            this.Grp_Bx_Fst_Color_Scale.Controls.Add(this.range_fst_slider);
            this.Grp_Bx_Snd_Color_Scale.Controls.Add(this.range_snd_slider);

            this.Init_Color_Dialog();
        }

        /// <summary>
        /// Initializes the OpenGl Render Controls
        /// </summary>
        private void Load_OpenGL_Render_Context()
        {
            this.View3D = new Control_Render();
            this.ViewBEPPlot = new Control_Render();
            this.ViewBEPLegend = new Control_Render();
            this.ViewMatrix = new Control_Render();
            this.ViewMapGlyphs = new Control_Render();

            this.ViewColorLeg_1 = new Control_Render();
            this.ViewColorLeg_2 = new Control_Render();

            this.View3D.Dock = DockStyle.Fill;
            this.ViewBEPPlot.Dock = DockStyle.Fill;
            this.ViewBEPLegend.Dock = DockStyle.Fill;
            this.ViewMatrix.Dock = DockStyle.Fill;
            this.ViewMapGlyphs.Dock = DockStyle.Fill;

            this.ViewColorLeg_1.Dock = DockStyle.Fill;
            this.ViewColorLeg_2.Dock = DockStyle.Fill;

            this.View3D.Camerapnt = new Control_Render.CameraPointer(this.Setup_Camera_3D);
            this.View3D.Rndpnt = new Control_Render.RenderPointer(this.Render_View_3D);

            this.ViewBEPPlot.Camerapnt = new Control_Render.CameraPointer(this.Setup_Camera_BEP);
            this.ViewBEPPlot.Rndpnt = new Control_Render.RenderPointer(this.Render_View_BEPPlot);

            this.ViewBEPLegend.Camerapnt = new Control_Render.CameraPointer(this.Setup_Camera_BEP_Legend);
            this.ViewBEPLegend.Rndpnt = new Control_Render.RenderPointer(this.Render_View_BEPLegend);

            this.ViewMatrix.Camerapnt = new Control_Render.CameraPointer(this.Setup_Camera_Matrix);
            this.ViewMatrix.Rndpnt = new Control_Render.RenderPointer(this.Render_View_Matrix);

            this.ViewMapGlyphs.Camerapnt = new Control_Render.CameraPointer(this.Setup_Camera_MapGlyphs);
            this.ViewMapGlyphs.Rndpnt = new Control_Render.RenderPointer(this.Render_View_MapGlyphs);

            this.ViewColorLeg_1.Rndpnt = new Control_Render.RenderPointer(this.Render_Color_Legend_1);
            this.ViewColorLeg_2.Rndpnt = new Control_Render.RenderPointer(this.Render_Color_Legend_2);

            // Abuffer for 3D View
            this.View3D.SetABPtr = new Control_Render.SetupABufferPointer(this.abuf_3D.SetupABuffer);
            this.View3D.ClearABPtr = new Control_Render.ClearABufferPointer(this.abuf_3D.ClearBuffers);
            this.View3D.SetABSizePtr = new Control_Render.SetABufferSizePointer(this.abuf_3D.SetABufferSize);
            this.View3D.ClearABContentPtr = new Control_Render.ClearABContentPointer(this.abuf_3D.ClearABufferContent);
            this.View3D.RndABContentPtr = new Control_Render.RenderABContentPointer(this.abuf_3D.RenderABufferContent);

            //// Abuffer for 2D MapGlyphs View
            this.ViewMapGlyphs.SetABPtr = new Control_Render.SetupABufferPointer(this.abuf_2D.SetupABuffer);
            this.ViewMapGlyphs.ClearABPtr = new Control_Render.ClearABufferPointer(this.abuf_2D.ClearBuffers);
            this.ViewMapGlyphs.SetABSizePtr = new Control_Render.SetABufferSizePointer(this.abuf_2D.SetABufferSize);
            this.ViewMapGlyphs.ClearABContentPtr = new Control_Render.ClearABContentPointer(this.abuf_2D.ClearABufferContent);
            this.ViewMapGlyphs.RndABContentPtr = new Control_Render.RenderABContentPointer(this.abuf_2D.RenderABufferContent);

            // Framebuffer for 2D MapGlyphs View
            //this.ViewMapGlyphs.SetFBPtr = new Control_Render.SetupFBufferPointer(this.fbuf_2D.SetupFramebuffer);
            //this.ViewMapGlyphs.SetFBSizePtr = new Control_Render.SetFBufferSizePointer(this.fbuf_2D.SetFramebufferSize);

            // Scatterplot for 3D View
            this.View3D.SetSPPtr = new Control_Render.SetupScatterBufferPointer(this.scat_plot.Setup_Textures);
            this.View3D.ClearSPContentPtr = new Control_Render.ClearScatterContentPointer(this.scat_plot.Clear_Texture_Buffers);

            //Scatterplot for Matrix View
            this.ViewMatrix.SetSPPtr = new Control_Render.SetupScatterBufferPointer(this.scat_plot.Setup_Textures);
            this.ViewMatrix.RndABContentPtr = new Control_Render.RenderABContentPointer(this.scat_plot.RenderScatterplotBufferContent);

            //Scatterplot for Map View
            //this.ViewMap.SetSPPtr = new Control_Render.SetupScatterBufferPointer(this.scat_plot.Setup_Textures);
            //this.ViewMap.ClearSPContentPtr = new Control_Render.ClearScatterContentPointer(this.scat_plot.ClearBrushingMapBufferContent);

            // Mouse Events for 3D View
            this.View3D.MouseWheel += new MouseEventHandler(this.View3D_MouseWheel);
            this.View3D.MouseMove += new MouseEventHandler(this.View_3D_MouseMove);
            this.View3D.MouseClick += new MouseEventHandler(this.View3D_MouseClick);

            // Mouse Events for Map View
            this.ViewBEPPlot.MouseWheel += new MouseEventHandler(this.ViewBEP_MouseWheel);
            this.ViewBEPPlot.MouseMove += new MouseEventHandler(this.View_BEP_MouseMove);
            this.ViewBEPPlot.MouseClick += new MouseEventHandler(this.ViewBEP_MouseClick);

            // Mouse Events for Matrix View
            this.ViewMatrix.MouseMove += new MouseEventHandler(this.View_Matrix_MouseMove);

            // Mouse Events for VPlots View
            this.ViewMapGlyphs.MouseWheel += new MouseEventHandler(this.View_MapGlyphs_MouseWheel);
            this.ViewMapGlyphs.MouseMove += new MouseEventHandler(this.View_MapGlyphs_MouseMove);
            this.ViewMapGlyphs.MouseClick += new MouseEventHandler(this.ViewMapGlyphs_MouseClick);

            //Key Events for 3D View
            this.View3D.KeyPress += new KeyPressEventHandler(this.View3D_KeyEnter);
            this.View3D.KeyUp += new KeyEventHandler(this.View3D_KeyUp);
            this.View3D.KeyDown += new KeyEventHandler(this.View3D_KeyDown);

            // Key Events for Map View
            this.ViewMapGlyphs.KeyPress += new KeyPressEventHandler(this.ViewMapGlyphs_KeyEnter);
            this.ViewMapGlyphs.KeyUp += new KeyEventHandler(this.ViewMapGlyphs_KeyUp);

            //Key Events for Matrix View
            this.ViewMatrix.KeyPress += new KeyPressEventHandler(this.ViewMatrix_KeyEnter);
            this.ViewMatrix.KeyUp += new KeyEventHandler(this.ViewMatrix_KeyUp);

            // Add Views to corresponding subpanel
            this.Pnl_View3D.Controls.Add(this.View3D);
            this.Pnl_Scatterplot.Controls.Add(this.ViewMatrix);
            this.Pnl_View_Map.Controls.Add(this.ViewBEPPlot);
            this.Pnl_LegendView.Controls.Add(this.ViewBEPLegend);
            this.Pnl_View_MapGlyph.Controls.Add(this.ViewMapGlyphs);

           this.Pnl_ColorLeg_1.Controls.Add(this.ViewColorLeg_1);
           this.Pnl_ColorLeg_2.Controls.Add(this.ViewColorLeg_2);
        }

        public void Update_Matrix_Gui()
        {
            if (this.renderdata== null)
            {
                return;
            }

            if (this.renderdata.Render_Meshes_3D == null)
            {
                return;
            }

            if (this.renderdata.Render_Meshes_3D.Count < 1)
            {
                return;
            }

            int number = this.renderdata.Render_Meshes_3D.First().Value.Scalar_Data.Count;

            if (this.GrpBx_ParameterColumn.Controls.Count > 0)
            {
                this.GrpBx_ParameterColumn.Controls.Clear();
                this.GrpBx_ParameterRow.Controls.Clear();
            }

            int i = 0;
       

            string file_row = Utility.Get_Relative_Project_Path() + @"\Dependencies\Images\ButtonBlue2.png";
            string file_col = Utility.Get_Relative_Project_Path() + @"\Dependencies\Images\ButtonGreen.png";

            Image btn_row_image = Image.FromFile(file_row);
            Image btn_col_image = Image.FromFile(file_col);

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> item in this.renderdata.Render_Meshes_3D.First().Value.Scalar_Data)
            {
                Button btn_col = new Button();
                btn_col.FlatStyle = FlatStyle.Flat;
                btn_col.Size = new Size((this.Pnl_Scatterplot.Width / number) - 1, 32);
                btn_col.Location = new Point(i * btn_col.Size.Width + 3, 9);
                btn_col.Text = item.Key;
                btn_col.Tag = 0;
                btn_col.BackgroundImage = btn_col_image;
                btn_col.BackgroundImageLayout = ImageLayout.Stretch;
                btn_col.Click += new EventHandler(this.Matrix_Btn_Click);

                this.GrpBx_ParameterColumn.Controls.Add(btn_col);

                Button btn_row = new Button();
                btn_row.FlatStyle = FlatStyle.Flat;
                btn_row.Size = new Size(32, (this.Pnl_Scatterplot.Height / number) - 2);
                btn_row.Location = new Point(4, i * btn_row.Size.Height + 9);
                btn_row.Text = item.Key;
                btn_row.Tag = 1;
                btn_row.BackgroundImage = btn_row_image;
                btn_row.BackgroundImageLayout = ImageLayout.Stretch;
                btn_row.Click += new EventHandler(this.Matrix_Btn_Click);

                this.GrpBx_ParameterRow.Controls.Add(btn_row);

                i++;
            }

            if (this.Cmb_Bx_StentSelectionTop.Items.Count > 0)
            {
                this.Cmb_Bx_StentSelectionTop.Items.Clear();
            }

            if (this.Cmb_Bx_StentSelectionBottom.Items.Count > 0)
            {
                this.Cmb_Bx_StentSelectionBottom.Items.Clear();
            }

            for (int j = 0; j < Utility.Stents.Count; j++)
            {
                this.Cmb_Bx_StentSelectionTop.Items.Add(Utility.Stents[j]);
                this.Cmb_Bx_StentSelectionBottom.Items.Add(Utility.Stents[j]);
            }

            if (this.Cmb_Bx_StentSelectionTop.Items.Count > 0)
            {
                this.Cmb_Bx_StentSelectionTop.SelectedIndex = 0;
            }

            if (this.Cmb_Bx_StentSelectionBottom.Items.Count > 0)
            {
                this.Cmb_Bx_StentSelectionBottom.SelectedIndex = 0;
            }

            this.Update_Labels();

            this.Init_Button_Selection();

            this.Rd_Btn_Local_Scat.Checked = true;
            this.RdBtn_Hatching.Checked = true;
        }

        private void Update_Labels()
        {
            this.Set_Histogramm_Labels(this.act_render_mesh_fst, "first", true);
            this.Set_Histogramm_Labels(this.act_render_mesh_snd, "second", false);

            this.Set_Legend_Labels();
        }

        private void Set_Histogramm_Labels(string key, string label, bool is_upper_matrix)
        {
            if (key == null)
            {
                return;
            }

            string name;
            string text;
            int sp_section_x;
            int sp_section_y;
            int bin_section;
            int bin_width;
            int sf_counter = 0;
            int x, y;
            int x_size;
            int y_size;

            foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in this.renderdata.Render_Meshes_3D[key].Scalar_Data)
            {
                float range = Utility.norm_values[kvp.Key].Y / (float)Utility.Num_Bins;

                for (int j = 0; j < Utility.Num_Bins; j++)
                {
                    name = label + (kvp.Key + j).ToString();
                    text = String.Format("{0:F2}", ((j + 1) * range));

                    sp_section_x = this.ViewMatrix.Width / Utility.Num_Scalarfields;
                    sp_section_y = this.ViewMatrix.Height / Utility.Num_Scalarfields;
                    bin_width = sp_section_x / Utility.Num_Bins;
                    bin_section = bin_width * j;

                    x_size = text.ToCharArray().Length * 5;
                    y_size = 8;
                    x = this.ViewMatrix.Location.X + (sp_section_x * sf_counter) + bin_section + ((bin_width - x_size) / 2);
                    y = ((sf_counter + 1) * sp_section_y) - y_size-1;

                    if (is_upper_matrix)
                    {
                        y = ((sf_counter + 1) * sp_section_y) - (sp_section_y / 2) - y_size-1;
                    }

                    if (this.Pnl_Scatterplot.Controls.ContainsKey(name))
                    {
                        this.Pnl_Scatterplot.Controls[name].Text = text;
                        this.Pnl_Scatterplot.Controls[name].Location = new Point(x, y);
                        this.Pnl_Scatterplot.Controls[name].Size = new Size(x_size, y_size);
                    }
                    else
                    {
                        Label hist_lab = new Label();
                        hist_lab.Text = text;

                        hist_lab.Location = new Point(x, y);
                        hist_lab.BackColor = Color.Transparent;
                        hist_lab.Size = new Size(x_size, y_size);
                        hist_lab.Font = new Font(hist_lab.Font.Name, 6);
                        hist_lab.Name = name;
                        this.Pnl_Scatterplot.Controls.Add(hist_lab);

                        hist_lab.BringToFront();
                    }
                }

                sf_counter++;
            }
        }

        private void Set_Legend_Labels()
        {
            try
            {
                foreach (Control item in this.Pnl_LegendView.Controls)
                {
                    if (item is Label)
                    {
                        this.Pnl_LegendView.Controls.Remove(item);
                    }
                }
            }
            catch (Exception)
            {
            }
           
            string labelname = "";

            int count = 0;

            foreach (string name in this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Parameter_Names)
            {
                labelname = name.Substring(0,3);

                Label hist_lab = new Label();
                hist_lab.Text = labelname;

                hist_lab.Location = new Point((this.Pnl_LegendView.Width/2)-13, (this.Pnl_LegendView.Height/2)-22-count);
                hist_lab.BackColor = Color.White;
                hist_lab.Size = new Size(32, 12);
                hist_lab.Font = new Font(hist_lab.Font.Name, 8);
                hist_lab.Name = name;
                this.Pnl_LegendView.Controls.Add(hist_lab);

                hist_lab.BringToFront();

                count += 25;
            }
        }

        private void Init_Button_Selection()
        {
            if (this.renderdata.Render_Meshes_3D.Count < 1)
            {
                return;
            }

            if (this.renderdata.Render_Meshes_3D.First().Value.Scalar_Data.Keys.Count > 1)
            {
                List<String> myKeys = this.renderdata.Render_Meshes_3D.First().Value.Scalar_Data.Keys.ToList();

                foreach (Button item in this.GrpBx_ParameterColumn.Controls)
                {
                    if (item is Button && item.Text == myKeys[0])
                    {
                        item.BackColor = Color.SandyBrown;

                        this.act_fst_sel_sf = myKeys[0];
                    }
                }

                foreach (Button item in this.GrpBx_ParameterRow.Controls)
                {
                    if (item is Button && item.Text == myKeys[1])
                    {
                        item.BackColor = SystemColors.ScrollBar;

                        this.act_snd_sel_sf = myKeys[1];
                    }
                }

                float fst_min = Utility.norm_values[this.act_fst_sel_sf].X;
                float fst_max = Utility.norm_values[this.act_fst_sel_sf].Y;
                float snd_min = Utility.norm_values[this.act_snd_sel_sf].X;
                float snd_max = Utility.norm_values[this.act_snd_sel_sf].Y;
                   
                this.Update_Color_Scale(fst_min, fst_max, snd_min, snd_max);
            }
        }

        #endregion

        #region - Setup Cameras -

        /// <summary>
        /// Setup 3D perspective camera
        /// </summary>
        private void Setup_Camera_3D(int width, int height)
        {
            GL.MatrixMode(MatrixMode.Projection);

            GL.LoadIdentity();

            Matrix4 projection = Matrix4.CreatePerspectiveFieldOfView((float)Math.PI / 3.0f, (float)width / (float)height, this.cam_3D.Near_Plane, this.cam_3D.Far_Plane);

            //Matrix4 projection = this.Create_Frustum((float)Math.PI / 3.0f, (float)width / (float)height, this.cam_3D.Near_Plane, this.cam_3D.Far_Plane);

            Utility.Picking_Mat_Projection_3D = projection;

            GL.MultMatrix(ref projection);

            GL.MatrixMode(MatrixMode.Modelview);

            GL.LoadIdentity();

            Matrix4 modelview = Matrix4.LookAt(this.cam_3D.EyePos_Kart, this.cam_3D.Center, this.cam_3D.Up_Vector);

            Utility.Picking_Mat_ModelView_3D = modelview;

            Utility.View_Direction_3D = this.cam_3D.Center - this.cam_3D.EyePos_Kart;

            GL.MultMatrix(ref modelview);
        }

        private Matrix4 Create_Frustum(float fovY, float aspect, float zNear, float zFar)
        {
            //float pi = 3.1415926535897932384626433832795f;
            float fW, fH;

            this.xoff = new Random(this.seed.Next());
            this.yoff = new Random(this.seed.Next());

            fH = (float)Math.Tan(fovY/2) * zNear;
            fW = fH * aspect;
           
            float left = -fW;
            float right = fW;
            float top = -fH;
            float bottom = fH;

            float scalex, scaley;

            float width = this.View3D.Width;
            float height = this.View3D.Height;

            scalex = (right - left)/width;
            scaley = (top - bottom)/height;

            return Matrix4.CreatePerspectiveOffCenter(left - (float)this.xoff.NextDouble() * scalex, right - (float)this.xoff.NextDouble() * scalex, top - (float)this.yoff.NextDouble() * scaley,
              bottom - (float)this.yoff.NextDouble() * scaley, zNear, zFar);
        }

        /// <summary>
        /// Setup 2D orthographic bep camera
        /// </summary>
        private void Setup_Camera_BEP(int width, int height)
        {
            GL.MatrixMode(MatrixMode.Projection);

            GL.LoadIdentity();

            Matrix4 projection = Matrix4.CreateOrthographic((0.006f - this.bep_plot_zooming) * (float)width, (0.006f - this.bep_plot_zooming) * (float)height, this.cam_bepplot.Near_Plane, this.cam_bepplot.Far_Plane);

            Utility.Picking_Mat_Projection_2DBEPPlot = projection;

            GL.MultMatrix(ref projection);

            GL.MatrixMode(MatrixMode.Modelview);

            GL.LoadIdentity();

            Matrix4 modelview = Matrix4.LookAt(this.cam_bepplot.EyePos_Kart, this.cam_bepplot.Center, this.cam_bepplot.Up_Vector);

            Utility.Picking_Mat_ModelView_2DBEPPlot = modelview;

            GL.MultMatrix(ref modelview);
        }

        /// <summary>
        /// Setup 2D orthographic bep legend camera
        /// </summary>
        private void Setup_Camera_BEP_Legend(int width, int height)
        {
            GL.MatrixMode(MatrixMode.Projection);

            GL.LoadIdentity();

            Matrix4 projection = Matrix4.CreateOrthographic((0.005f) * (float)width, (0.005f) * (float)height, this.cam_beplegend.Near_Plane, this.cam_beplegend.Far_Plane);

            GL.MultMatrix(ref projection);

            GL.MatrixMode(MatrixMode.Modelview);

            GL.LoadIdentity();

            Matrix4 modelview = Matrix4.LookAt(this.cam_beplegend.EyePos_Kart, this.cam_beplegend.Center, this.cam_beplegend.Up_Vector);

            GL.MultMatrix(ref modelview);
        }

        /// <summary>
        /// Setup 2D orthographic matrix camera
        /// </summary>
        private void Setup_Camera_Matrix(int width, int height)
        {
            GL.MatrixMode(MatrixMode.Projection);

            GL.LoadIdentity();

            Matrix4 projection = Matrix4.CreateOrthographic(0.00214f * (float)width, 0.0046f * (float)height, this.cam_matrix.Near_Plane, this.cam_matrix.Far_Plane);

            GL.MultMatrix(ref projection);

            GL.MatrixMode(MatrixMode.Modelview);

            GL.LoadIdentity();

            Matrix4 modelview = Matrix4.LookAt(this.cam_matrix.EyePos_Kart, this.cam_matrix.Center, this.cam_matrix.Up_Vector);

            GL.MultMatrix(ref modelview);
        }

        /// <summary>
        /// Setup 3D perspective vplots camera
        /// </summary>
        private void Setup_Camera_MapGlyphs(int width, int height)
        {
            GL.MatrixMode(MatrixMode.Projection);

            GL.LoadIdentity();

            Matrix4 projection = Matrix4.CreatePerspectiveFieldOfView((float)Math.PI / 3.0f, (float)width / (float)height, this.cam_mapglyphs.Near_Plane, this.cam_mapglyphs.Far_Plane);
           
            Utility.Picking_Mat_Projection_2DSamMap = projection;

            GL.MultMatrix(ref projection);

            GL.MatrixMode(MatrixMode.Modelview);

            GL.LoadIdentity();

            Matrix4 modelview = Matrix4.LookAt(this.cam_mapglyphs.EyePos_Kart, this.cam_mapglyphs.Center, this.cam_mapglyphs.Up_Vector);

            Utility.Picking_Mat_ModelView_2DSamMap = modelview;

            Utility.View_Direction_2D = this.cam_mapglyphs.Center - this.cam_mapglyphs.EyePos_Kart;
            Utility.Cam_Pos_MapGlyphs = this.cam_mapglyphs.EyePos_Kart;

            GL.MultMatrix(ref modelview);
        }

        #endregion

        #region - Render Functions -

        /// <summary>
        /// 3D Render function
        /// </summary>
        private void Render_View_3D()
        {
            foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Meshes_3D)
            {
                if (kvp.Value != null)
                {
                    if (!kvp.Value.Init_Setup || !kvp.Value.Init_Shader)
                    {
                        kvp.Value.Initialize_Render_Item();
                    }

                    if (this.act_render_mesh_fst == kvp.Key || this.act_render_mesh_snd == kvp.Key)
                    {
                        kvp.Value.Render();
                    }
                }
            }

            foreach (KeyValuePair<string, List<RenderItem>> dataset in this.renderdata.Render_Stents_3D)
            {
                for (int i = 0; i < dataset.Value.Count; i++)
                {
                    if (dataset.Value[i] != null)
                    {
                        if (!dataset.Value[i].Init_Setup || !dataset.Value[i].Init_Shader)
                        {
                            dataset.Value[i].Initialize_Render_Item();
                        }

                        if (this.act_render_mesh_fst == dataset.Key)
                        {
                            dataset.Value[i].Render();
                        }
                    }
                }
            }

            foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Objects_3D)
            {
                if (kvp.Value != null)
                {
                    if (!kvp.Value.Init_Setup || !kvp.Value.Init_Shader)
                    {
                        kvp.Value.Initialize_Render_Item();
                    }

                    kvp.Value.Render();
                }
            }

            if (this.single_point_camera_drive)
            {
                this.Move_Camera_to_Single_Point(this.single_point_cam_drive_index);
            }

            if (Utility.Animation_On)
            {
                Shader.Ani_time += Utility.Animation_increase;
                
                if (Shader.Ani_time >= ((float)Utility.Num_Timesteps - 1))
                {
                    Shader.Ani_time = 0.0f;

                }

                this.Update_Time_Plot();
            }

            this.fps++;
        }

        /// <summary>
        /// Render BEP plot function
        /// </summary>
        private void Render_View_BEPPlot()
        {
            try
            {
                foreach (KeyValuePair<string, VesselPlot> kvp in this.renderdata.Aneurysm_Plots)
                {
                    if (kvp.Value != null)
                    {
                        if (!kvp.Value.Init_Setup || !kvp.Value.Init_Shader)
                        {
                            kvp.Value.Initialize_Render_Item();
                        }

                        if (this.act_render_mesh_fst == kvp.Key)
                        {
                            kvp.Value.Render();
                        }
                    }
                }
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Render BEP legend function
        /// </summary>
        private void Render_View_BEPLegend()
        {
            try
            {
                foreach (KeyValuePair<string, VesselPlot> kvp in this.renderdata.Aneurysm_Plots)
                {
                    if (kvp.Value != null && kvp.Value.Legend != null)
                    {
                        if (!kvp.Value.Legend.Init_Setup || !kvp.Value.Legend.Init_Shader)
                        {
                            kvp.Value.Legend.Initialize_Render_Item();
                        }

                        if (this.act_render_mesh_fst == kvp.Key)
                        {
                            kvp.Value.Legend.Render();
                        }
                    }
                }
            }
            catch (Exception)
            {
            }

        }

        /// <summary>
        /// Render matrix function
        /// </summary>
        private void Render_View_Matrix()
        {
            if (this.scat_plot != null)
            {
                this.scat_plot.Render_Shader.FPS_Counter = this.frame_counter;
            }
        }

        /// <summary>
        /// Render violin plots function
        /// </summary>
        private void Render_View_MapGlyphs()
        {
            foreach (KeyValuePair<string, RenderItem> kvp in this.renderdata.Render_Sampled_Maps_2D)
            {
                if (kvp.Value != null)
                {
                    if (!kvp.Value.Init_Setup || !kvp.Value.Init_Shader)
                    {
                        kvp.Value.Initialize_Render_Item();
                    }

                    if (this.act_render_smap_fst == kvp.Key)
                    {
                        kvp.Value.Render();
                    }
                }
            }
        }

        private void DrawRectangle(float x, float y, float w, float h)
        {
            GL.Begin(PrimitiveType.Quads);
            {
                GL.Color3(Color.DarkRed);
                GL.Vertex3(x, y, 0);
                GL.Vertex3(x + w, y, 0);
                GL.Vertex3(x + w, y + h, 0);
                GL.Vertex3(x, y + h, 0);
            }
            GL.End();
        }

        /// <summary>
        /// Render color legends
        /// </summary>
        private void Render_Color_Legend_1()
        {
            GL.LineWidth(10.0f);

            int counter = 0;

            GL.Begin(PrimitiveType.LineStrip);
            {
                for (float i = -50; i <= 50; i += offset)
                {
                    GL.Color3(colors_leg_1[counter]);
                    GL.Vertex3(new Vector3(0.5f, i / 50, 0.0f));

                    counter++;
                }
            }
            GL.End();

            GL.LineWidth(4.0f);


            for (float i = -50; i <= 50; i += offset2)
            {
                GL.Begin(PrimitiveType.Lines);
                {
                    GL.Color3(new Vector3(0.2f));
                    GL.Vertex3(new Vector3(-0.3f, i / 50, 0.0f));
                    GL.Vertex3(new Vector3(0.4f, i / 50, 0.0f));
                }
                GL.End();
            }

            GL.LineWidth(4.0f);

            GL.Begin(PrimitiveType.Lines);
            {
                GL.Color3(new Vector3(0.2f));
                GL.Vertex3(new Vector3(-0.3f, -0.98f, 0.0f));
                GL.Vertex3(new Vector3(0.4f, -0.98f, 0.0f));
            }
            GL.End();

            GL.LineWidth(1.0f);
        }

        /// <summary>
        /// Render color legends
        /// </summary>
        private void Render_Color_Legend_2()
        {
            GL.LineWidth(10.0f);

            int counter = 0;

            GL.Begin(PrimitiveType.LineStrip);
            {
                for (float i = -50; i <= 50; i += offset)
                {
                    GL.Color3(colors_leg_2[counter]);
                    GL.Vertex3(new Vector3(0.5f, i / 50, 0.0f));

                    counter++;
                }
            }
            GL.End();

            GL.LineWidth(4.0f);


            for (float i = -50; i <= 50; i += offset2)
            {
                GL.Begin(PrimitiveType.Lines);
                {
                    GL.Color3(new Vector3(0.2f));
                    GL.Vertex3(new Vector3(-0.3f, i / 50, 0.0f));
                    GL.Vertex3(new Vector3(0.4f, i / 50, 0.0f));
                }
                GL.End();
            }

            GL.LineWidth(4.0f);

            GL.Begin(PrimitiveType.Lines);
            {
                GL.Color3(new Vector3(0.2f));
                GL.Vertex3(new Vector3(-0.3f, -0.98f, 0.0f));
                GL.Vertex3(new Vector3(0.4f, -0.98f, 0.0f));
            }
            GL.End();

            GL.LineWidth(1.0f);

            GL.LineWidth(1.0f);
        }

        #endregion

        #region - Redraw Functions -

        /// <summary>
        /// Redraw both paint controls
        /// </summary>
        private void Application_Idle(object sender, EventArgs e)
        {
            this.Redraw_All_Views();
        }

        private void Redraw_All_Views()
        {
            if (this.View3D != null)
            {
                this.View3D.Invalidate();
            }

            if (this.ViewBEPPlot != null)
            {
                this.ViewBEPPlot.Invalidate();
            }

            if (this.ViewBEPLegend != null)
            {
                this.ViewBEPLegend.Invalidate();
            }

            if (this.ViewMatrix != null)
            {
                this.ViewMatrix.Invalidate();
            }

            if (this.ViewMapGlyphs != null)
            {
                this.ViewMapGlyphs.Invalidate();
            }

            if (this.ViewColorLeg_1 != null)
            {
                this.ViewColorLeg_1.Invalidate();
            }
        }

        /// <summary>
        /// Redraw of whole scene
        /// </summary>
        private void ReDrawTimer_Tick(object sender, EventArgs e)
        {
            //Stopwatch sw = new Stopwatch();

            //sw.Reset();
            //sw.Start();

            this.Application_Idle(sender, e);

            //sw.Stop();

            //Console.WriteLine(sw.Elapsed.Milliseconds);
        }

        private void FPSTimer_Tick(object sender, EventArgs e)
        {
            this.Txt_Bx_FPS.Text = "FPS: " + this.fps;

            this.fps = 0;
        }

        private void Update_Shaders()
        {
            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                item.Value.Update_Render_Item_Shaders();
            }

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Sampled_Maps_2D)
            {
                item.Value.Update_Render_Item_Shaders();
            }

            if (this.scat_plot != null)
            {
                this.scat_plot.Update_Shaders();
            }
        }

        public void Update_Scatter_Plot_Size()
        {
            int num_scalafields = 1;

            if (this.renderdata.Render_Meshes_3D.Count > 0)
            {
                num_scalafields = this.renderdata.Render_Meshes_3D.First().Value.Scalar_Data.Count;

                Utility.Num_Scalarfields = num_scalafields;
            }

            if (this.View3D != null)
            {
                this.View3D.Update_Scatter_Plot_Size();

                this.View3D.SetSPPtr = new Control_Render.SetupScatterBufferPointer(this.scat_plot.Setup_Textures);
                this.View3D.ClearSPContentPtr = new Control_Render.ClearScatterContentPointer(this.scat_plot.Clear_Texture_Buffers);

                this.View3D.Refresh();
            }

            if (this.ViewMatrix != null)
            {
                this.ViewMatrix.Update_Scatter_Plot_Size();

                this.ViewMatrix.SetSPPtr = new Control_Render.SetupScatterBufferPointer(this.scat_plot.Setup_Textures);

                this.ViewMatrix.RndABContentPtr = new Control_Render.RenderABContentPointer(this.scat_plot.RenderScatterplotBufferContent);

                this.ViewMatrix.Refresh();
            }
        }

        #endregion

        #endregion

        #region - GUI -

        /// <summary>
        /// Init timeline for animation
        /// </summary>
        public void Init_Time_Plot()
        {
            this.Chrt_Time.ChartAreas[0].AxisX.Minimum = 0.0;
            this.Chrt_Time.ChartAreas[0].AxisX.Maximum = Math.Round(Utility.Cycle_Time, 2);

            this.Chrt_Time.Series["Time"].Points.Clear();

            float act_time = 0;

            try
            {
                for (int i = 0; i < Utility.Num_Timesteps; i++)
                {
                    this.Chrt_Time.Series["Time"].Points.AddXY(Math.Round(act_time, 2), 0.0);

                    act_time += Utility.Timespan;
                }

                this.Chrt_Time.Series["CurrentTime"].Points[0].XValue = 0.0;
            }
            catch (System.Exception)
            {
            }
        }

        private void Update_Time_Plot()
        {
            if (!(Utility.Num_Timesteps > 0))
            {
                return;
            }

            double val = Shader.Ani_time * Utility.Timespan;

            if (val < 0.01)
            {
                this.Chrt_Time.Series["CurrentTime"].Points[0].XValue = 0.0001;
            }
            else if (val >= Utility.Cycle_Time)
            {
                this.Chrt_Time.Series["CurrentTime"].Points[0].XValue = Utility.Cycle_Time;
            }
            else
            {
                this.Chrt_Time.Series["CurrentTime"].Points[0].XValue = val;
            }
        }

        private void Current_TimeSlider_TrckBr_Scroll(object sender, EventArgs e)
        {
            try
            {
                float norm_value = ((float)this.TrckBr_CurrentTimeSlider.Value / 100.0f);

                Shader.Ani_time = (float)norm_value * (Utility.Num_Timesteps - 1);

                this.Update_Time_Plot();

                this.Redraw_All_Views();
            }
            catch (Exception)
            {
            }
        }

        private void Update_Color_Scale(float fst_min, float fst_max, float snd_min, float snd_max)
        {
            float fst_act = (fst_max - fst_min) / 4.0f;

            float fst_snd = fst_act + fst_min;

            float fst_thd = 2.0f * fst_act + fst_min;

            float fst_fth = 3.0f * fst_act + fst_min;

            this.Lbl_Col0_Fst_Scale.Text = String.Format("{0:F1}", fst_min);
            this.Lbl_Col1_Fst_Scale.Text = String.Format("{0:F1}", fst_snd);
            this.Lbl_Col2_Fst_Scale.Text = String.Format("{0:F1}", fst_thd);
            this.Lbl_Col3_Fst_Scale.Text = String.Format("{0:F1}", fst_fth);
            this.Lbl_Col4_Fst_Scale.Text = String.Format("{0:F1}", fst_max);

            float snd_act = (snd_max - snd_min) / 4.0f;

            float snd_snd = snd_act + snd_min;

            float snd_thd = 2.0f * snd_act + snd_min;

            float snd_fth = 3.0f * snd_act + snd_min;

            this.Lbl_Col0_Snd_Scale.Text = String.Format("{0:F1}", snd_min);
            this.Lbl_Col1_Snd_Scale.Text = String.Format("{0:F1}", snd_snd);
            this.Lbl_Col2_Snd_Scale.Text = String.Format("{0:F1}", snd_thd);
            this.Lbl_Col3_Snd_Scale.Text = String.Format("{0:F1}", snd_fth);
            this.Lbl_Col4_Snd_Scale.Text = String.Format("{0:F1}", snd_max);
        }

        private void Update_First_Color_Scale(float fst_min, float fst_max)
        {
            float fst_act = (fst_max - fst_min) / 4.0f;

            float fst_snd = fst_act + fst_min;

            float fst_thd = 2.0f * fst_act + fst_min;

            float fst_fth = 3.0f * fst_act + fst_min;

            this.Lbl_Col0_Fst_Scale.Text = String.Format("{0:F1}", fst_min);
            this.Lbl_Col1_Fst_Scale.Text = String.Format("{0:F1}", fst_snd);
            this.Lbl_Col2_Fst_Scale.Text = String.Format("{0:F1}", fst_thd);
            this.Lbl_Col3_Fst_Scale.Text = String.Format("{0:F1}", fst_fth);
            this.Lbl_Col4_Fst_Scale.Text = String.Format("{0:F1}", fst_max);
        }

        private void Update_Second_Color_Scale(float snd_min, float snd_max)
        {
            float snd_act = (snd_max - snd_min) / 4.0f;

            float snd_snd = snd_act + snd_min;

            float snd_thd = 2.0f * snd_act + snd_min;

            float snd_fth = 3.0f * snd_act + snd_min;

            this.Lbl_Col0_Snd_Scale.Text = String.Format("{0:F1}", snd_min);
            this.Lbl_Col1_Snd_Scale.Text = String.Format("{0:F1}", snd_snd);
            this.Lbl_Col2_Snd_Scale.Text = String.Format("{0:F1}", snd_thd);
            this.Lbl_Col3_Snd_Scale.Text = String.Format("{0:F1}", snd_fth);
            this.Lbl_Col4_Snd_Scale.Text = String.Format("{0:F1}", snd_max);
        }

        private void Init_Color_Dialog()
        {
            this.Clr_Dlg_Add_Region.CustomColors = new int[] { ColorTranslator.ToOle(Color.FromArgb(251, 180, 174)),
                                                               ColorTranslator.ToOle(Color.FromArgb(128, 177, 221)),
                                                               ColorTranslator.ToOle(Color.FromArgb(204, 235, 197)),
                                                               ColorTranslator.ToOle(Color.FromArgb(255, 255, 204)),
                                                               ColorTranslator.ToOle(Color.FromArgb(222, 203, 228)),
                                                               ColorTranslator.ToOle(Color.FromArgb(254, 217, 166))};
        }

        #endregion

        #region - Events -

        private void Control_Risk_Analysis_Resize(object sender, EventArgs e)
        {
            this.Update_Matrix_Gui();
        }

        private void Splt_Contr_Brush_Panel1_SizeChanged(object sender, EventArgs e)
        {
            this.Update_Matrix_Gui();
        }

        private void Splt_Cntr_View_Panel1_SizeChanged(object sender, EventArgs e)
        {
            this.Update_Matrix_Gui();
        }

        private void Chck_Bx_Stop_Animation_CheckedChanged(object sender, EventArgs e)
        {
            if (this.Chck_Bx_Stop_Animation.Checked)
            {
                Utility.Animation_On = false;
            }
            else
            {
                Utility.Animation_On = true;

                this.Disable_Histo_Equalize();

                this.Btn_Equalize_SP.Enabled = true;
            }
        }

        private void Chck_Bx_Peak_Systole_CheckedChanged(object sender, EventArgs e)
        {
            if (this.Chck_Bx_Peak_Systole.Checked)
            {
                Utility.Animation_On = false;

                Shader.Ani_time = Utility.Systolic_Peak_Time;

                this.Update_Time_Plot();

                this.Chck_Bx_Stop_Animation.Enabled = false;
            }
            else
            {
                Utility.Animation_On = true;

                this.Disable_Histo_Equalize();

                this.Chck_Bx_Stop_Animation.Enabled = true;

                this.Btn_Equalize_SP.Enabled = true;
            }
        }

        private void Matrix_Btn_Click(Object sender, EventArgs e)
        {
            Button act_btn = (Button)sender;

            this.View3D.MakeCurrent();

            if (this.renderdata == null)
            {
                return;
            }

            int i = 0;

            try
            {
                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
                {
                    i = 0;

                    foreach (KeyValuePair<string, Unsteady_Datafield<float>> kvp in item.Value.Scalar_Data)
                    {
                        if (kvp.Key == act_btn.Text && (int)act_btn.Tag < 1)
                        {
                            item.Value.ShaderProg.FST_Rendered_Prop = i;

                            item.Value.Update_Child_Render_Objects();

                            this.act_fst_sel_sf = kvp.Key;

                            act_btn.ForeColor = Color.MediumSeaGreen;

                            break;
                        }

                        else if (kvp.Key == act_btn.Text && (int)act_btn.Tag > 0)
                        {
                            item.Value.ShaderProg.Snd_Rendered_Prop = i;

                            item.Value.Update_Child_Render_Objects();

                            this.act_snd_sel_sf = kvp.Key;

                            act_btn.ForeColor = Color.MediumSeaGreen;

                            break;
                        }

                        i++;
                    }
                }

                this.Deactivate_Scalarfield_Button((int)act_btn.Tag, act_btn.Text);

                this.View3D.Refresh();

                this.ViewMapGlyphs.MakeCurrent();

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Sampled_Maps_2D)
                {
                    if (item.Value.ShaderProg != null)
                    {
                        if ((int)act_btn.Tag < 1)
                        {
                            item.Value.ShaderProg.FST_Rendered_Prop = i;
                        }
                        else
                        {
                            item.Value.ShaderProg.Snd_Rendered_Prop = i;
                        }

                        item.Value.Update_Child_Render_Objects();
                    }
                }

                this.ViewMapGlyphs.Refresh();

                float fst_min = Utility.norm_values[this.act_fst_sel_sf].X;
                float fst_max = Utility.norm_values[this.act_fst_sel_sf].Y;
                float snd_min = Utility.norm_values[this.act_snd_sel_sf].X;
                float snd_max = Utility.norm_values[this.act_snd_sel_sf].Y;

                this.Update_Color_Scale(fst_min, fst_max, snd_min, snd_max);

                this.Update_Fst_Color_Scale_Range();
                this.Update_Snd_Color_Scale_Range();
            }
            catch (Exception)
            {
                Console.WriteLine("Exception in Function Matrix_Btn_Click");
            }
        }

        private void Deactivate_Scalarfield_Button(int id, string text)
        {
            if (id > 0)
            {
                foreach (Button item in this.GrpBx_ParameterRow.Controls)
                {
                    if (item is Button && item.Text != text)
                    {
                         item.ForeColor = Color.Black; 
                    }
                }
            }
            else
            {
                foreach (Button item in this.GrpBx_ParameterColumn.Controls)
                {
                    if (item is Button && item.Text != text)
                    {
                        item.ForeColor = Color.Black; 
                    }
                }
            }
        }

        private void Btn_Equalize_SP_Click(object sender, EventArgs e)
        {
            if (this.scat_plot != null && this.renderdata.Render_Meshes_3D.Count > 0)
            {
                this.scat_plot.Equalize_Histo = true;

                this.scat_plot.Clear_Textures = false;

                this.scat_plot.Render_Shader.Render_Scatter_Hist = 1;

                this.ViewMatrix.Refresh();

                //this.View3D.MakeCurrent();

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
                {
                    item.Value.ShaderProg.Write_ScatterPlot = 0;
                }

                this.View3D.Refresh();

                this.Btn_Equalize_SP.Enabled = false;
            }
        }

        private void Disable_Histo_Equalize()
        {
            if (this.scat_plot != null && this.renderdata.Render_Meshes_3D.Count > 0)
            {
                this.scat_plot.Equalize_Histo = false;

                this.scat_plot.Clear_Textures = true;

                this.scat_plot.Render_Shader.Render_Scatter_Hist = 0;

                this.scat_plot.Clear_Texture_Buffers();

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
                {
                    item.Value.ShaderProg.Write_ScatterPlot = 1;
                }

                this.View3D.Refresh();

                this.ViewMatrix.Refresh();
            }
        }

        private void Btn_Clear_Brushing_Click(object sender, EventArgs e)
        {
            this.brushing_on = false;

            if (this.Lst_Vw_Regions.Items.Count > 0)
            {
                this.Lst_Vw_Regions.Items.Clear();

                this.act_region_id = -1;
                this.act_region_col = Color.White;

                if (this.sel_brush_colors.Count > 0)
                {
                    this.sel_brush_colors.Clear();
                }
            }

            this.View3D.MakeCurrent();

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                if (this.act_render_mesh_fst == item.Key)
                {
                    item.Value.Clear_Brushing();

                    break;
                }
            }

            if (this.scat_plot != null)
            {
                this.scat_plot.Clear_Texture_Buffers();

                this.scat_plot.ClearBrushing2DBufferContent();

                this.scat_plot.Brushing_Shader.Brushed_Point = new Vector2(-1, -1);

                this.scat_plot.ClearBrushingMapBufferContent();
            }

            this.View3D.Refresh();

            this.ViewBEPPlot.MakeCurrent();

            Mesh_Inner actmesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

            if (actmesh.Show_Initial_Brush)
            {
                this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Num_Regions = Utility.Num_Regions;

                this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Region_Colors = this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Init_Region_Colors();
            }
            else
            {
                this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Num_Regions = this.sel_brush_colors.Count;

                this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Region_Colors = this.sel_brush_colors.ToArray();
            }

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Clear_Brushing();

            if (actmesh.Show_Initial_Brush)
            {
                this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Vert_Segment_Indices = actmesh.Vertex_Region_IDs.ToArray();
            }

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Get_Segment_Information();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Reset_Selection();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Init_Setup = false;

            this.ViewBEPPlot.Refresh();

            this.ViewMapGlyphs.MakeCurrent();

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Sampled_Maps_2D)
            {
                if (this.act_render_smap_fst == item.Key)
                {
                    if (item.Value.ShaderProg != null)
                    {
                        item.Value.Clear_Brushing();

                        break;
                    }
                }
            }

            this.ViewMapGlyphs.Refresh();
        }

        private void RdBtn_Global_Scat_CheckedChanged(object sender, EventArgs e)
        {
            if (this.RdBtn_Global_Scat.Checked)
            {
                this.Rd_Btn_Local_Scat.Checked = false;

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
                {
                    item.Value.ShaderProg.Draw_Global_ScatterPlot = 1;
                }

                this.View3D.Refresh();
            }
        }

        private void Rd_Btn_Local_Scat_CheckedChanged(object sender, EventArgs e)
        {
            if (this.Rd_Btn_Local_Scat.Checked)
            {
                this.RdBtn_Global_Scat.Checked = false;

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
                {
                    item.Value.ShaderProg.Draw_Global_ScatterPlot = 0;
                }

                this.View3D.Refresh();
            }
        }

        private void Chck_Bx_InvertScatter_CheckedChanged(object sender, EventArgs e)
        {
            //this.View3D.MakeCurrent
            if (this.Chck_Bx_InvertScatter.Checked)
            {
                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
                {
                    item.Value.ShaderProg.Invert_ScatterPlot = 1;
                }
            }
            else
            {
                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
                {
                    item.Value.ShaderProg.Invert_ScatterPlot = 0;
                }
            }

            this.View3D.Refresh();
        }

        private void Chck_Bx_Substract_CheckedChanged(object sender, EventArgs e)
        {
            if (this.Chck_Bx_InvertScatter.Checked)
            {
                if (this.Chck_Bx_Substract.Checked)
                {
                    if (this.scat_plot != null)
                    {
                        this.scat_plot.Render_Shader.Difference_ScatterPlot = 1;
                    }
                }
                else
                {
                    if (this.scat_plot != null)
                    {
                        this.scat_plot.Render_Shader.Difference_ScatterPlot = 0;
                    }
                }

                this.ViewMatrix.Refresh();
            }
        }

        private void TrckBr_FocusValueSlider_Scroll(object sender, EventArgs e)
        {
            try
            {
                float norm_value = ((float)this.TrckBr_FocusValueSlider.Value / 100.0f);

                this.View3D.MakeCurrent();

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
                {
                    item.Value.ShaderProg.Focus_Value = norm_value;
                }

                this.View3D.Refresh();

                this.ViewMapGlyphs.MakeCurrent();

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Sampled_Maps_2D)
                {
                    item.Value.ShaderProg.Focus_Value = norm_value;
                }

                this.ViewMapGlyphs.Refresh();
            }
            catch (Exception)
            {
            }
        }

        private void NmrcUpDown_NumBins_ValueChanged(object sender, EventArgs e)
        {
            int value = (int)this.NmrcUpDown_NumBins.Value;

            Utility.Num_Bins = value;

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                item.Value.Calculate_Scalar_Histograms();
                item.Value.Get_Min_Max_Hist_Val();
            }

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                item.Value.Normalize_Histogram_Values();
            }

            this.Init_Histogram_Rendering();

            this.Update_Labels();
        }

        private void TrckBr_ScalVal_Scroll(object sender, EventArgs e)
        {
            if (this.RdBtn_Hatching.Checked)
            {
                float con_val = this.TrckBr_ScalVal.Value / 100f;

                this.ViewMapGlyphs.MakeCurrent();

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Sampled_Maps_2D)
                {
                    item.Value.ShaderProg.Contour_Val = con_val;

                    item.Value.Update_Child_Render_Objects();
                }

                this.ViewMapGlyphs.Refresh();
                
                this.View3D.MakeCurrent();

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
                {
                    item.Value.ShaderProg.Contour_Val = con_val;

                    item.Value.Update_Child_Render_Objects();
                }
                
                this.View3D.Refresh();
            }
        }

        private void TrckBr_Mesh_Opacity_Scroll(object sender, EventArgs e)
        {
            float opac_val = this.TrckBr_Mesh_Opacity.Value / 100f;

            this.View3D.MakeCurrent();

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                item.Value.ShaderProg.Mesh_Opacity = opac_val;
            }

            this.View3D.Refresh();
        }

        private void RdBtn_Chessboard_CheckedChanged(object sender, EventArgs e)
        {
            if (RdBtn_Chessboard.Checked)
            {
                this.Enable_Hatching_Rendering(false);
            }
        }

        private void Enable_Hatching_Rendering(bool activate)
        {
            int active = Convert.ToInt32(activate);

            this.ViewMapGlyphs.MakeCurrent();

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Sampled_Maps_2D)
            {
                item.Value.ShaderProg.Hatching_Active_Val = active;

                item.Value.Update_Child_Render_Objects();
            }

            this.ViewMapGlyphs.Refresh();

            this.View3D.MakeCurrent();

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                item.Value.ShaderProg.Hatching_Active_Val = active;

                item.Value.Update_Child_Render_Objects();
            }

            this.View3D.Refresh();
        }

        private void RdBtn_Hatching_CheckedChanged(object sender, EventArgs e)
        {
            this.Enable_Hatching_Rendering(this.RdBtn_Hatching.Checked);
        }

        private void ChckBx_Glyphs_CheckedChanged(object sender, EventArgs e)
        {
            Dictionary<string, RenderItem>.KeyCollection keyColl = this.renderdata.Render_Sampled_Maps_2D.Keys;

            List<string> keys = keyColl.ToList();

            this.ViewMapGlyphs.MakeCurrent();

            try
            {
                if (this.ChckBx_Glyphs.Checked)
                {
                    foreach (string s in keys)
                    {
                        Map actmap = (Map)this.renderdata.Render_Sampled_Maps_2D[s];

                        actmap.Map_Cylinder.Hide_Render = true;
                        actmap.Cylinder_Plane.Hide_Render = true;

                        this.renderdata.Render_Sampled_Maps_2D[s] = actmap;
                    }
                }
                else
                {
                    foreach (string s in keys)
                    {
                        Map actmap = (Map)this.renderdata.Render_Sampled_Maps_2D[s];

                        actmap.Map_Cylinder.Hide_Render = false;
                        actmap.Cylinder_Plane.Hide_Render = false;

                        this.renderdata.Render_Sampled_Maps_2D[s] = actmap;
                    }
                }
            }
            catch (Exception)
            {

            }

            this.ViewMapGlyphs.Refresh();
        }

        private void Cmb_Bx_StentSelectionTop_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Cmb_Bx_StentSelectionTop.SelectedItem.ToString() == Settings.Default.AneurysmNoStentName)
            {
                this.act_render_mesh_fst = Settings.Default.MeshInnerName;
                this.act_render_smap_fst = Settings.Default.SampledAneurysmMapName;

                if (this.renderdata.Render_Meshes_3D[Settings.Default.MeshInnerName].ShaderProg != null)
                {
                    this.renderdata.Render_Meshes_3D[Settings.Default.MeshInnerName].ShaderProg.Stent_Selected = 0;
                }
            }
            else
            {
                this.act_render_mesh_fst = Cmb_Bx_StentSelectionTop.SelectedItem.ToString();
                this.act_render_smap_fst = Cmb_Bx_StentSelectionTop.SelectedItem.ToString();

                if (this.renderdata.Render_Meshes_3D[act_render_mesh_fst].ShaderProg != null)
                {
                    this.renderdata.Render_Meshes_3D[act_render_mesh_fst].ShaderProg.Stent_Selected = 1;
                }
            }

            this.Btn_Clear_Brushing_Click(sender, e);

            this.Set_Rendered_Meshes();

            this.Init_Histogram_Rendering();

            this.Update_Labels();

            if (this.View3D != null)
            {
                this.View3D.MakeCurrent();

                this.View3D.Refresh();
            }

            if (this.ViewMatrix != null)
            {
                this.ViewMatrix.MakeCurrent();

                this.ViewMatrix.Refresh();
            }

            if (this.ViewBEPPlot != null)
            {
                this.ViewBEPPlot.MakeCurrent();

                this.ViewBEPPlot.Refresh();
            }

            if (this.ViewMapGlyphs != null)
            {
                this.ViewMapGlyphs.MakeCurrent();

                this.ViewMapGlyphs.Refresh();
            }
        }

        private void Cmb_Bx_StentSelectionBottom_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Cmb_Bx_StentSelectionBottom.SelectedItem.ToString() == Settings.Default.AneurysmNoStentName)
            {
                this.act_render_mesh_snd = Settings.Default.MeshInnerName;
                //this.act_render_map_snd = Settings.Default.AneurysmMapName;
                this.act_render_smap_snd = Settings.Default.SampledAneurysmMapName;
            }
            else
            {
                this.act_render_mesh_snd = Cmb_Bx_StentSelectionBottom.SelectedItem.ToString();
                //this.act_render_map_snd = Cmb_Bx_StentSelectionBottom.SelectedItem.ToString();
                this.act_render_smap_snd = Cmb_Bx_StentSelectionBottom.SelectedItem.ToString();
            }

            this.Btn_Clear_Brushing_Click(sender, e);

            this.Set_Rendered_Meshes();

            this.Init_Histogram_Rendering();

            this.Update_Labels();

            if (this.View3D != null)
            {
                this.View3D.MakeCurrent();

                this.View3D.Refresh();
            }

            if (this.ViewMatrix != null)
            {
                this.ViewMatrix.MakeCurrent();

                this.ViewMatrix.Refresh();
            }

            if (this.ViewBEPPlot != null)
            {
                this.ViewBEPPlot.MakeCurrent();

                this.ViewBEPPlot.Refresh();
            }

            if (this.ViewMapGlyphs != null)
            {
                this.ViewMapGlyphs.MakeCurrent();

                this.ViewMapGlyphs.Refresh();
            }
        }

        private void Set_Rendered_Meshes()
        {
            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                if (item.Key == this.act_render_mesh_fst)
                {
                    item.Value.ShaderProg.Rendered_Mesh = 1;
                }
                else
                {
                    item.Value.ShaderProg.Rendered_Mesh = 0;
                }
            }

            if (this.act_render_mesh_fst == this.act_render_mesh_snd)
            {
                this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst].ShaderProg.Rendered_Mesh = 2;
            }
        }

        private void NmrcUpDown_Grid_Res_X_ValueChanged(object sender, EventArgs e)
        {
            float grid_x_value = (float)this.NmrcUpDown_Grid_Res_X.Value;
            float grid_y_value = (float)this.NmrcUpDown_Grid_Res_Y.Value;

            Vector2 new_res = new Vector2(grid_x_value, grid_y_value);

            this.Set_Grid_Resolution(new_res);
        }

        private void NmrcUpDown_Grid_Res_Y_ValueChanged(object sender, EventArgs e)
        {
            float grid_x_value = (float)this.NmrcUpDown_Grid_Res_X.Value;
            float grid_y_value = (float)this.NmrcUpDown_Grid_Res_Y.Value;

            Vector2 new_res = new Vector2(grid_x_value, grid_y_value);

            this.Set_Grid_Resolution(new_res);
        }

        private void Set_Grid_Resolution(Vector2 grid_res)
        {
            try
            {
                this.View3D.MakeCurrent();

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
                {
                    item.Value.ShaderProg.Map_Grid_Dim = grid_res;
                }

                this.View3D.Refresh();

                this.ViewMapGlyphs.MakeCurrent();

                foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Sampled_Maps_2D)
                {
                    item.Value.ShaderProg.Map_Grid_Dim = grid_res;
                }

                this.ViewMapGlyphs.Refresh();
            }
            catch (Exception)
            {
            }
        }

        private void Btn_Mesh_Clustering_Click(object sender, EventArgs e)
        {
            if (this.renderdata.Render_Meshes_3D.Count > 0)
            {
                if (this.form_clust_weights == null)
                {
                    this.form_clust_weights = new Form_Clustering();
                    this.form_clust_weights.Parent_Control = this;
                }

                this.form_clust_weights.Scalar_Fields = this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst].Scalar_Data.Keys.ToList();

                this.form_clust_weights.ShowDialog();
            }
        }

        public void Start_Mesh_Clustering()
        {
            if (this.form_clust_weights.Has_Changed)
            {
                this.View3D.MakeCurrent();

                Mesh_Inner actmesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

                actmesh.Cluster_Mesh(this.form_clust_weights.Weights, this.form_clust_weights.Norm_Val, this.form_clust_weights.Invert_Val);

                this.Chck_Bx_ShowClustering.Checked = true;
                this.Chck_Bx_ShowClustering.Visible = true;

                actmesh.Render_Cont = false;

                actmesh.ShaderProg.Render_Cluster = 1;

                this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = actmesh;

                this.View3D.Refresh();

                //this.ViewMap.MakeCurrent();
                this.ViewMapGlyphs.MakeCurrent();

                //Map actmap = (Map)this.renderdata.Render_Maps_2D[this.act_render_map_fst];
                Map actmap = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                actmap.IsoLine_Lables = actmesh.IsoLine_Lables;

                actmap.Cluster_Values = actmesh.Cluster_Values;

                actmap.Render_Cont = false;

                actmap.ShaderProg.Render_Cluster = 1;

                actmap.Init_Setup = false;

                //this.renderdata.Render_Maps_2D[this.act_render_map_fst] = actmap;
                this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actmap;

                this.ViewBEPPlot.Refresh();
            }
        }

        private void Chck_Bx_ShowClustering_CheckedChanged(object sender, EventArgs e)
        {
            if (this.renderdata.Render_Meshes_3D.ContainsKey(this.act_render_mesh_fst))
            {
                Mesh_Inner actmesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

                Map actmap = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                if (this.Chck_Bx_ShowClustering.Checked)
                {
                    this.View3D.MakeCurrent();

                    actmesh.Render_IsoLines = true;

                    actmesh.Render_Cont = false;

                    actmesh.ShaderProg.Render_Cluster = 1;

                    this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = actmesh;

                    this.View3D.Refresh();

                    this.ViewMapGlyphs.MakeCurrent();

                    actmap.Render_IsoLines = true;

                    actmap.Render_Cont = false;

                    actmap.ShaderProg.Render_Cluster = 1;

                    this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actmap;

                    this.ViewMapGlyphs.Refresh();
                }
                else
                {
                    actmesh.Render_IsoLines = false;

                    actmesh.Render_Cont = true;

                    actmesh.ShaderProg.Render_Cluster = 0;

                    this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = actmesh;

                    this.View3D.Refresh();

                    //this.ViewMap.MakeCurrent();
                    this.ViewMapGlyphs.MakeCurrent();

                    actmap.Render_IsoLines = false;

                    actmap.Render_Cont = true;

                    actmap.ShaderProg.Render_Cluster = 0;

                    //this.renderdata.Render_Maps_2D[this.act_render_map_fst] = actmap;
                    this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actmap;

                    //this.ViewMap.Refresh();
                    this.ViewMapGlyphs.Refresh();
                }
            }
        }

        private void Btn_Analysis_Click(object sender, EventArgs e)
        {
            Mesh_Inner actmesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

            actmesh.Calculate_Brushing_Analysis();
        }

        private void Btn_BEP_Parameters_Click(object sender, EventArgs e)
        {
            if (this.renderdata.Render_Meshes_3D.Count > 0)
            {
                if (this.form_bep_parameters == null)
                {
                    this.form_bep_parameters = new Form_BEPParameters();
                    this.form_bep_parameters.Parent_Control = this;
                }

                this.form_bep_parameters.Scalar_Fields = this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst].Scalar_Data.Keys.ToList();

                this.form_bep_parameters.ShowDialog();
            }
        }

        public void Update_BEP_Plot()
        {
            this.ViewBEPPlot.MakeCurrent();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Parameter_Thresholds = this.form_bep_parameters.Thresholds;

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].InvertValues = this.form_bep_parameters.InvertValues;

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Get_Segment_Information();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Init_Setup = false;

            this.ViewBEPPlot.Refresh();
        }

        private void Chck_Bx_Show_Regions_CheckedChanged(object sender, EventArgs e)
        {
            this.View3D.MakeCurrent();

            Mesh_Inner act_mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

            if (Chck_Bx_Show_Regions.Checked)
            {
                act_mesh.ShaderProg.Show_Brushing = 1;
            }
            else
            {
                act_mesh.ShaderProg.Show_Brushing = 0;
            }

            this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = act_mesh;

            this.View3D.Refresh();

            this.ViewMapGlyphs.MakeCurrent();

            Map act_map = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

            if (Chck_Bx_Show_Regions.Checked)
            {
                act_map.ShaderProg.Show_Brushing = 1;
            }
            else
            {
                act_map.ShaderProg.Show_Brushing = 0;
            }

            this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = act_map;

            this.ViewMapGlyphs.Refresh();
        }

        private void Btn_Add_Region_Click(object sender, EventArgs e)
        {
            DialogResult res = this.Clr_Dlg_Add_Region.ShowDialog();

            try
            {
                if (res == DialogResult.OK)
                {
                    Color act_col = this.Clr_Dlg_Add_Region.Color;

                    this.sel_brush_colors.Add(new Vector3(act_col.R, act_col.G, act_col.B) / 255.0f);

                    this.act_region_id++;

                    this.Add_Region_Mesh(act_col);

                    this.Add_Region_Map(act_col);
                }
            }
            catch (Exception)
            {
            }
        }

        private void Add_Region_Mesh(Color act_col)
        {
            try
            {
                Mesh_Inner act_mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

                if (act_mesh.Show_Initial_Brush)
                {
                    act_mesh.Show_Initial_Brush = false;

                    act_mesh.Clear_Brushing();

                    act_mesh.ShaderProg.Brushing_Colors = new float[Utility.Max_Region_Colors * 3];

                    act_mesh.Selected_Colors = new float[Utility.Max_Region_Colors * 3];

                    this.ViewBEPPlot.MakeCurrent();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Num_Regions = this.sel_brush_colors.Count;

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Region_Colors = this.sel_brush_colors.ToArray();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Vert_Segment_Indices = act_mesh.Vertex_Region_IDs.ToArray();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Get_Segment_Information();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Reset_Selection();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Init_Setup = false;

                    this.ViewBEPPlot.Refresh();
                }

                this.View3D.MakeCurrent();

                act_mesh.ShaderProg.Show_Brushing = 1;
                act_mesh.Render_IsoLines = false;

                int id = (this.act_region_id * 3);
                act_mesh.ShaderProg.Brushing_Colors[id] = act_col.R / 255.0f;
                act_mesh.ShaderProg.Brushing_Colors[id + 1] = act_col.G / 255.0f;
                act_mesh.ShaderProg.Brushing_Colors[id + 2] = act_col.B / 255.0f;

                act_mesh.Selected_Colors[id] = act_col.R / 255.0f;
                act_mesh.Selected_Colors[id + 1] = act_col.G / 255.0f;
                act_mesh.Selected_Colors[id + 2] = act_col.B / 255.0f;

                act_mesh.Transformfeedback_Shader.Brushing_Region_Id = this.act_region_id;

                this.act_region_col = act_col;

                this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = act_mesh;

                this.View3D.Refresh();
            }
            catch (Exception)
            {
            }
        }

        private void Add_Region_Map(Color act_col)
        {
            try
            {
                this.ViewMapGlyphs.MakeCurrent();

                Map act_map = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                if (act_map.Show_Initial_Brush)
                {
                    act_map.Show_Initial_Brush = false;

                    act_map.Clear_Brushing();

                    act_map.ShaderProg.Brushing_Colors = new float[Utility.Max_Region_Colors * 3];

                    act_map.Selected_Colors = new float[Utility.Max_Region_Colors * 3];
                }

                act_map.ShaderProg.Show_Brushing = 1;
                act_map.Render_IsoLines = false;

                int id = (this.act_region_id * 3);
                act_map.ShaderProg.Brushing_Colors[id] = act_col.R / 255.0f;
                act_map.ShaderProg.Brushing_Colors[id + 1] = act_col.G / 255.0f;
                act_map.ShaderProg.Brushing_Colors[id + 2] = act_col.B / 255.0f;
                act_map.Transformfeedback_Shader.Brushing_Region_Id = this.act_region_id;

                this.act_region_col = act_col;

                this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = act_map;

                this.ViewMapGlyphs.Refresh();
            }
            catch (Exception)
            {
            }
        }

        private void Lst_Vw_Regions_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                this.Remove_Items_from_List();
            }
        }

        private void NmrUpDown_BrushSize_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                this.View3D.MakeCurrent();

                Dictionary<string, RenderItem>.KeyCollection keyColl = this.renderdata.Render_Meshes_3D.Keys;

                List<string> keys = keyColl.ToList();

                foreach (string item in keys)
                {
                    Mesh_Inner act_mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[item];

                    if (act_mesh.Transformfeedback_Shader != null)
                    {
                        act_mesh.Transformfeedback_Shader.Brush_Size = (int)this.NmrUpDown_BrushSize.Value;
                    }

                    this.renderdata.Render_Meshes_3D[item] = act_mesh;
                }

                this.View3D.Refresh();

                this.ViewMapGlyphs.MakeCurrent();

                keyColl = this.renderdata.Render_Sampled_Maps_2D.Keys;

                foreach (string item in keys)
                {
                    Map act_map = (Map)this.renderdata.Render_Sampled_Maps_2D[item];

                    if (act_map.Transformfeedback_Shader != null)
                    {
                        act_map.Transformfeedback_Shader.Brush_Size = (int)this.NmrUpDown_BrushSize.Value;
                    }

                    this.renderdata.Render_Sampled_Maps_2D[item] = act_map;
                }

                this.ViewMapGlyphs.Refresh();
            }
            catch (Exception)
            {
               
            }
        }

        private void Btn_Reset_Brushing_Click(object sender, EventArgs e)
        {
            this.act_region_id = -1;

            if (this.sel_brush_colors.Count > 0)
            {
                this.sel_brush_colors.Clear();
            }

            if (this.Lst_Vw_Regions.Items.Count > 0)
            {
                this.Lst_Vw_Regions.Items.Clear();
            }
            
            this.View3D.MakeCurrent();

            Mesh_Inner actmesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

            actmesh.ReSet_Region_Ids_Input();

            actmesh.Transformfeedback_Shader.Brushing_Region_Id = this.act_region_id;

            actmesh.ShaderProg.Brushing_Colors = actmesh.Init_Vertex_Region_Colors();

            actmesh.ShaderProg.Show_Brushing = 1;

            actmesh.Show_Initial_Brush = true;

            actmesh.Render_IsoLines = false;

            this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = actmesh;

            this.View3D.Refresh();

            this.ViewMapGlyphs.MakeCurrent();

            Map actmap = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

            actmap.ReSet_Region_Ids_Input();

            actmap.Transformfeedback_Shader.Brushing_Region_Id = this.act_region_id;

            actmap.ShaderProg.Brushing_Colors = actmap.Init_Vertex_Region_Colors();

            actmap.ShaderProg.Show_Brushing = 1;

            actmap.Show_Initial_Brush = true;

            actmap.Render_IsoLines = false;

            this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actmap;

            this.ViewMapGlyphs.Refresh();

            this.ViewBEPPlot.MakeCurrent();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Num_Regions = this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Initial_Num_Regions;

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Region_Colors = Utility.Initial_Brush_Region_Colors;

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Vert_Segment_Indices = actmesh.Inital_Vertex_Region_IDs.ToArray();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Get_Segment_Information();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Reset_Selection();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Init_Setup = false;

            this.ViewBEPPlot.Refresh();
        }

        #endregion

        #region - Data Processing -

        public void Create_Aneurysm_Map()
        {
            Mesh_Inner act_mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

            if (act_mesh.Dome_Indices.Count > 0 && act_mesh.Ostium_Indices.Count > 0)
            {
                act_mesh.Seperate_Aneurysm();

                this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = act_mesh;

                Map actsammap = new Map(act_mesh.Triangles, act_mesh.Positions, act_mesh.Normals, act_mesh.Scalar_Data, act_mesh.Dome_Indices, act_mesh.Ostium_Indices, true, act_mesh.Inital_Vertex_Region_IDs.ToList());

                act_mesh.Ostium_Indices = actsammap.Ostium_Indices;
                act_mesh.Construct_Aneurysm_Ostium();

                if (!this.renderdata.Render_Sampled_Maps_2D.ContainsKey(this.act_render_smap_fst))
                {
                    this.renderdata.Render_Sampled_Maps_2D.Add(this.act_render_smap_fst, actsammap);
                }
                else
                {
                    this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actsammap;
                }
            }
        }

        public void Calculate_Fusiform_Aneurysm_Ostium()
        {
            if (this.renderdata.Render_Sampled_Maps_2D != null && this.renderdata.Render_Sampled_Maps_2D.Keys.Contains(this.act_render_smap_fst))
            {
                List<Vector3> all_ostium_colors = new List<Vector3>();

                Map act_map = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                act_map.Get_Ostium_From_Map(out all_ostium_colors);

                this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = act_map;

                if (this.renderdata.Render_Meshes_3D != null && this.renderdata.Render_Meshes_3D.Keys.Contains(this.act_render_mesh_fst))
                {
                    Mesh_Inner act_mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

                    act_mesh.Ostium_Indices = act_map.Ostium_Indices;

                    act_mesh.Construct_Aneurysm_Ostium(all_ostium_colors);

                    this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = act_mesh;
                }
            }
        }

        public void Init_Histogram_Rendering()
        {
            this.ViewMatrix.MakeCurrent();

            if (this.act_render_mesh_fst == null || this.act_render_mesh_snd == null)
            {
                return;
            }

            if (this.scat_plot != null && this.renderdata.Render_Meshes_3D.ContainsKey(this.act_render_mesh_fst) && this.renderdata.Render_Meshes_3D.ContainsKey(this.act_render_mesh_snd))
            {
                if (this.scat_plot.Render_Shader == null)
                {
                    return;
                }

                Mesh_Inner actmesh_fst = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];
                Mesh_Inner actmesh_snd = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_snd];

                List<uint> test = new List<uint>();

                for (int j = 0; j < actmesh_fst.All_Histo_Values.Count; j++)
                {
                    test.Add(actmesh_fst.All_Histo_Values[j]);
                }

                for (int j = 0; j < actmesh_snd.All_Histo_Values.Count; j++)
                {
                    test.Add(actmesh_snd.All_Histo_Values[j]);
                }

                this.scat_plot.Texture_Histo_Data_First_Case = test.ToArray();

                this.ViewMatrix.Update_Scatter_Plot_Size();

                this.ViewMatrix.SetSPPtr = new Control_Render.SetupScatterBufferPointer(this.scat_plot.Setup_Textures);

                this.ViewMatrix.RndABContentPtr = new Control_Render.RenderABContentPointer(this.scat_plot.RenderScatterplotBufferContent);
            }

            this.ViewMatrix.Refresh();
        }

        public List<int> Generate_Quad_Shaped_Regions()
        {
            List<int> ids = new List<int>();

            if (this.renderdata.Render_Sampled_Maps_2D != null && this.renderdata.Render_Sampled_Maps_2D.ContainsKey(this.act_render_smap_fst))
            {
                Map act_map = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                ids = act_map.Generate_Quad_Shaped_Regions();
            }

            return ids;
        }

        public List<int> Generate_Circular_Shaped_Regions()
        {
            List<int> ids = new List<int>();

            if (this.renderdata.Render_Sampled_Maps_2D != null && this.renderdata.Render_Sampled_Maps_2D.ContainsKey(this.act_render_smap_fst))
            {
                Map act_map = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                ids = act_map.Generate_Circular_Shaped_Regions();
            }

            return ids;
        }

        #endregion

        #region - Mouse Interaction -

        #region - Mouse Wheel -

        /// <summary>
        /// 3D Camera Control via Mouse Interaction --> Zooming
        /// </summary>
        private void View3D_MouseWheel(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.Control_Mouse_Wheel(ref this.cam_3D, e);
        }

        /// <summary>
        /// 3D Camera Control via Mouse Interaction --> Zooming
        /// </summary>
        private void ViewBEP_MouseWheel(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.bep_plot_zooming = this.bep_plot_zooming + e.Delta * 0.000001f;

            if (this.bep_plot_zooming < -0.05f)
            {
                this.bep_plot_zooming = -0.05f;
            }
            else if (this.bep_plot_zooming > 0.005f)
            {
                this.bep_plot_zooming = 0.005f;
            }
        }

        /// <summary>
        /// Violin Plots Camera Control via Mouse Interaction --> Zooming
        /// </summary>
        private void View_MapGlyphs_MouseWheel(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.Control_Mouse_Wheel(ref this.cam_mapglyphs, e);
        }

        private void Control_Mouse_Wheel(ref Camera cam, System.Windows.Forms.MouseEventArgs e)
        {
            float neweyepos = cam.EyePos.X + e.Delta * 0.001f;

            if (neweyepos > 0.0 && neweyepos < cam.Far_Plane)
            {
                cam.EyePos_X = neweyepos;

                cam.EyePos_Kart = Utility.ConvertToCartCoord(cam.EyePos);
            }
        }

        #endregion

        #region - Mouse Move -

        /// <summary>
        /// 3D Camera Control via Mouse Interaction --> Rotation
        /// </summary>
        private void View_3D_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.Control_3D_MouseMove(ref this.cam_3D, this.cam_3D.OldMousePos, e);
        }

        private void View_BEP_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.Control_2D_MouseMove(ref this.cam_bepplot, this.cam_bepplot.OldMousePos, e);
        }

        private void Control_3D_MouseMove(ref Camera cam_view, Vector3 old_mouse_pos, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                cam_view.EyePos_Z = cam_view.EyePos.Z + (old_mouse_pos.X - e.X) * 0.002f;

                if (cam_view.EyePos_Z > (2 * Math.PI))
                {
                    cam_view.EyePos_Z = 0;
                }
                if (cam_view.EyePos_Z < 0)
                {
                    cam_view.EyePos_Z = (float)(2 * Math.PI);
                }

                if (cam_view.EyePos.Y + (old_mouse_pos.Y - e.Y) * 0.002f > 0 && cam_view.EyePos.Y + (old_mouse_pos.Y - e.Y) * 0.002f < Math.PI)
                {
                    cam_view.EyePos_Y = cam_view.EyePos.Y + (old_mouse_pos.Y - e.Y) * 0.002f;
                }

                cam_view.EyePos_Kart = Utility.ConvertToCartCoord(cam_view.EyePos);
            }

            if (e.Button == MouseButtons.Left && this.brushing_on)
            {
                Mesh_Inner actmesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

                actmesh.Transformfeedback_Shader.Brushed_Point = new Vector2(e.X, this.View3D.Height - e.Y);

                this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = actmesh;

                this.View3D.Refresh();

                if (actmesh.Brushed_Points != null && this.act_region_id != -1)
                {
                    this.Add_Color_Brushing_Region();

                    //this.Delete_Empty_Regions();
                }

                this.ViewMapGlyphs.MakeCurrent();

                Map actmap = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                actmap.TransformFeedbackList = actmesh.Brushed_Points.ToList();

                actmap.Set_Transform_Feedback_Input();

                actmap.Vertex_Region_IDs = actmesh.Brushed_Region_Indices.ToList();

                actmap.Brushed_Region_Indices = actmesh.Brushed_Region_Indices;

                actmap.Set_Region_Ids_Input();

                this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actmap;

                this.ViewMapGlyphs.Refresh();

                if (this.act_region_id != -1)
                {
                    this.ViewBEPPlot.MakeCurrent();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Num_Regions = this.sel_brush_colors.Count;

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Region_Colors = this.sel_brush_colors.ToArray();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Vert_Segment_Indices = actmesh.Brushed_Region_Indices;

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Get_Segment_Information();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Init_Setup = false;

                    this.ViewBEPPlot.Refresh();
                }
            }
            else if (e.Button == MouseButtons.Left && this.brushing_on == false)
            {
                cam_view.Center_Z = cam_view.Center.Z + (old_mouse_pos.Y - e.Y) * 0.008f;
            }

            cam_view.OldMousePos = new Vector3(e.X, e.Y, cam_view.OldMousePos.Z);
        }

        private void Control_2D_MouseMove(ref Camera cam_view, Vector3 old_mouse_pos, System.Windows.Forms.MouseEventArgs e)
        {
            float x = 0;
            float y = 0;

            if (e.Button == MouseButtons.Left)
            {
                x = this.cam_bepplot.Center.X + (cam_view.OldMousePos.X - e.X) * 0.008f;
                y = this.cam_bepplot.Center.Y + (cam_view.OldMousePos.Y - e.Y) * 0.008f;

                cam_view.Center_X = x;
                cam_view.Center_Y = y;

                cam_view.EyePos_Kart = new Vector3(x, y, cam_view.EyePos_Kart.Z);
            }

            cam_view.OldMousePos = new Vector3(e.X, e.Y, cam_view.OldMousePos.Z);
        }

        private void View_Matrix_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) // && this.brushing_on
            {
                Vector2 scatter_pos = this.scat_plot.Get_Scatterplot_Coordinates(e.X, e.Y, this.ViewMatrix.Width, this.ViewMatrix.Height);

                this.scat_plot.Set_Brushing_Regions((int)scatter_pos.X, (int)scatter_pos.Y);
            }
        }

        /// <summary>
        /// 3D Camera Control via Mouse Interaction --> Rotation
        /// </summary>
        private void View_MapGlyphs_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.Control_MapGlyph_MouseMove(ref this.cam_mapglyphs, this.cam_mapglyphs.OldMousePos, e);
        }

        private void Control_MapGlyph_MouseMove(ref Camera cam_view, Vector3 old_mouse_pos, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                cam_view.EyePos_Z = cam_view.EyePos.Z + (old_mouse_pos.X - e.X) * 0.002f;

                if (cam_view.EyePos_Z > (2 * Math.PI))
                {
                    cam_view.EyePos_Z = 0;
                }
                if (cam_view.EyePos_Z < 0)
                {
                    cam_view.EyePos_Z = (float)(2 * Math.PI);
                }

                if (cam_view.EyePos.Y + (old_mouse_pos.Y - e.Y) * 0.002f > 0 && cam_view.EyePos.Y + (old_mouse_pos.Y - e.Y) * 0.002f < Math.PI)
                {
                    cam_view.EyePos_Y = cam_view.EyePos.Y + (old_mouse_pos.Y - e.Y) * 0.002f;
                }

                cam_view.EyePos_Kart = Utility.ConvertToCartCoord(cam_view.EyePos);
            }

            if (e.Button == MouseButtons.Left && this.brushing_on )
            {
                Map actmap = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                actmap.Transformfeedback_Shader.Brushed_Point = new Vector2(e.X, this.ViewBEPPlot.Height - e.Y);

                if (actmap.Brushed_Points != null && this.act_region_id != -1)
                {
                    this.Add_Color_Brushing_Region();

                    //this.Delete_Empty_Regions();
                }

                this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actmap;

                this.ViewMapGlyphs.Refresh();

                this.View3D.MakeCurrent();

                Mesh_Inner actmesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

                actmesh.TransformFeedbackList = actmap.Brushed_Points.ToList();

                actmesh.Set_Transform_Feedback_Input();

                actmesh.Vertex_Region_IDs = actmap.Brushed_Region_Indices.ToList();

                actmesh.Brushed_Region_Indices = actmap.Brushed_Region_Indices;

                actmesh.Set_Region_Ids_Input();

                this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = actmesh;

                this.View3D.Refresh();

                if (this.act_region_id != -1)
                {
                    this.ViewBEPPlot.MakeCurrent();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Num_Regions = this.sel_brush_colors.Count;

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Region_Colors = this.sel_brush_colors.ToArray();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Vert_Segment_Indices = actmap.Brushed_Region_Indices;

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Get_Segment_Information();

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Init_Setup = false;

                    this.ViewBEPPlot.Refresh();
                }
            }
            else if (e.Button == MouseButtons.Left && this.brushing_on == false)
            {
                cam_view.Center_Z = cam_view.Center.Z + (old_mouse_pos.Y - e.Y) * 0.008f;
            }

            cam_view.OldMousePos = new Vector3(e.X, e.Y, cam_view.OldMousePos.Z);
        }

        #endregion

        #region - Mouse Click -

        #region - View3D -

        private void View3D_MouseClick(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.View3D.MakeCurrent();

            if (e.Button == MouseButtons.Left && (this.dome_selected || this.ostium_selected))
            {
                if (this.renderdata.Render_Meshes_3D.ContainsKey(this.act_render_mesh_fst))
                {
                    Vector3 near_point;
                    Vector3 ray_dir;

                    this.Get_Ray_on_Click_in_3DView(e.X, e.Y, out near_point, out ray_dir);

                    Vector3 hit_point = Vector3.Zero;
                    Vector3 hit_norm = Vector3.Zero;

                    int index = this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst].Calculate_Picked_Triangle(near_point, ray_dir, out hit_point, out hit_norm);

                    if (index != -1)
                    {
                        if (this.ostium_selected)
                        {
                            Mesh_Inner mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

                            mesh.Ostium_Indices.Add(index);

                            this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = mesh;

                            this.Add_Selected_Point(Settings.Default.Spheres3DName, index, hit_point, hit_norm, new Vector3(1, 1, 0));
                        }
                        else if (this.dome_selected)
                        {
                            Mesh_Inner mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

                            mesh.Dome_Indices.Add(index);

                            this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = mesh;

                            this.Add_Selected_Point(Settings.Default.Spheres3DName, index, hit_point, hit_norm, Vector3.UnitX);
                        }
                    }
                }
            }

            this.ostium_selected = false;

            this.dome_selected = false;

            this.View3D.Refresh();
        }

        private void Get_Ray_on_Click_in_3DView(int mouse_pos_x, int mouse_pos_y, out Vector3 near_point, out Vector3 ray_dir)
        {
            near_point = this.Calculate_Word_Coords(this.View3D, new Vector3(mouse_pos_x, mouse_pos_y, 0.0f), ref Utility.Picking_Mat_ModelView_3D, ref Utility.Picking_Mat_Projection_3D);

            Vector3 far_point = this.Calculate_Word_Coords(this.View3D, new Vector3(mouse_pos_x, mouse_pos_y, 1.0f), ref Utility.Picking_Mat_ModelView_3D, ref Utility.Picking_Mat_Projection_3D);

            ray_dir = far_point - near_point;

            ray_dir.Normalize();
        }

        private void Get_Ray_on_Click_in_2DBEPView(int mouse_pos_x, int mouse_pos_y, out Vector3 near_point, out Vector3 ray_dir)
        {
            near_point = this.Calculate_Word_Coords(this.ViewBEPPlot, new Vector3(mouse_pos_x, mouse_pos_y, 0.0f), ref Utility.Picking_Mat_ModelView_2DBEPPlot, ref Utility.Picking_Mat_Projection_2DBEPPlot);

            Vector3 far_point = this.Calculate_Word_Coords(this.ViewBEPPlot, new Vector3(mouse_pos_x, mouse_pos_y, 1.0f), ref Utility.Picking_Mat_ModelView_2DBEPPlot, ref Utility.Picking_Mat_Projection_2DBEPPlot);

            ray_dir = far_point - near_point;

            ray_dir.Normalize();
        }

        private void Get_Ray_on_Click_in_MapGlyphView(int mouse_pos_x, int mouse_pos_y, out Vector3 near_point, out Vector3 ray_dir)
        {
            near_point = this.Calculate_Word_Coords(this.ViewMapGlyphs, new Vector3(mouse_pos_x, mouse_pos_y, 0.0f), ref Utility.Picking_Mat_ModelView_2DSamMap, ref Utility.Picking_Mat_Projection_2DSamMap);

            Vector3 far_point = this.Calculate_Word_Coords(this.ViewMapGlyphs, new Vector3(mouse_pos_x, mouse_pos_y, 1.0f), ref Utility.Picking_Mat_ModelView_2DSamMap, ref Utility.Picking_Mat_Projection_2DSamMap);

            ray_dir = far_point - near_point;

            ray_dir.Normalize();
        }

        private Vector3 Calculate_Word_Coords(Control_Render actview, Vector3 mouse_point, ref Matrix4 ModelView, ref Matrix4 Projection)
        {
            // 3D Normalised Device Coordinates
            float x = (2.0f * mouse_point.X) / actview.Width - 1.0f;
            float y = (2.0f * mouse_point.Y) / actview.Height - 1.0f;
            float z = 2.0f * mouse_point.Z - 1.0f;
            float w = 1.0f;

            Vector4 ray_clip = new Vector4(x, -y, z, w);

            //4D Eye (Camera) Coordinates
            Matrix4 Inverted_Proj_Matrix = Projection.Inverted();

            Vector4.Transform(ref ray_clip, ref Inverted_Proj_Matrix, out ray_clip);

            //4D World Coordinates
            Matrix4 Inverted_View_Matrix = ModelView.Inverted();

            Vector4.Transform(ref ray_clip, ref Inverted_View_Matrix, out ray_clip);

            if (ray_clip.W > float.Epsilon || ray_clip.W < float.Epsilon)
            {
                ray_clip.X /= ray_clip.W;
                ray_clip.Y /= ray_clip.W;
                ray_clip.Z /= ray_clip.W;
            }

            return ray_clip.Xyz;
        }

        private void Add_Selected_Point(string key, int index, Vector3 hit_point, Vector3 hit_norm, Vector3 color)
        {
            this.View3D.MakeCurrent();

            PointSphere act_sphere;

            if (this.renderdata.Render_Objects_3D.ContainsKey(key))
            {
                act_sphere = (PointSphere)this.renderdata.Render_Objects_3D[key];
            }
            else
            {
                act_sphere = new PointSphere();
            }

            if (act_sphere.Indices.Count > 0)
            {
                act_sphere.Indices[0] = index;
                act_sphere.Positions[0] = hit_point;
                act_sphere.Normals[0] = hit_norm;
                act_sphere.Colors[0] = color;
            }
            else
            {
                act_sphere.Indices.Add(index);
                act_sphere.Positions.Add(hit_point);
                act_sphere.Normals.Add(hit_norm);
                act_sphere.Colors.Add(color);
            }

            this.renderdata.Render_Objects_3D[key] = act_sphere;

            if (this.renderdata.Render_Objects_3D[key].Init_Setup)
            {
                this.renderdata.Render_Objects_3D[key].Update_Render_Item();
            }

            this.View3D.Refresh();
        }

        #endregion

        #region - View BEPPlot -

        private void ViewBEP_MouseClick(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            int region_id = -1;

            int time_seg = -1;

            this.ViewBEPPlot.MakeCurrent();

            if (e.Button == MouseButtons.Left)
            {
                if (this.renderdata.Aneurysm_Plots.ContainsKey(this.act_render_mesh_fst))
                {
                    Vector3 near_point;
                    Vector3 ray_dir;

                    this.Get_Ray_on_Click_in_2DBEPView(e.X, e.Y, out near_point, out ray_dir);

                    Vector4 near_point_mod = new Vector4(near_point, 1);

                    //4D Eye (Camera) Coordinates
                    Matrix4 Inverted_Mod_Matrix = this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].TransformationMatrix.Inverted();

                    Vector4.Transform(ref near_point_mod, ref Inverted_Mod_Matrix, out near_point_mod);

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Get_Selected_Plot_Segment(near_point_mod.Xy, out region_id, out time_seg);

                    this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Init_Setup = false;
                }
            }

            this.ViewBEPPlot.Refresh();

            if (region_id != -1 && time_seg != -1)
            {
                this.View3D.MakeCurrent();

                Mesh_Inner act_mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[act_render_mesh_fst];

                act_mesh.Update_Isoline_Data((region_id + 1)); // ids start at 1, for coloring id-1 has to be choosen

                act_mesh.Render_IsoLines = true;

                act_mesh.ShaderProg.Show_Brushing = 0;

                act_mesh.Isoline_Shader_Prog.Brushing_Colors = act_mesh.ShaderProg.Brushing_Colors;

                this.renderdata.Render_Meshes_3D[act_render_mesh_fst] = act_mesh;

                this.View3D.Refresh();

                this.ViewMapGlyphs.MakeCurrent();

                Map act_map = (Map)this.renderdata.Render_Sampled_Maps_2D[act_render_smap_fst];

                act_map.Update_Isoline_Data((region_id + 1)); // ids start at 1, for coloring id-1 has to be choosen

                act_map.Render_IsoLines = true;

                act_map.ShaderProg.Show_Brushing = 0;

                act_map.Isoline_Shader_Prog.Brushing_Colors = act_mesh.ShaderProg.Brushing_Colors;

                this.renderdata.Render_Sampled_Maps_2D[act_render_smap_fst] = act_map;

                this.ViewMapGlyphs.Refresh();

                this.Set_Animation_Time(time_seg);
            }
        }

        private void Set_Animation_Time(int time_seg)
        {
            Shader.Ani_time = (float)(time_seg * this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Num_Depicted_Plot_Timesteps);

            this.Update_Time_Plot();

            this.Chck_Bx_Stop_Animation.Checked = true;

            this.Redraw_All_Views();
        }

        #endregion

        #region - View Map Glyphs -

        private void ViewMapGlyphs_MouseClick(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.ViewMapGlyphs.MakeCurrent();

            if (e.Button == MouseButtons.Left)
            {
                if (this.renderdata.Render_Sampled_Maps_2D.ContainsKey(this.act_render_smap_fst))
                {
                    Map actmap = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                    Vector3 near_point;
                    Vector3 ray_dir;

                    this.Get_Ray_on_Click_in_MapGlyphView(e.X, e.Y, out near_point, out ray_dir);

                    if (this.animation_selected || this.map_region_analysis || this.glyph_adding)
                    {
                        Mesh_Inner mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

                        Vector3 hit_point = Vector3.Zero;
                        Vector3 hit_norm = Vector3.Zero;

                        int index = actmap.Calculate_Picked_Triangle(near_point, ray_dir, out hit_point, out hit_norm);

                        if (this.glyph_adding)
                        {
                            if (actmap.Map_Cylinder != null)
                            {
                                actmap.Add_Sample_Point(near_point, ray_dir);

                                this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actmap;
                            }
                        }
                        else if (this.map_region_analysis)
                        {
                            //if (Chck_Bx_ShowClustering.Checked)
                            //{
                            //    if (this.form_clust_weights != null)
                            //    {
                            //        List<string> fields = new List<string>();

                            //        for (int i = 0; i < this.form_clust_weights.Weights.Count; i++)
                            //        {
                            //            if (this.form_clust_weights.Weights[i] > 0)
                            //            {
                            //                fields.Add(this.form_clust_weights.Scalar_Fields[i]);
                            //            }
                            //        }

                            //        if (fields.Count > 0)
                            //        {
                            //            actmap.Cluster_Analysis(index, fields);
                            //        }
                            //    }
                            //}
                            //else
                            //{
                            //    actmap.Region_Analysis(index, this.act_fst_sel_sf);
                            //}

                            actmap.Region_Analysis(index, this.act_fst_sel_sf);

                            this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actmap;

                            this.map_region_analysis = false;

                        }
                        else if (this.animation_selected && index != -1)
                        {
                            hit_point = mesh.Positions[index];

                            Console.WriteLine("Index: " + index);
                            hit_norm = mesh.Normals[index];

                            this.Add_Selected_Point(Settings.Default.Spheres3DName, index, hit_point, hit_norm, new Vector3(0, 1, 0));

                            this.animation_selected = false;

                            this.single_point_cam_drive_index = index;

                            Utility.Animation_On = false;

                            // camera move
                            this.single_point_camera_drive = true;
                        }
                    }
                    else
                    {
                        string fst_val, snd_val;

                        actmap.Get_Value_On_Click(near_point, ray_dir, this.act_fst_sel_sf, this.act_snd_sel_sf, out fst_val, out snd_val);

                        if (fst_val.Length > 0 && snd_val.Length > 0 && this.map_selected)
                        {
                            string s1 = "Green: " + this.act_fst_sel_sf + ": " + fst_val;
                            string s2 = "Pink: " + this.act_snd_sel_sf + ": " + snd_val;

                            this.act_sel_pos_val.Text = s1 + "\r\n" + s2;

                            this.act_sel_pos_val.Visible = true;

                            this.act_sel_pos_val.Location = new Point(e.X + 5, e.Y);

                            int max = Math.Max(s1.Length, s2.Length);

                            this.act_sel_pos_val.Size = new Size(max * 7, 40);

                            this.act_sel_pos_val.BringToFront();

                            this.map_selected = false;
                        }
                        else
                        {
                            this.act_sel_pos_val.Visible = false;
                        }
                    }
                }
            }

            this.ViewMapGlyphs.Refresh();
        }

        private void View_Color_Scale_Fst_Rerange_Click(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.Update_Fst_Color_Scale_Range();
        }

        private void Update_Fst_Color_Scale_Range()
        {
            float selected_min = (float)this.range_fst_slider.SelectedMin / 100.0f;
            float selected_max = (float)this.range_fst_slider.Value / 100.0f;

            float fst_min = (Utility.norm_values[this.act_fst_sel_sf].X * (1.0f - selected_min)) + (Utility.norm_values[this.act_fst_sel_sf].Y * selected_min);
            float fst_max = (Utility.norm_values[this.act_fst_sel_sf].X * (1.0f - selected_max)) + (Utility.norm_values[this.act_fst_sel_sf].Y * selected_max);

            this.Update_First_Color_Scale(fst_min, fst_max);

            this.View3D.MakeCurrent();

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                if (item.Value.ShaderProg != null)
                {
                    item.Value.ShaderProg.Fst_Rescale = new Vector2(selected_min, selected_max);
                    item.Value.Update_Child_Render_Objects();
                }
            }

            this.View3D.Refresh();

            this.ViewMapGlyphs.MakeCurrent();

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Sampled_Maps_2D)
            {
                if (item.Value.ShaderProg != null)
                {
                    item.Value.ShaderProg.Fst_Rescale = new Vector2(selected_min, selected_max);
                    item.Value.Update_Child_Render_Objects();
                }
            }

            this.ViewMapGlyphs.Refresh();
        }

        private void View_Color_Scale_Snd_Rerange_Click(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.Update_Snd_Color_Scale_Range();
        }

        private void Update_Snd_Color_Scale_Range()
        {
            float selected_min = (float)this.range_snd_slider.SelectedMin / 100.0f;
            float selected_max = (float)this.range_snd_slider.Value / 100.0f;

            float snd_min = (Utility.norm_values[this.act_snd_sel_sf].X * (1.0f - selected_min)) + (Utility.norm_values[this.act_snd_sel_sf].Y * selected_min);
            float snd_max = (Utility.norm_values[this.act_snd_sel_sf].X * (1.0f - selected_max)) + (Utility.norm_values[this.act_snd_sel_sf].Y * selected_max);

            this.Update_Second_Color_Scale(snd_min, snd_max);

            this.View3D.MakeCurrent();

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Meshes_3D)
            {
                if (item.Value.ShaderProg != null)
                {
                    item.Value.ShaderProg.Snd_Rescale = new Vector2(selected_min, selected_max);
                    item.Value.Update_Child_Render_Objects();
                }
            }

            this.View3D.Refresh();

            this.ViewMapGlyphs.MakeCurrent();

            foreach (KeyValuePair<string, RenderItem> item in this.renderdata.Render_Sampled_Maps_2D)
            {
                if (item.Value.ShaderProg != null)
                {
                    item.Value.ShaderProg.Snd_Rescale = new Vector2(selected_min, selected_max);
                    item.Value.Update_Child_Render_Objects();
                }
            }

            this.ViewMapGlyphs.Refresh();
        }

        #endregion

        #endregion

        #endregion

        #region - Key Interaction -

        #region - View 3D -

        private void View3D_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                this.Update_Shaders();
            }
        }

        private void View3D_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.O)
            {
                this.ostium_selected = false;
            }
            else if (e.KeyCode == Keys.D)
            {
                this.dome_selected = false;
            }
            else if (e.KeyCode == Keys.B)
            {
                this.brushing_on = false;

                if (this.renderdata.Render_Meshes_3D.ContainsKey(this.act_render_mesh_fst))
                {
                    Mesh_Inner actmesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];

                    actmesh.Transformfeedback_Shader.Brushing_On = 0;

                    actmesh.Transformfeedback_Shader.Brushed_Point = new Vector2(-1, -1);

                    this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = actmesh;

                    this.View3D.Refresh();
                }
            }
        }

        private void View3D_KeyEnter(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar == 'o')
            {
                this.ostium_selected = true;
                this.dome_selected = false;
            }
            else if (e.KeyChar == 'd')
            {
                this.dome_selected = true;
                this.ostium_selected = false;
            }
            else if (e.KeyChar == 'b')
            {
                this.brushing_on = true;

                if (this.renderdata.Render_Meshes_3D.ContainsKey(this.act_render_mesh_fst))
                {
                    Mesh_Inner actmesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst];
                    actmesh.Transformfeedback_Shader.Brushing_On = 1;

                    this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst] = actmesh;

                    this.View3D.Refresh();
                }
            }
        }

        private void Add_Color_Brushing_Region()
        {
            if (this.act_region_id > -1)
	        {
                string newreg = "Region: " + this.act_region_id;

                bool exists = false;

                int count = this.Lst_Vw_Regions.Items.Count;

                for (int i = 0; i < count; i++)
                {
                    if (this.Lst_Vw_Regions.Items[i].Text.Equals(newreg))
                    {
                        exists = true;

                        break;
                    }
                }

                if (!exists)
                {
                    ListViewItem newitem = new ListViewItem();
                    newitem.Text = newreg;
                    newitem.ForeColor = this.act_region_col;
                    this.Lst_Vw_Regions.Items.Add(newitem);
                }
	        }
        }

        private void Remove_Items_from_List()
        {
            ListView.SelectedListViewItemCollection items = this.Lst_Vw_Regions.SelectedItems;

            string act_reg = "";
            int startindex = 0;

            int act_id = 0;

            for (int i = 0; i < items.Count; i++)
            {
                act_reg = items[i].Text;

                startindex = act_reg.LastIndexOf(":") + 2;

                Int32.TryParse(act_reg.Substring(startindex), out act_id);

                this.sel_brush_colors.RemoveAt(act_id);

                this.Remove_Region_from_List(act_id);

                this.act_region_id = this.act_region_id - 1;

                this.Lst_Vw_Regions.Items.Remove(items[i]);

                this.Update_Region_Labels();
            }
        }

        private void Remove_Region_from_List(int region) // region between 0 and 19
        {
            this.View3D.MakeCurrent();

            Mesh_Inner act_mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[act_render_mesh_fst];

            for (int i = 0; i < act_mesh.Brushed_Region_Indices.Length; i++)
            {
                if (act_mesh.Brushed_Region_Indices[i] == region)
                {
                    act_mesh.Brushed_Region_Indices[i] = -1;
                }

                else if (act_mesh.Brushed_Region_Indices[i] > region)
                {
                    act_mesh.Brushed_Region_Indices[i] = act_mesh.Brushed_Region_Indices[i] - 1;
                }
            }

            act_mesh.Vertex_Region_IDs = act_mesh.Brushed_Region_Indices.ToList();

            act_mesh.Set_Region_Ids_Input();

            act_mesh.Transformfeedback_Shader.Brushing_Region_Id = this.act_region_id-1;

            act_mesh.Render_IsoLines = false;
            act_mesh.ShaderProg.Show_Brushing = 1;

            if (region < Utility.Max_Region_Colors - 1)
            {
                for (int i = (region * 3); i < (Utility.Max_Region_Colors*3); i += 3)
                {
                    if (i <= ((Utility.Max_Region_Colors - 2) * 3))
                    {
                        act_mesh.ShaderProg.Brushing_Colors[i] = act_mesh.ShaderProg.Brushing_Colors[i + 3];
                        act_mesh.ShaderProg.Brushing_Colors[i + 1] = act_mesh.ShaderProg.Brushing_Colors[i + 4];
                        act_mesh.ShaderProg.Brushing_Colors[i + 2] = act_mesh.ShaderProg.Brushing_Colors[i + 5];
                    }
                    else
                    {
                        act_mesh.ShaderProg.Brushing_Colors[i] = 0;
                        act_mesh.ShaderProg.Brushing_Colors[i + 1] = 0;
                        act_mesh.ShaderProg.Brushing_Colors[i + 2] = 0;
                    }
                    
                }
            }
            else
            {
                act_mesh.ShaderProg.Brushing_Colors[(region*3)] = 0;
                act_mesh.ShaderProg.Brushing_Colors[(region*3) + 1] = 0;
                act_mesh.ShaderProg.Brushing_Colors[(region*3) + 2] = 0;
            }

            this.renderdata.Render_Meshes_3D[act_render_mesh_fst] = act_mesh;

            this.View3D.Refresh();

            this.ViewMapGlyphs.MakeCurrent();

            Map act_map = (Map)this.renderdata.Render_Sampled_Maps_2D[act_render_smap_fst];

            act_map.Vertex_Region_IDs = act_mesh.Brushed_Region_Indices.ToList();

            act_map.Set_Region_Ids_Input();

            act_map.Render_IsoLines = false;
            act_map.ShaderProg.Show_Brushing = 1;

            act_map.Transformfeedback_Shader.Brushing_Region_Id = this.act_region_id - 1;

            act_map.ShaderProg.Brushing_Colors = act_mesh.ShaderProg.Brushing_Colors;

            this.renderdata.Render_Sampled_Maps_2D[act_render_smap_fst] = act_map;

            this.ViewMapGlyphs.Refresh();

            this.ViewBEPPlot.MakeCurrent();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Num_Regions = this.sel_brush_colors.Count;

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Region_Colors = this.sel_brush_colors.ToArray();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Vert_Segment_Indices = act_mesh.Brushed_Region_Indices;

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Get_Segment_Information();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Reset_Selection();

            this.renderdata.Aneurysm_Plots[this.act_render_mesh_fst].Init_Setup = false;

            this.ViewBEPPlot.Refresh();
        }

        private void Update_Region_Labels()
        {
            for (int i = 0; i < this.Lst_Vw_Regions.Items.Count; i++)
            {
                this.Lst_Vw_Regions.Items[i].Text = "Region: " + i;
            }
        }

        private void Delete_Empty_Regions()
        {
            Mesh_Inner act_mesh = (Mesh_Inner)this.renderdata.Render_Meshes_3D[act_render_mesh_fst];
            Map act_map = (Map)this.renderdata.Render_Sampled_Maps_2D[act_render_smap_fst];

            for (int i = this.act_region_id; i >= 0; i--)
            {
                if (act_mesh.Brushed_Region_Indices != null && act_mesh.Brushed_Region_Indices.Contains(i))
                {
                    continue;
                }
                else if (act_map.Brushed_Region_Indices != null && act_map.Brushed_Region_Indices.Contains(i))
                {
                    continue;
                }
                else
                {
                    for (int j = 0; j < this.Lst_Vw_Regions.Items.Count; j++)
                    {
                        if (this.Lst_Vw_Regions.Items[j].Text.Contains(i.ToString()))
                        {
                            this.sel_brush_colors.RemoveAt(i);

                            this.Remove_Region_from_List(i);

                            this.act_region_id = this.act_region_id - 1;

                            this.Lst_Vw_Regions.Items.RemoveAt(j);

                            this.Update_Region_Labels();
                        }
                    }
                }
            }
        }

        #endregion

        #region - View Map -

        private void ViewMapGlyphs_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.B)
            {
                this.brushing_on = false;

                if (this.renderdata.Render_Sampled_Maps_2D.ContainsKey(this.act_render_smap_fst))
                {
                    Map actmap = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                    actmap.Transformfeedback_Shader.Brushing_On = 0;

                    actmap.Transformfeedback_Shader.Brushed_Point = new Vector2(-1, -1);

                    this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actmap;

                    this.ViewMapGlyphs.Refresh();
                }
            }
            else if (e.KeyCode == Keys.A)
            {
                this.animation_selected = false;
            }
            else if (e.KeyCode == Keys.G)
            {
                this.glyph_adding = false;
            }
            else if (e.KeyCode == Keys.I)
            {
                this.map_selected = false;
            }
            else if (e.KeyCode == Keys.S)
            {
                this.map_region_analysis = false;
            }
        }

        private void ViewMapGlyphs_KeyEnter(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar == 'b')
            {
                this.brushing_on = true;

                //if (this.renderdata.Render_Maps_2D.ContainsKey(this.act_render_map_fst))
                if (this.renderdata.Render_Sampled_Maps_2D.ContainsKey(this.act_render_smap_fst))
                {
                    //Map actmap = (Map)this.renderdata.Render_Maps_2D[this.act_render_map_fst];
                    Map actmap = (Map)this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst];

                    actmap.Transformfeedback_Shader.Brushing_On = 1;

                    //this.renderdata.Render_Maps_2D[this.act_render_map_fst] = actmap;
                    this.renderdata.Render_Sampled_Maps_2D[this.act_render_smap_fst] = actmap;

                    //this.ViewMap.Refresh();
                    this.ViewMapGlyphs.Refresh();
                }
            }
            else if (e.KeyChar == 'a')
            {
                this.animation_selected = true;
            }
            else if (e.KeyChar == 'g')
            {
                this.glyph_adding = true;
            }
            else if (e.KeyChar == 'i')
            {
                this.map_selected = true;
            }
            else if (e.KeyChar == 's')
            {
                this.map_region_analysis = true;
            }
        }

        #endregion

        #region - View Matrix -

        private void ViewMatrix_KeyEnter(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar == 'b')
            {
                this.brushing_on = true;
            }
        }

        private void ViewMatrix_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.B)
            {
                this.brushing_on = false;
            }
        }

        #endregion

        #endregion

        #region - Linked Interaction -

        private void Move_Camera_to_Single_Point(int final_vert_index)
        {
            // current camera position
            Vector3 cam_pos = this.cam_3D.EyePos_Kart;

            Vector3 cam_goal = this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst].Positions[final_vert_index];

            // current vertex normal from index
            Vector3 normal = this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst].Normals[final_vert_index] * 10.0f;

            cam_goal = normal + cam_goal;

            // animation time of camera
            float animationLength = 10000.0f;

            float t = this.camera_animation_time / animationLength;

            // current look at point
            Vector3 focalPoint = this.cam_3D.Center;

            focalPoint = focalPoint + t * (this.renderdata.Render_Meshes_3D[this.act_render_mesh_fst].Positions[final_vert_index] - focalPoint);

            cam_pos = cam_pos + t * (cam_goal - cam_pos);

            // OpenGl Camera setzen
            this.cam_3D.EyePos_Kart = cam_pos;
            this.cam_3D.Center = focalPoint;

            if (this.camera_animation_time > animationLength || (cam_pos - cam_goal).Length < 0.01)
            {
                this.camera_animation_time = 0;

                this.single_point_camera_drive = false;

                Utility.Animation_On = true;
            }
            else
            {
                this.camera_animation_time++;
            }
        }

        #endregion

        #endregion
    }
}
