﻿namespace NeuroAnalytics
{
    partial class Control_Risk_Analysis
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint1 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            this.Pnl_Risk_Analysis = new System.Windows.Forms.Panel();
            this.Splt_Cntr_View = new System.Windows.Forms.SplitContainer();
            this.Splt_Contr_Brush = new System.Windows.Forms.SplitContainer();
            this.Pnl_ScatterInteraction = new System.Windows.Forms.Panel();
            this.Chck_Bx_Substract = new System.Windows.Forms.CheckBox();
            this.Chck_Bx_InvertScatter = new System.Windows.Forms.CheckBox();
            this.NmrcUpDown_NumBins = new System.Windows.Forms.NumericUpDown();
            this.Cmb_Bx_StentSelectionTop = new System.Windows.Forms.ComboBox();
            this.Btn_Equalize_SP = new System.Windows.Forms.Button();
            this.Pnl_StentSelectionBottom = new System.Windows.Forms.Panel();
            this.Cmb_Bx_StentSelectionBottom = new System.Windows.Forms.ComboBox();
            this.Rd_Btn_Local_Scat = new System.Windows.Forms.RadioButton();
            this.GrpBx_ParameterRow = new System.Windows.Forms.GroupBox();
            this.RdBtn_Global_Scat = new System.Windows.Forms.RadioButton();
            this.GrpBx_ParameterColumn = new System.Windows.Forms.GroupBox();
            this.Pnl_Scatterplot = new System.Windows.Forms.Panel();
            this.Txt_Bx_FPS = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Pnl_BEP_Parameters = new System.Windows.Forms.Panel();
            this.Btn_BEP_Parameters = new System.Windows.Forms.Button();
            this.Pnl_View_Map = new System.Windows.Forms.Panel();
            this.Pnl_LegendView = new System.Windows.Forms.Panel();
            this.Splt_Contr_Analysis = new System.Windows.Forms.SplitContainer();
            this.Timespan_GrpBx = new System.Windows.Forms.GroupBox();
            this.Chck_Bx_Peak_Systole = new System.Windows.Forms.CheckBox();
            this.Chck_Bx_Stop_Animation = new System.Windows.Forms.CheckBox();
            this.Chrt_Time = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.TrckBr_CurrentTimeSlider = new GradientControls.ColorTrackBar();
            this.Pnl_View3D = new System.Windows.Forms.Panel();
            this.Pnl_Region_Brushing = new System.Windows.Forms.Panel();
            this.Chck_Bx_Show_Regions = new System.Windows.Forms.CheckBox();
            this.Btn_Reset_Brushing = new System.Windows.Forms.Button();
            this.Btn_Clear_Brushing = new System.Windows.Forms.Button();
            this.Lbl_Brush_Size = new System.Windows.Forms.Label();
            this.NmrUpDown_BrushSize = new System.Windows.Forms.NumericUpDown();
            this.Btn_Add_Region = new System.Windows.Forms.Button();
            this.Lst_Vw_Regions = new System.Windows.Forms.ListView();
            this.Pnl_3D_Interaction = new System.Windows.Forms.Panel();
            this.Btn_Analysis = new System.Windows.Forms.Button();
            this.Chck_Bx_ShowClustering = new System.Windows.Forms.CheckBox();
            this.Btn_Mesh_Clustering = new System.Windows.Forms.Button();
            this.Lbl_Opacity = new System.Windows.Forms.Label();
            this.TrckBr_Mesh_Opacity = new GradientControls.ColorTrackBar();
            this.Grp_Bx_Snd_Color_Scale = new System.Windows.Forms.GroupBox();
            this.Pnl_ColorLeg_2 = new System.Windows.Forms.Panel();
            this.Lbl_Col4_Snd_Scale = new System.Windows.Forms.Label();
            this.Lbl_Col0_Snd_Scale = new System.Windows.Forms.Label();
            this.Lbl_Col1_Snd_Scale = new System.Windows.Forms.Label();
            this.Lbl_Col3_Snd_Scale = new System.Windows.Forms.Label();
            this.Lbl_Col2_Snd_Scale = new System.Windows.Forms.Label();
            this.Pnl_View_MapGlyph = new System.Windows.Forms.Panel();
            this.Grp_Bx_Fst_Color_Scale = new System.Windows.Forms.GroupBox();
            this.Pnl_ColorLeg_1 = new System.Windows.Forms.Panel();
            this.Lbl_Col4_Fst_Scale = new System.Windows.Forms.Label();
            this.Lbl_Col0_Fst_Scale = new System.Windows.Forms.Label();
            this.Lbl_Col3_Fst_Scale = new System.Windows.Forms.Label();
            this.Lbl_Col1_Fst_Scale = new System.Windows.Forms.Label();
            this.Lbl_Col2_Fst_Scale = new System.Windows.Forms.Label();
            this.Pnl_Map_Interaction = new System.Windows.Forms.Panel();
            this.ChckBx_Glyphs = new System.Windows.Forms.CheckBox();
            this.Lbl_Grid_Res_Y = new System.Windows.Forms.Label();
            this.NmrcUpDown_Grid_Res_Y = new System.Windows.Forms.NumericUpDown();
            this.Lbl_Grid_Res_X = new System.Windows.Forms.Label();
            this.NmrcUpDown_Grid_Res_X = new System.Windows.Forms.NumericUpDown();
            this.TrckBr_FocusValueSlider = new GradientControls.ColorTrackBar();
            this.TrckBr_ScalVal = new GradientControls.ColorTrackBar();
            this.RdBtn_Hatching = new System.Windows.Forms.RadioButton();
            this.RdBtn_Chessboard = new System.Windows.Forms.RadioButton();
            this.FPSTimer = new System.Windows.Forms.Timer(this.components);
            this.ReDrawTimer = new System.Windows.Forms.Timer(this.components);
            this.Clr_Dlg_Add_Region = new System.Windows.Forms.ColorDialog();
            this.Pnl_Risk_Analysis.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Splt_Cntr_View)).BeginInit();
            this.Splt_Cntr_View.Panel1.SuspendLayout();
            this.Splt_Cntr_View.Panel2.SuspendLayout();
            this.Splt_Cntr_View.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Splt_Contr_Brush)).BeginInit();
            this.Splt_Contr_Brush.Panel1.SuspendLayout();
            this.Splt_Contr_Brush.Panel2.SuspendLayout();
            this.Splt_Contr_Brush.SuspendLayout();
            this.Pnl_ScatterInteraction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NmrcUpDown_NumBins)).BeginInit();
            this.Pnl_StentSelectionBottom.SuspendLayout();
            this.Pnl_BEP_Parameters.SuspendLayout();
            this.Pnl_View_Map.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Splt_Contr_Analysis)).BeginInit();
            this.Splt_Contr_Analysis.Panel1.SuspendLayout();
            this.Splt_Contr_Analysis.Panel2.SuspendLayout();
            this.Splt_Contr_Analysis.SuspendLayout();
            this.Timespan_GrpBx.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Chrt_Time)).BeginInit();
            this.Pnl_View3D.SuspendLayout();
            this.Pnl_Region_Brushing.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NmrUpDown_BrushSize)).BeginInit();
            this.Pnl_3D_Interaction.SuspendLayout();
            this.Grp_Bx_Snd_Color_Scale.SuspendLayout();
            this.Grp_Bx_Fst_Color_Scale.SuspendLayout();
            this.Pnl_Map_Interaction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NmrcUpDown_Grid_Res_Y)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NmrcUpDown_Grid_Res_X)).BeginInit();
            this.SuspendLayout();
            // 
            // Pnl_Risk_Analysis
            // 
            this.Pnl_Risk_Analysis.Controls.Add(this.Splt_Cntr_View);
            this.Pnl_Risk_Analysis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pnl_Risk_Analysis.Location = new System.Drawing.Point(0, 0);
            this.Pnl_Risk_Analysis.Name = "Pnl_Risk_Analysis";
            this.Pnl_Risk_Analysis.Size = new System.Drawing.Size(1800, 1074);
            this.Pnl_Risk_Analysis.TabIndex = 0;
            // 
            // Splt_Cntr_View
            // 
            this.Splt_Cntr_View.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Splt_Cntr_View.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Splt_Cntr_View.Location = new System.Drawing.Point(0, 0);
            this.Splt_Cntr_View.Name = "Splt_Cntr_View";
            // 
            // Splt_Cntr_View.Panel1
            // 
            this.Splt_Cntr_View.Panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Splt_Cntr_View.Panel1.Controls.Add(this.Splt_Contr_Brush);
            this.Splt_Cntr_View.Panel1.SizeChanged += new System.EventHandler(this.Splt_Cntr_View_Panel1_SizeChanged);
            // 
            // Splt_Cntr_View.Panel2
            // 
            this.Splt_Cntr_View.Panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Splt_Cntr_View.Panel2.Controls.Add(this.Splt_Contr_Analysis);
            this.Splt_Cntr_View.Size = new System.Drawing.Size(1800, 1074);
            this.Splt_Cntr_View.SplitterDistance = 909;
            this.Splt_Cntr_View.TabIndex = 0;
            // 
            // Splt_Contr_Brush
            // 
            this.Splt_Contr_Brush.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Splt_Contr_Brush.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Splt_Contr_Brush.Location = new System.Drawing.Point(0, 0);
            this.Splt_Contr_Brush.Name = "Splt_Contr_Brush";
            this.Splt_Contr_Brush.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // Splt_Contr_Brush.Panel1
            // 
            this.Splt_Contr_Brush.Panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Splt_Contr_Brush.Panel1.Controls.Add(this.Pnl_ScatterInteraction);
            this.Splt_Contr_Brush.Panel1.Controls.Add(this.Btn_Equalize_SP);
            this.Splt_Contr_Brush.Panel1.Controls.Add(this.Pnl_StentSelectionBottom);
            this.Splt_Contr_Brush.Panel1.Controls.Add(this.Rd_Btn_Local_Scat);
            this.Splt_Contr_Brush.Panel1.Controls.Add(this.GrpBx_ParameterRow);
            this.Splt_Contr_Brush.Panel1.Controls.Add(this.RdBtn_Global_Scat);
            this.Splt_Contr_Brush.Panel1.Controls.Add(this.GrpBx_ParameterColumn);
            this.Splt_Contr_Brush.Panel1.Controls.Add(this.Pnl_Scatterplot);
            this.Splt_Contr_Brush.Panel1.Controls.Add(this.Txt_Bx_FPS);
            this.Splt_Contr_Brush.Panel1.SizeChanged += new System.EventHandler(this.Splt_Contr_Brush_Panel1_SizeChanged);
            // 
            // Splt_Contr_Brush.Panel2
            // 
            this.Splt_Contr_Brush.Panel2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Splt_Contr_Brush.Panel2.Controls.Add(this.button1);
            this.Splt_Contr_Brush.Panel2.Controls.Add(this.Pnl_BEP_Parameters);
            this.Splt_Contr_Brush.Panel2.Controls.Add(this.Pnl_View_Map);
            this.Splt_Contr_Brush.Size = new System.Drawing.Size(909, 1074);
            this.Splt_Contr_Brush.SplitterDistance = 526;
            this.Splt_Contr_Brush.TabIndex = 0;
            // 
            // Pnl_ScatterInteraction
            // 
            this.Pnl_ScatterInteraction.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pnl_ScatterInteraction.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Pnl_ScatterInteraction.Controls.Add(this.Chck_Bx_Substract);
            this.Pnl_ScatterInteraction.Controls.Add(this.Chck_Bx_InvertScatter);
            this.Pnl_ScatterInteraction.Controls.Add(this.NmrcUpDown_NumBins);
            this.Pnl_ScatterInteraction.Controls.Add(this.Cmb_Bx_StentSelectionTop);
            this.Pnl_ScatterInteraction.Location = new System.Drawing.Point(831, 38);
            this.Pnl_ScatterInteraction.Name = "Pnl_ScatterInteraction";
            this.Pnl_ScatterInteraction.Size = new System.Drawing.Size(74, 103);
            this.Pnl_ScatterInteraction.TabIndex = 10;
            // 
            // Chck_Bx_Substract
            // 
            this.Chck_Bx_Substract.AutoSize = true;
            this.Chck_Bx_Substract.Location = new System.Drawing.Point(15, 79);
            this.Chck_Bx_Substract.Name = "Chck_Bx_Substract";
            this.Chck_Bx_Substract.Size = new System.Drawing.Size(39, 17);
            this.Chck_Bx_Substract.TabIndex = 65;
            this.Chck_Bx_Substract.Text = "Dif";
            this.Chck_Bx_Substract.UseVisualStyleBackColor = true;
            this.Chck_Bx_Substract.CheckedChanged += new System.EventHandler(this.Chck_Bx_Substract_CheckedChanged);
            // 
            // Chck_Bx_InvertScatter
            // 
            this.Chck_Bx_InvertScatter.AutoSize = true;
            this.Chck_Bx_InvertScatter.Location = new System.Drawing.Point(15, 56);
            this.Chck_Bx_InvertScatter.Name = "Chck_Bx_InvertScatter";
            this.Chck_Bx_InvertScatter.Size = new System.Drawing.Size(53, 17);
            this.Chck_Bx_InvertScatter.TabIndex = 64;
            this.Chck_Bx_InvertScatter.Text = "Invert";
            this.Chck_Bx_InvertScatter.UseVisualStyleBackColor = true;
            this.Chck_Bx_InvertScatter.CheckedChanged += new System.EventHandler(this.Chck_Bx_InvertScatter_CheckedChanged);
            // 
            // NmrcUpDown_NumBins
            // 
            this.NmrcUpDown_NumBins.Location = new System.Drawing.Point(10, 27);
            this.NmrcUpDown_NumBins.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NmrcUpDown_NumBins.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NmrcUpDown_NumBins.Name = "NmrcUpDown_NumBins";
            this.NmrcUpDown_NumBins.Size = new System.Drawing.Size(58, 20);
            this.NmrcUpDown_NumBins.TabIndex = 11;
            this.NmrcUpDown_NumBins.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.NmrcUpDown_NumBins.ValueChanged += new System.EventHandler(this.NmrcUpDown_NumBins_ValueChanged);
            // 
            // Cmb_Bx_StentSelectionTop
            // 
            this.Cmb_Bx_StentSelectionTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.Cmb_Bx_StentSelectionTop.FormattingEnabled = true;
            this.Cmb_Bx_StentSelectionTop.Location = new System.Drawing.Point(0, 0);
            this.Cmb_Bx_StentSelectionTop.Name = "Cmb_Bx_StentSelectionTop";
            this.Cmb_Bx_StentSelectionTop.Size = new System.Drawing.Size(74, 21);
            this.Cmb_Bx_StentSelectionTop.TabIndex = 10;
            this.Cmb_Bx_StentSelectionTop.SelectedIndexChanged += new System.EventHandler(this.Cmb_Bx_StentSelectionTop_SelectedIndexChanged);
            // 
            // Btn_Equalize_SP
            // 
            this.Btn_Equalize_SP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Equalize_SP.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Equalize_SP.Location = new System.Drawing.Point(832, 190);
            this.Btn_Equalize_SP.Name = "Btn_Equalize_SP";
            this.Btn_Equalize_SP.Size = new System.Drawing.Size(67, 23);
            this.Btn_Equalize_SP.TabIndex = 5;
            this.Btn_Equalize_SP.Text = "Equal";
            this.Btn_Equalize_SP.UseVisualStyleBackColor = true;
            this.Btn_Equalize_SP.Click += new System.EventHandler(this.Btn_Equalize_SP_Click);
            // 
            // Pnl_StentSelectionBottom
            // 
            this.Pnl_StentSelectionBottom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Pnl_StentSelectionBottom.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Pnl_StentSelectionBottom.Controls.Add(this.Cmb_Bx_StentSelectionBottom);
            this.Pnl_StentSelectionBottom.Location = new System.Drawing.Point(831, 403);
            this.Pnl_StentSelectionBottom.Name = "Pnl_StentSelectionBottom";
            this.Pnl_StentSelectionBottom.Size = new System.Drawing.Size(74, 119);
            this.Pnl_StentSelectionBottom.TabIndex = 11;
            // 
            // Cmb_Bx_StentSelectionBottom
            // 
            this.Cmb_Bx_StentSelectionBottom.Dock = System.Windows.Forms.DockStyle.Top;
            this.Cmb_Bx_StentSelectionBottom.FormattingEnabled = true;
            this.Cmb_Bx_StentSelectionBottom.Location = new System.Drawing.Point(0, 0);
            this.Cmb_Bx_StentSelectionBottom.Name = "Cmb_Bx_StentSelectionBottom";
            this.Cmb_Bx_StentSelectionBottom.Size = new System.Drawing.Size(74, 21);
            this.Cmb_Bx_StentSelectionBottom.TabIndex = 10;
            this.Cmb_Bx_StentSelectionBottom.SelectedIndexChanged += new System.EventHandler(this.Cmb_Bx_StentSelectionBottom_SelectedIndexChanged);
            // 
            // Rd_Btn_Local_Scat
            // 
            this.Rd_Btn_Local_Scat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Rd_Btn_Local_Scat.AutoSize = true;
            this.Rd_Btn_Local_Scat.Location = new System.Drawing.Point(841, 167);
            this.Rd_Btn_Local_Scat.Name = "Rd_Btn_Local_Scat";
            this.Rd_Btn_Local_Scat.Size = new System.Drawing.Size(51, 17);
            this.Rd_Btn_Local_Scat.TabIndex = 8;
            this.Rd_Btn_Local_Scat.TabStop = true;
            this.Rd_Btn_Local_Scat.Text = "Local";
            this.Rd_Btn_Local_Scat.UseVisualStyleBackColor = true;
            this.Rd_Btn_Local_Scat.Visible = false;
            this.Rd_Btn_Local_Scat.CheckedChanged += new System.EventHandler(this.Rd_Btn_Local_Scat_CheckedChanged);
            // 
            // GrpBx_ParameterRow
            // 
            this.GrpBx_ParameterRow.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.GrpBx_ParameterRow.Location = new System.Drawing.Point(2, 32);
            this.GrpBx_ParameterRow.Margin = new System.Windows.Forms.Padding(0);
            this.GrpBx_ParameterRow.Name = "GrpBx_ParameterRow";
            this.GrpBx_ParameterRow.Size = new System.Drawing.Size(31, 492);
            this.GrpBx_ParameterRow.TabIndex = 3;
            this.GrpBx_ParameterRow.TabStop = false;
            // 
            // RdBtn_Global_Scat
            // 
            this.RdBtn_Global_Scat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RdBtn_Global_Scat.AutoSize = true;
            this.RdBtn_Global_Scat.Location = new System.Drawing.Point(840, 144);
            this.RdBtn_Global_Scat.Name = "RdBtn_Global_Scat";
            this.RdBtn_Global_Scat.Size = new System.Drawing.Size(55, 17);
            this.RdBtn_Global_Scat.TabIndex = 7;
            this.RdBtn_Global_Scat.TabStop = true;
            this.RdBtn_Global_Scat.Text = "Global";
            this.RdBtn_Global_Scat.UseVisualStyleBackColor = true;
            this.RdBtn_Global_Scat.Visible = false;
            this.RdBtn_Global_Scat.CheckedChanged += new System.EventHandler(this.RdBtn_Global_Scat_CheckedChanged);
            // 
            // GrpBx_ParameterColumn
            // 
            this.GrpBx_ParameterColumn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrpBx_ParameterColumn.Location = new System.Drawing.Point(36, 3);
            this.GrpBx_ParameterColumn.Margin = new System.Windows.Forms.Padding(0);
            this.GrpBx_ParameterColumn.Name = "GrpBx_ParameterColumn";
            this.GrpBx_ParameterColumn.Size = new System.Drawing.Size(789, 35);
            this.GrpBx_ParameterColumn.TabIndex = 2;
            this.GrpBx_ParameterColumn.TabStop = false;
            // 
            // Pnl_Scatterplot
            // 
            this.Pnl_Scatterplot.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Pnl_Scatterplot.BackColor = System.Drawing.Color.Transparent;
            this.Pnl_Scatterplot.Location = new System.Drawing.Point(36, 38);
            this.Pnl_Scatterplot.Name = "Pnl_Scatterplot";
            this.Pnl_Scatterplot.Size = new System.Drawing.Size(789, 486);
            this.Pnl_Scatterplot.TabIndex = 4;
            // 
            // Txt_Bx_FPS
            // 
            this.Txt_Bx_FPS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Txt_Bx_FPS.Location = new System.Drawing.Point(847, 219);
            this.Txt_Bx_FPS.Name = "Txt_Bx_FPS";
            this.Txt_Bx_FPS.Size = new System.Drawing.Size(55, 20);
            this.Txt_Bx_FPS.TabIndex = 9;
            this.Txt_Bx_FPS.Text = "FPS:";
            this.Txt_Bx_FPS.Visible = false;
            // 
            // Pnl_BEP_Parameters
            // 
            this.Pnl_BEP_Parameters.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pnl_BEP_Parameters.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Pnl_BEP_Parameters.Controls.Add(this.Btn_BEP_Parameters);
            this.Pnl_BEP_Parameters.Location = new System.Drawing.Point(831, 3);
            this.Pnl_BEP_Parameters.Name = "Pnl_BEP_Parameters";
            this.Pnl_BEP_Parameters.Size = new System.Drawing.Size(74, 30);
            this.Pnl_BEP_Parameters.TabIndex = 56;
            // 
            // Btn_BEP_Parameters
            // 
            this.Btn_BEP_Parameters.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Btn_BEP_Parameters.Location = new System.Drawing.Point(3, 3);
            this.Btn_BEP_Parameters.Name = "Btn_BEP_Parameters";
            this.Btn_BEP_Parameters.Size = new System.Drawing.Size(68, 23);
            this.Btn_BEP_Parameters.TabIndex = 56;
            this.Btn_BEP_Parameters.Text = "Parameters";
            this.Btn_BEP_Parameters.UseVisualStyleBackColor = true;
            this.Btn_BEP_Parameters.Click += new System.EventHandler(this.Btn_BEP_Parameters_Click);
            // 
            // Pnl_View_Map
            // 
            this.Pnl_View_Map.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Pnl_View_Map.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Pnl_View_Map.Controls.Add(this.Pnl_LegendView);
            this.Pnl_View_Map.Location = new System.Drawing.Point(0, 0);
            this.Pnl_View_Map.Name = "Pnl_View_Map";
            this.Pnl_View_Map.Size = new System.Drawing.Size(825, 544);
            this.Pnl_View_Map.TabIndex = 55;
            // 
            // Pnl_LegendView
            // 
            this.Pnl_LegendView.BackColor = System.Drawing.Color.Maroon;
            this.Pnl_LegendView.Location = new System.Drawing.Point(3, 3);
            this.Pnl_LegendView.Name = "Pnl_LegendView";
            this.Pnl_LegendView.Size = new System.Drawing.Size(150, 150);
            this.Pnl_LegendView.TabIndex = 57;
            // 
            // Splt_Contr_Analysis
            // 
            this.Splt_Contr_Analysis.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Splt_Contr_Analysis.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Splt_Contr_Analysis.Location = new System.Drawing.Point(0, 0);
            this.Splt_Contr_Analysis.Name = "Splt_Contr_Analysis";
            this.Splt_Contr_Analysis.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // Splt_Contr_Analysis.Panel1
            // 
            this.Splt_Contr_Analysis.Panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Splt_Contr_Analysis.Panel1.Controls.Add(this.Timespan_GrpBx);
            this.Splt_Contr_Analysis.Panel1.Controls.Add(this.Pnl_View3D);
            // 
            // Splt_Contr_Analysis.Panel2
            // 
            this.Splt_Contr_Analysis.Panel2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Splt_Contr_Analysis.Panel2.Controls.Add(this.Grp_Bx_Snd_Color_Scale);
            this.Splt_Contr_Analysis.Panel2.Controls.Add(this.Pnl_View_MapGlyph);
            this.Splt_Contr_Analysis.Panel2.Controls.Add(this.Grp_Bx_Fst_Color_Scale);
            this.Splt_Contr_Analysis.Panel2.Controls.Add(this.Pnl_Map_Interaction);
            this.Splt_Contr_Analysis.Size = new System.Drawing.Size(887, 1074);
            this.Splt_Contr_Analysis.SplitterDistance = 526;
            this.Splt_Contr_Analysis.TabIndex = 0;
            // 
            // Timespan_GrpBx
            // 
            this.Timespan_GrpBx.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Timespan_GrpBx.BackColor = System.Drawing.SystemColors.Control;
            this.Timespan_GrpBx.Controls.Add(this.Chck_Bx_Peak_Systole);
            this.Timespan_GrpBx.Controls.Add(this.Chck_Bx_Stop_Animation);
            this.Timespan_GrpBx.Controls.Add(this.Chrt_Time);
            this.Timespan_GrpBx.Controls.Add(this.TrckBr_CurrentTimeSlider);
            this.Timespan_GrpBx.Location = new System.Drawing.Point(3, 437);
            this.Timespan_GrpBx.Name = "Timespan_GrpBx";
            this.Timespan_GrpBx.Size = new System.Drawing.Size(881, 73);
            this.Timespan_GrpBx.TabIndex = 23;
            this.Timespan_GrpBx.TabStop = false;
            // 
            // Chck_Bx_Peak_Systole
            // 
            this.Chck_Bx_Peak_Systole.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Chck_Bx_Peak_Systole.AutoSize = true;
            this.Chck_Bx_Peak_Systole.BackColor = System.Drawing.SystemColors.Control;
            this.Chck_Bx_Peak_Systole.Location = new System.Drawing.Point(770, 55);
            this.Chck_Bx_Peak_Systole.Name = "Chck_Bx_Peak_Systole";
            this.Chck_Bx_Peak_Systole.Size = new System.Drawing.Size(88, 17);
            this.Chck_Bx_Peak_Systole.TabIndex = 52;
            this.Chck_Bx_Peak_Systole.Text = "Peak Systole";
            this.Chck_Bx_Peak_Systole.UseVisualStyleBackColor = false;
            this.Chck_Bx_Peak_Systole.CheckedChanged += new System.EventHandler(this.Chck_Bx_Peak_Systole_CheckedChanged);
            // 
            // Chck_Bx_Stop_Animation
            // 
            this.Chck_Bx_Stop_Animation.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Chck_Bx_Stop_Animation.AutoSize = true;
            this.Chck_Bx_Stop_Animation.BackColor = System.Drawing.SystemColors.Window;
            this.Chck_Bx_Stop_Animation.Location = new System.Drawing.Point(770, 33);
            this.Chck_Bx_Stop_Animation.Name = "Chck_Bx_Stop_Animation";
            this.Chck_Bx_Stop_Animation.Size = new System.Drawing.Size(48, 17);
            this.Chck_Bx_Stop_Animation.TabIndex = 51;
            this.Chck_Bx_Stop_Animation.Text = "Stop";
            this.Chck_Bx_Stop_Animation.UseVisualStyleBackColor = false;
            this.Chck_Bx_Stop_Animation.CheckedChanged += new System.EventHandler(this.Chck_Bx_Stop_Animation_CheckedChanged);
            // 
            // Chrt_Time
            // 
            this.Chrt_Time.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            chartArea1.AxisX.Title = "Time in [s]";
            chartArea1.AxisX.TitleAlignment = System.Drawing.StringAlignment.Far;
            chartArea1.AxisY.Enabled = System.Windows.Forms.DataVisualization.Charting.AxisEnabled.False;
            chartArea1.AxisY.IsMarginVisible = false;
            chartArea1.Name = "TimeArea";
            this.Chrt_Time.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.Chrt_Time.Legends.Add(legend1);
            this.Chrt_Time.Location = new System.Drawing.Point(3, 10);
            this.Chrt_Time.Margin = new System.Windows.Forms.Padding(0);
            this.Chrt_Time.Name = "Chrt_Time";
            series1.ChartArea = "TimeArea";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.IsVisibleInLegend = false;
            series1.Legend = "Legend1";
            series1.Name = "Time";
            series2.ChartArea = "TimeArea";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series2.Legend = "Legend1";
            series2.MarkerColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            series2.MarkerSize = 10;
            series2.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series2.Name = "CurrentTime";
            dataPoint1.LegendText = "Current Time";
            dataPoint1.MarkerColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataPoint1.MarkerSize = 10;
            dataPoint1.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Circle;
            series2.Points.Add(dataPoint1);
            this.Chrt_Time.Series.Add(series1);
            this.Chrt_Time.Series.Add(series2);
            this.Chrt_Time.Size = new System.Drawing.Size(869, 45);
            this.Chrt_Time.TabIndex = 50;
            this.Chrt_Time.Text = "chart1";
            // 
            // TrckBr_CurrentTimeSlider
            // 
            this.TrckBr_CurrentTimeSlider.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TrckBr_CurrentTimeSlider.BarBorderColor = System.Drawing.Color.Black;
            this.TrckBr_CurrentTimeSlider.BarColor = System.Drawing.Color.White;
            this.TrckBr_CurrentTimeSlider.BarOrientation = GradientControls.Orientations.Horizontal;
            this.TrckBr_CurrentTimeSlider.ControlCornerStyle = GradientControls.CornerStyles.Square;
            this.TrckBr_CurrentTimeSlider.Location = new System.Drawing.Point(28, 58);
            this.TrckBr_CurrentTimeSlider.Maximum = 100;
            this.TrckBr_CurrentTimeSlider.MaximumValueSide = GradientControls.Poles.Right;
            this.TrckBr_CurrentTimeSlider.Minimum = 0;
            this.TrckBr_CurrentTimeSlider.Name = "TrckBr_CurrentTimeSlider";
            this.TrckBr_CurrentTimeSlider.Size = new System.Drawing.Size(714, 10);
            this.TrckBr_CurrentTimeSlider.TabIndex = 49;
            this.TrckBr_CurrentTimeSlider.TrackerBorderColor = System.Drawing.Color.Black;
            this.TrckBr_CurrentTimeSlider.TrackerColor = System.Drawing.Color.Red;
            this.TrckBr_CurrentTimeSlider.TrackerSize = 15;
            this.TrckBr_CurrentTimeSlider.Value = 0;
            this.TrckBr_CurrentTimeSlider.Scroll += new GradientControls.ColorTrackBar.ScrollEventHandler(this.Current_TimeSlider_TrckBr_Scroll);
            // 
            // Pnl_View3D
            // 
            this.Pnl_View3D.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Pnl_View3D.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Pnl_View3D.Controls.Add(this.Pnl_Region_Brushing);
            this.Pnl_View3D.Controls.Add(this.Pnl_3D_Interaction);
            this.Pnl_View3D.Location = new System.Drawing.Point(2, 3);
            this.Pnl_View3D.Name = "Pnl_View3D";
            this.Pnl_View3D.Size = new System.Drawing.Size(882, 431);
            this.Pnl_View3D.TabIndex = 5;
            // 
            // Pnl_Region_Brushing
            // 
            this.Pnl_Region_Brushing.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pnl_Region_Brushing.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Pnl_Region_Brushing.Controls.Add(this.Chck_Bx_Show_Regions);
            this.Pnl_Region_Brushing.Controls.Add(this.Btn_Reset_Brushing);
            this.Pnl_Region_Brushing.Controls.Add(this.Btn_Clear_Brushing);
            this.Pnl_Region_Brushing.Controls.Add(this.Lbl_Brush_Size);
            this.Pnl_Region_Brushing.Controls.Add(this.NmrUpDown_BrushSize);
            this.Pnl_Region_Brushing.Controls.Add(this.Btn_Add_Region);
            this.Pnl_Region_Brushing.Controls.Add(this.Lst_Vw_Regions);
            this.Pnl_Region_Brushing.Location = new System.Drawing.Point(796, 171);
            this.Pnl_Region_Brushing.Name = "Pnl_Region_Brushing";
            this.Pnl_Region_Brushing.Size = new System.Drawing.Size(80, 257);
            this.Pnl_Region_Brushing.TabIndex = 59;
            // 
            // Chck_Bx_Show_Regions
            // 
            this.Chck_Bx_Show_Regions.AutoSize = true;
            this.Chck_Bx_Show_Regions.Location = new System.Drawing.Point(3, 3);
            this.Chck_Bx_Show_Regions.Name = "Chck_Bx_Show_Regions";
            this.Chck_Bx_Show_Regions.Size = new System.Drawing.Size(53, 17);
            this.Chck_Bx_Show_Regions.TabIndex = 63;
            this.Chck_Bx_Show_Regions.Text = "Show";
            this.Chck_Bx_Show_Regions.UseVisualStyleBackColor = true;
            this.Chck_Bx_Show_Regions.CheckedChanged += new System.EventHandler(this.Chck_Bx_Show_Regions_CheckedChanged);
            // 
            // Btn_Reset_Brushing
            // 
            this.Btn_Reset_Brushing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Reset_Brushing.Location = new System.Drawing.Point(3, 231);
            this.Btn_Reset_Brushing.Name = "Btn_Reset_Brushing";
            this.Btn_Reset_Brushing.Size = new System.Drawing.Size(74, 23);
            this.Btn_Reset_Brushing.TabIndex = 64;
            this.Btn_Reset_Brushing.Text = "Reset";
            this.Btn_Reset_Brushing.UseVisualStyleBackColor = true;
            this.Btn_Reset_Brushing.Click += new System.EventHandler(this.Btn_Reset_Brushing_Click);
            // 
            // Btn_Clear_Brushing
            // 
            this.Btn_Clear_Brushing.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Clear_Brushing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Clear_Brushing.Location = new System.Drawing.Point(3, 202);
            this.Btn_Clear_Brushing.Name = "Btn_Clear_Brushing";
            this.Btn_Clear_Brushing.Size = new System.Drawing.Size(74, 23);
            this.Btn_Clear_Brushing.TabIndex = 6;
            this.Btn_Clear_Brushing.Text = "Clear";
            this.Btn_Clear_Brushing.UseVisualStyleBackColor = true;
            this.Btn_Clear_Brushing.Click += new System.EventHandler(this.Btn_Clear_Brushing_Click);
            // 
            // Lbl_Brush_Size
            // 
            this.Lbl_Brush_Size.AutoSize = true;
            this.Lbl_Brush_Size.Location = new System.Drawing.Point(3, 52);
            this.Lbl_Brush_Size.Name = "Lbl_Brush_Size";
            this.Lbl_Brush_Size.Size = new System.Drawing.Size(57, 13);
            this.Lbl_Brush_Size.TabIndex = 63;
            this.Lbl_Brush_Size.Text = "Brush Size";
            // 
            // NmrUpDown_BrushSize
            // 
            this.NmrUpDown_BrushSize.Increment = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.NmrUpDown_BrushSize.Location = new System.Drawing.Point(3, 71);
            this.NmrUpDown_BrushSize.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.NmrUpDown_BrushSize.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.NmrUpDown_BrushSize.Name = "NmrUpDown_BrushSize";
            this.NmrUpDown_BrushSize.Size = new System.Drawing.Size(74, 20);
            this.NmrUpDown_BrushSize.TabIndex = 62;
            this.NmrUpDown_BrushSize.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NmrUpDown_BrushSize.ValueChanged += new System.EventHandler(this.NmrUpDown_BrushSize_ValueChanged);
            // 
            // Btn_Add_Region
            // 
            this.Btn_Add_Region.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Add_Region.Location = new System.Drawing.Point(3, 26);
            this.Btn_Add_Region.Name = "Btn_Add_Region";
            this.Btn_Add_Region.Size = new System.Drawing.Size(74, 23);
            this.Btn_Add_Region.TabIndex = 0;
            this.Btn_Add_Region.Text = "Add Region";
            this.Btn_Add_Region.UseVisualStyleBackColor = true;
            this.Btn_Add_Region.Click += new System.EventHandler(this.Btn_Add_Region_Click);
            // 
            // Lst_Vw_Regions
            // 
            this.Lst_Vw_Regions.Location = new System.Drawing.Point(3, 97);
            this.Lst_Vw_Regions.MultiSelect = false;
            this.Lst_Vw_Regions.Name = "Lst_Vw_Regions";
            this.Lst_Vw_Regions.Size = new System.Drawing.Size(74, 99);
            this.Lst_Vw_Regions.TabIndex = 61;
            this.Lst_Vw_Regions.UseCompatibleStateImageBehavior = false;
            this.Lst_Vw_Regions.View = System.Windows.Forms.View.List;
            this.Lst_Vw_Regions.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Lst_Vw_Regions_KeyUp);
            // 
            // Pnl_3D_Interaction
            // 
            this.Pnl_3D_Interaction.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pnl_3D_Interaction.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Pnl_3D_Interaction.Controls.Add(this.Btn_Analysis);
            this.Pnl_3D_Interaction.Controls.Add(this.Chck_Bx_ShowClustering);
            this.Pnl_3D_Interaction.Controls.Add(this.Btn_Mesh_Clustering);
            this.Pnl_3D_Interaction.Controls.Add(this.Lbl_Opacity);
            this.Pnl_3D_Interaction.Controls.Add(this.TrckBr_Mesh_Opacity);
            this.Pnl_3D_Interaction.Location = new System.Drawing.Point(796, 3);
            this.Pnl_3D_Interaction.Name = "Pnl_3D_Interaction";
            this.Pnl_3D_Interaction.Size = new System.Drawing.Size(80, 140);
            this.Pnl_3D_Interaction.TabIndex = 58;
            // 
            // Btn_Analysis
            // 
            this.Btn_Analysis.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Btn_Analysis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Analysis.Location = new System.Drawing.Point(3, 97);
            this.Btn_Analysis.Name = "Btn_Analysis";
            this.Btn_Analysis.Size = new System.Drawing.Size(74, 38);
            this.Btn_Analysis.TabIndex = 11;
            this.Btn_Analysis.Text = "Analyze Region";
            this.Btn_Analysis.UseVisualStyleBackColor = true;
            this.Btn_Analysis.Click += new System.EventHandler(this.Btn_Analysis_Click);
            // 
            // Chck_Bx_ShowClustering
            // 
            this.Chck_Bx_ShowClustering.AutoSize = true;
            this.Chck_Bx_ShowClustering.Location = new System.Drawing.Point(3, 75);
            this.Chck_Bx_ShowClustering.Name = "Chck_Bx_ShowClustering";
            this.Chck_Bx_ShowClustering.Size = new System.Drawing.Size(53, 17);
            this.Chck_Bx_ShowClustering.TabIndex = 63;
            this.Chck_Bx_ShowClustering.Text = "Show";
            this.Chck_Bx_ShowClustering.UseVisualStyleBackColor = true;
            this.Chck_Bx_ShowClustering.Visible = false;
            this.Chck_Bx_ShowClustering.CheckedChanged += new System.EventHandler(this.Chck_Bx_ShowClustering_CheckedChanged);
            // 
            // Btn_Mesh_Clustering
            // 
            this.Btn_Mesh_Clustering.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Mesh_Clustering.Location = new System.Drawing.Point(3, 46);
            this.Btn_Mesh_Clustering.Name = "Btn_Mesh_Clustering";
            this.Btn_Mesh_Clustering.Size = new System.Drawing.Size(74, 23);
            this.Btn_Mesh_Clustering.TabIndex = 0;
            this.Btn_Mesh_Clustering.Text = "Clustering";
            this.Btn_Mesh_Clustering.UseVisualStyleBackColor = true;
            this.Btn_Mesh_Clustering.Click += new System.EventHandler(this.Btn_Mesh_Clustering_Click);
            // 
            // Lbl_Opacity
            // 
            this.Lbl_Opacity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Opacity.AutoSize = true;
            this.Lbl_Opacity.Location = new System.Drawing.Point(17, 6);
            this.Lbl_Opacity.Name = "Lbl_Opacity";
            this.Lbl_Opacity.Size = new System.Drawing.Size(43, 13);
            this.Lbl_Opacity.TabIndex = 59;
            this.Lbl_Opacity.Text = "Opacity";
            // 
            // TrckBr_Mesh_Opacity
            // 
            this.TrckBr_Mesh_Opacity.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TrckBr_Mesh_Opacity.BarBorderColor = System.Drawing.Color.Black;
            this.TrckBr_Mesh_Opacity.BarColor = System.Drawing.Color.White;
            this.TrckBr_Mesh_Opacity.BarOrientation = GradientControls.Orientations.Horizontal;
            this.TrckBr_Mesh_Opacity.ControlCornerStyle = GradientControls.CornerStyles.Square;
            this.TrckBr_Mesh_Opacity.Location = new System.Drawing.Point(3, 23);
            this.TrckBr_Mesh_Opacity.Maximum = 100;
            this.TrckBr_Mesh_Opacity.MaximumValueSide = GradientControls.Poles.Right;
            this.TrckBr_Mesh_Opacity.Minimum = 10;
            this.TrckBr_Mesh_Opacity.Name = "TrckBr_Mesh_Opacity";
            this.TrckBr_Mesh_Opacity.Size = new System.Drawing.Size(74, 17);
            this.TrckBr_Mesh_Opacity.TabIndex = 53;
            this.TrckBr_Mesh_Opacity.TrackerBorderColor = System.Drawing.Color.Black;
            this.TrckBr_Mesh_Opacity.TrackerColor = System.Drawing.Color.Red;
            this.TrckBr_Mesh_Opacity.TrackerSize = 10;
            this.TrckBr_Mesh_Opacity.Value = 100;
            this.TrckBr_Mesh_Opacity.Scroll += new GradientControls.ColorTrackBar.ScrollEventHandler(this.TrckBr_Mesh_Opacity_Scroll);
            // 
            // Grp_Bx_Snd_Color_Scale
            // 
            this.Grp_Bx_Snd_Color_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Grp_Bx_Snd_Color_Scale.Controls.Add(this.Pnl_ColorLeg_2);
            this.Grp_Bx_Snd_Color_Scale.Controls.Add(this.Lbl_Col4_Snd_Scale);
            this.Grp_Bx_Snd_Color_Scale.Controls.Add(this.Lbl_Col0_Snd_Scale);
            this.Grp_Bx_Snd_Color_Scale.Controls.Add(this.Lbl_Col1_Snd_Scale);
            this.Grp_Bx_Snd_Color_Scale.Controls.Add(this.Lbl_Col3_Snd_Scale);
            this.Grp_Bx_Snd_Color_Scale.Controls.Add(this.Lbl_Col2_Snd_Scale);
            this.Grp_Bx_Snd_Color_Scale.Location = new System.Drawing.Point(806, 354);
            this.Grp_Bx_Snd_Color_Scale.Margin = new System.Windows.Forms.Padding(1);
            this.Grp_Bx_Snd_Color_Scale.Name = "Grp_Bx_Snd_Color_Scale";
            this.Grp_Bx_Snd_Color_Scale.Size = new System.Drawing.Size(78, 189);
            this.Grp_Bx_Snd_Color_Scale.TabIndex = 58;
            this.Grp_Bx_Snd_Color_Scale.TabStop = false;
            // 
            // Pnl_ColorLeg_2
            // 
            this.Pnl_ColorLeg_2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Pnl_ColorLeg_2.Location = new System.Drawing.Point(48, 8);
            this.Pnl_ColorLeg_2.Name = "Pnl_ColorLeg_2";
            this.Pnl_ColorLeg_2.Size = new System.Drawing.Size(25, 147);
            this.Pnl_ColorLeg_2.TabIndex = 12;
            // 
            // Lbl_Col4_Snd_Scale
            // 
            this.Lbl_Col4_Snd_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Col4_Snd_Scale.AutoSize = true;
            this.Lbl_Col4_Snd_Scale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Col4_Snd_Scale.Location = new System.Drawing.Point(5, 8);
            this.Lbl_Col4_Snd_Scale.Name = "Lbl_Col4_Snd_Scale";
            this.Lbl_Col4_Snd_Scale.Size = new System.Drawing.Size(31, 15);
            this.Lbl_Col4_Snd_Scale.TabIndex = 15;
            this.Lbl_Col4_Snd_Scale.Text = "100";
            // 
            // Lbl_Col0_Snd_Scale
            // 
            this.Lbl_Col0_Snd_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Col0_Snd_Scale.AutoSize = true;
            this.Lbl_Col0_Snd_Scale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Col0_Snd_Scale.Location = new System.Drawing.Point(5, 148);
            this.Lbl_Col0_Snd_Scale.Name = "Lbl_Col0_Snd_Scale";
            this.Lbl_Col0_Snd_Scale.Size = new System.Drawing.Size(15, 15);
            this.Lbl_Col0_Snd_Scale.TabIndex = 11;
            this.Lbl_Col0_Snd_Scale.Text = "0";
            // 
            // Lbl_Col1_Snd_Scale
            // 
            this.Lbl_Col1_Snd_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Col1_Snd_Scale.AutoSize = true;
            this.Lbl_Col1_Snd_Scale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Col1_Snd_Scale.Location = new System.Drawing.Point(5, 114);
            this.Lbl_Col1_Snd_Scale.Name = "Lbl_Col1_Snd_Scale";
            this.Lbl_Col1_Snd_Scale.Size = new System.Drawing.Size(31, 15);
            this.Lbl_Col1_Snd_Scale.TabIndex = 12;
            this.Lbl_Col1_Snd_Scale.Text = "100";
            // 
            // Lbl_Col3_Snd_Scale
            // 
            this.Lbl_Col3_Snd_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Col3_Snd_Scale.AutoSize = true;
            this.Lbl_Col3_Snd_Scale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Col3_Snd_Scale.Location = new System.Drawing.Point(5, 42);
            this.Lbl_Col3_Snd_Scale.Name = "Lbl_Col3_Snd_Scale";
            this.Lbl_Col3_Snd_Scale.Size = new System.Drawing.Size(31, 15);
            this.Lbl_Col3_Snd_Scale.TabIndex = 14;
            this.Lbl_Col3_Snd_Scale.Text = "100";
            // 
            // Lbl_Col2_Snd_Scale
            // 
            this.Lbl_Col2_Snd_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Col2_Snd_Scale.AutoSize = true;
            this.Lbl_Col2_Snd_Scale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Col2_Snd_Scale.Location = new System.Drawing.Point(5, 77);
            this.Lbl_Col2_Snd_Scale.Name = "Lbl_Col2_Snd_Scale";
            this.Lbl_Col2_Snd_Scale.Size = new System.Drawing.Size(31, 15);
            this.Lbl_Col2_Snd_Scale.TabIndex = 13;
            this.Lbl_Col2_Snd_Scale.Text = "100";
            // 
            // Pnl_View_MapGlyph
            // 
            this.Pnl_View_MapGlyph.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Pnl_View_MapGlyph.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Pnl_View_MapGlyph.Location = new System.Drawing.Point(0, 0);
            this.Pnl_View_MapGlyph.Name = "Pnl_View_MapGlyph";
            this.Pnl_View_MapGlyph.Size = new System.Drawing.Size(771, 544);
            this.Pnl_View_MapGlyph.TabIndex = 56;
            // 
            // Grp_Bx_Fst_Color_Scale
            // 
            this.Grp_Bx_Fst_Color_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Grp_Bx_Fst_Color_Scale.Controls.Add(this.Pnl_ColorLeg_1);
            this.Grp_Bx_Fst_Color_Scale.Controls.Add(this.Lbl_Col4_Fst_Scale);
            this.Grp_Bx_Fst_Color_Scale.Controls.Add(this.Lbl_Col0_Fst_Scale);
            this.Grp_Bx_Fst_Color_Scale.Controls.Add(this.Lbl_Col3_Fst_Scale);
            this.Grp_Bx_Fst_Color_Scale.Controls.Add(this.Lbl_Col1_Fst_Scale);
            this.Grp_Bx_Fst_Color_Scale.Controls.Add(this.Lbl_Col2_Fst_Scale);
            this.Grp_Bx_Fst_Color_Scale.Location = new System.Drawing.Point(806, 165);
            this.Grp_Bx_Fst_Color_Scale.Margin = new System.Windows.Forms.Padding(1);
            this.Grp_Bx_Fst_Color_Scale.Name = "Grp_Bx_Fst_Color_Scale";
            this.Grp_Bx_Fst_Color_Scale.Size = new System.Drawing.Size(78, 187);
            this.Grp_Bx_Fst_Color_Scale.TabIndex = 57;
            this.Grp_Bx_Fst_Color_Scale.TabStop = false;
            // 
            // Pnl_ColorLeg_1
            // 
            this.Pnl_ColorLeg_1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Pnl_ColorLeg_1.Location = new System.Drawing.Point(48, 9);
            this.Pnl_ColorLeg_1.Name = "Pnl_ColorLeg_1";
            this.Pnl_ColorLeg_1.Size = new System.Drawing.Size(25, 147);
            this.Pnl_ColorLeg_1.TabIndex = 11;
            // 
            // Lbl_Col4_Fst_Scale
            // 
            this.Lbl_Col4_Fst_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Col4_Fst_Scale.AutoSize = true;
            this.Lbl_Col4_Fst_Scale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Col4_Fst_Scale.Location = new System.Drawing.Point(9, 7);
            this.Lbl_Col4_Fst_Scale.Name = "Lbl_Col4_Fst_Scale";
            this.Lbl_Col4_Fst_Scale.Size = new System.Drawing.Size(31, 15);
            this.Lbl_Col4_Fst_Scale.TabIndex = 10;
            this.Lbl_Col4_Fst_Scale.Text = "100";
            // 
            // Lbl_Col0_Fst_Scale
            // 
            this.Lbl_Col0_Fst_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Col0_Fst_Scale.AutoSize = true;
            this.Lbl_Col0_Fst_Scale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Col0_Fst_Scale.Location = new System.Drawing.Point(9, 147);
            this.Lbl_Col0_Fst_Scale.Name = "Lbl_Col0_Fst_Scale";
            this.Lbl_Col0_Fst_Scale.Size = new System.Drawing.Size(15, 15);
            this.Lbl_Col0_Fst_Scale.TabIndex = 6;
            this.Lbl_Col0_Fst_Scale.Text = "0";
            // 
            // Lbl_Col3_Fst_Scale
            // 
            this.Lbl_Col3_Fst_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Col3_Fst_Scale.AutoSize = true;
            this.Lbl_Col3_Fst_Scale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Col3_Fst_Scale.Location = new System.Drawing.Point(9, 41);
            this.Lbl_Col3_Fst_Scale.Name = "Lbl_Col3_Fst_Scale";
            this.Lbl_Col3_Fst_Scale.Size = new System.Drawing.Size(31, 15);
            this.Lbl_Col3_Fst_Scale.TabIndex = 9;
            this.Lbl_Col3_Fst_Scale.Text = "100";
            // 
            // Lbl_Col1_Fst_Scale
            // 
            this.Lbl_Col1_Fst_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Col1_Fst_Scale.AutoSize = true;
            this.Lbl_Col1_Fst_Scale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Col1_Fst_Scale.Location = new System.Drawing.Point(9, 113);
            this.Lbl_Col1_Fst_Scale.Name = "Lbl_Col1_Fst_Scale";
            this.Lbl_Col1_Fst_Scale.Size = new System.Drawing.Size(31, 15);
            this.Lbl_Col1_Fst_Scale.TabIndex = 7;
            this.Lbl_Col1_Fst_Scale.Text = "100";
            // 
            // Lbl_Col2_Fst_Scale
            // 
            this.Lbl_Col2_Fst_Scale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Lbl_Col2_Fst_Scale.AutoSize = true;
            this.Lbl_Col2_Fst_Scale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Col2_Fst_Scale.Location = new System.Drawing.Point(9, 76);
            this.Lbl_Col2_Fst_Scale.Name = "Lbl_Col2_Fst_Scale";
            this.Lbl_Col2_Fst_Scale.Size = new System.Drawing.Size(31, 15);
            this.Lbl_Col2_Fst_Scale.TabIndex = 8;
            this.Lbl_Col2_Fst_Scale.Text = "100";
            // 
            // Pnl_Map_Interaction
            // 
            this.Pnl_Map_Interaction.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Pnl_Map_Interaction.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Pnl_Map_Interaction.Controls.Add(this.ChckBx_Glyphs);
            this.Pnl_Map_Interaction.Controls.Add(this.Lbl_Grid_Res_Y);
            this.Pnl_Map_Interaction.Controls.Add(this.NmrcUpDown_Grid_Res_Y);
            this.Pnl_Map_Interaction.Controls.Add(this.Lbl_Grid_Res_X);
            this.Pnl_Map_Interaction.Controls.Add(this.NmrcUpDown_Grid_Res_X);
            this.Pnl_Map_Interaction.Controls.Add(this.TrckBr_FocusValueSlider);
            this.Pnl_Map_Interaction.Controls.Add(this.TrckBr_ScalVal);
            this.Pnl_Map_Interaction.Controls.Add(this.RdBtn_Hatching);
            this.Pnl_Map_Interaction.Controls.Add(this.RdBtn_Chessboard);
            this.Pnl_Map_Interaction.Location = new System.Drawing.Point(777, 3);
            this.Pnl_Map_Interaction.Margin = new System.Windows.Forms.Padding(1);
            this.Pnl_Map_Interaction.Name = "Pnl_Map_Interaction";
            this.Pnl_Map_Interaction.Size = new System.Drawing.Size(107, 160);
            this.Pnl_Map_Interaction.TabIndex = 56;
            // 
            // ChckBx_Glyphs
            // 
            this.ChckBx_Glyphs.AutoSize = true;
            this.ChckBx_Glyphs.Location = new System.Drawing.Point(3, 137);
            this.ChckBx_Glyphs.Name = "ChckBx_Glyphs";
            this.ChckBx_Glyphs.Size = new System.Drawing.Size(83, 17);
            this.ChckBx_Glyphs.TabIndex = 62;
            this.ChckBx_Glyphs.Text = "Hide Glyphs";
            this.ChckBx_Glyphs.UseVisualStyleBackColor = true;
            this.ChckBx_Glyphs.CheckedChanged += new System.EventHandler(this.ChckBx_Glyphs_CheckedChanged);
            // 
            // Lbl_Grid_Res_Y
            // 
            this.Lbl_Grid_Res_Y.AutoSize = true;
            this.Lbl_Grid_Res_Y.Location = new System.Drawing.Point(7, 73);
            this.Lbl_Grid_Res_Y.Name = "Lbl_Grid_Res_Y";
            this.Lbl_Grid_Res_Y.Size = new System.Drawing.Size(14, 13);
            this.Lbl_Grid_Res_Y.TabIndex = 61;
            this.Lbl_Grid_Res_Y.Text = "Y";
            // 
            // NmrcUpDown_Grid_Res_Y
            // 
            this.NmrcUpDown_Grid_Res_Y.Location = new System.Drawing.Point(29, 71);
            this.NmrcUpDown_Grid_Res_Y.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.NmrcUpDown_Grid_Res_Y.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NmrcUpDown_Grid_Res_Y.Name = "NmrcUpDown_Grid_Res_Y";
            this.NmrcUpDown_Grid_Res_Y.Size = new System.Drawing.Size(36, 20);
            this.NmrcUpDown_Grid_Res_Y.TabIndex = 60;
            this.NmrcUpDown_Grid_Res_Y.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.NmrcUpDown_Grid_Res_Y.ValueChanged += new System.EventHandler(this.NmrcUpDown_Grid_Res_Y_ValueChanged);
            // 
            // Lbl_Grid_Res_X
            // 
            this.Lbl_Grid_Res_X.AutoSize = true;
            this.Lbl_Grid_Res_X.Location = new System.Drawing.Point(7, 47);
            this.Lbl_Grid_Res_X.Name = "Lbl_Grid_Res_X";
            this.Lbl_Grid_Res_X.Size = new System.Drawing.Size(14, 13);
            this.Lbl_Grid_Res_X.TabIndex = 59;
            this.Lbl_Grid_Res_X.Text = "X";
            // 
            // NmrcUpDown_Grid_Res_X
            // 
            this.NmrcUpDown_Grid_Res_X.Location = new System.Drawing.Point(29, 45);
            this.NmrcUpDown_Grid_Res_X.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.NmrcUpDown_Grid_Res_X.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NmrcUpDown_Grid_Res_X.Name = "NmrcUpDown_Grid_Res_X";
            this.NmrcUpDown_Grid_Res_X.Size = new System.Drawing.Size(36, 20);
            this.NmrcUpDown_Grid_Res_X.TabIndex = 58;
            this.NmrcUpDown_Grid_Res_X.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.NmrcUpDown_Grid_Res_X.ValueChanged += new System.EventHandler(this.NmrcUpDown_Grid_Res_X_ValueChanged);
            // 
            // TrckBr_FocusValueSlider
            // 
            this.TrckBr_FocusValueSlider.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TrckBr_FocusValueSlider.BarBorderColor = System.Drawing.Color.Black;
            this.TrckBr_FocusValueSlider.BarColor = System.Drawing.Color.White;
            this.TrckBr_FocusValueSlider.BarOrientation = GradientControls.Orientations.Horizontal;
            this.TrckBr_FocusValueSlider.ControlCornerStyle = GradientControls.CornerStyles.Square;
            this.TrckBr_FocusValueSlider.Location = new System.Drawing.Point(21, 26);
            this.TrckBr_FocusValueSlider.Maximum = 100;
            this.TrckBr_FocusValueSlider.MaximumValueSide = GradientControls.Poles.Right;
            this.TrckBr_FocusValueSlider.Minimum = 0;
            this.TrckBr_FocusValueSlider.Name = "TrckBr_FocusValueSlider";
            this.TrckBr_FocusValueSlider.Size = new System.Drawing.Size(82, 13);
            this.TrckBr_FocusValueSlider.TabIndex = 53;
            this.TrckBr_FocusValueSlider.TrackerBorderColor = System.Drawing.Color.Black;
            this.TrckBr_FocusValueSlider.TrackerColor = System.Drawing.Color.Red;
            this.TrckBr_FocusValueSlider.TrackerSize = 10;
            this.TrckBr_FocusValueSlider.Value = 50;
            this.TrckBr_FocusValueSlider.Scroll += new GradientControls.ColorTrackBar.ScrollEventHandler(this.TrckBr_FocusValueSlider_Scroll);
            // 
            // TrckBr_ScalVal
            // 
            this.TrckBr_ScalVal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.TrckBr_ScalVal.BarBorderColor = System.Drawing.Color.Black;
            this.TrckBr_ScalVal.BarColor = System.Drawing.Color.White;
            this.TrckBr_ScalVal.BarOrientation = GradientControls.Orientations.Horizontal;
            this.TrckBr_ScalVal.ControlCornerStyle = GradientControls.CornerStyles.Square;
            this.TrckBr_ScalVal.Location = new System.Drawing.Point(21, 117);
            this.TrckBr_ScalVal.Maximum = 100;
            this.TrckBr_ScalVal.MaximumValueSide = GradientControls.Poles.Right;
            this.TrckBr_ScalVal.Minimum = 0;
            this.TrckBr_ScalVal.Name = "TrckBr_ScalVal";
            this.TrckBr_ScalVal.Size = new System.Drawing.Size(82, 13);
            this.TrckBr_ScalVal.TabIndex = 57;
            this.TrckBr_ScalVal.TrackerBorderColor = System.Drawing.Color.Black;
            this.TrckBr_ScalVal.TrackerColor = System.Drawing.Color.Red;
            this.TrckBr_ScalVal.TrackerSize = 10;
            this.TrckBr_ScalVal.Value = 50;
            this.TrckBr_ScalVal.Scroll += new GradientControls.ColorTrackBar.ScrollEventHandler(this.TrckBr_ScalVal_Scroll);
            // 
            // RdBtn_Hatching
            // 
            this.RdBtn_Hatching.AutoSize = true;
            this.RdBtn_Hatching.Location = new System.Drawing.Point(3, 94);
            this.RdBtn_Hatching.Name = "RdBtn_Hatching";
            this.RdBtn_Hatching.Size = new System.Drawing.Size(68, 17);
            this.RdBtn_Hatching.TabIndex = 56;
            this.RdBtn_Hatching.TabStop = true;
            this.RdBtn_Hatching.Text = "Hatching";
            this.RdBtn_Hatching.UseVisualStyleBackColor = true;
            this.RdBtn_Hatching.CheckedChanged += new System.EventHandler(this.RdBtn_Hatching_CheckedChanged);
            // 
            // RdBtn_Chessboard
            // 
            this.RdBtn_Chessboard.AutoSize = true;
            this.RdBtn_Chessboard.Location = new System.Drawing.Point(2, 3);
            this.RdBtn_Chessboard.Name = "RdBtn_Chessboard";
            this.RdBtn_Chessboard.Size = new System.Drawing.Size(64, 17);
            this.RdBtn_Chessboard.TabIndex = 55;
            this.RdBtn_Chessboard.TabStop = true;
            this.RdBtn_Chessboard.Text = "Squares";
            this.RdBtn_Chessboard.UseVisualStyleBackColor = true;
            this.RdBtn_Chessboard.CheckedChanged += new System.EventHandler(this.RdBtn_Chessboard_CheckedChanged);
            // 
            // FPSTimer
            // 
            this.FPSTimer.Enabled = true;
            this.FPSTimer.Interval = 1000;
            this.FPSTimer.Tick += new System.EventHandler(this.FPSTimer_Tick);
            // 
            // ReDrawTimer
            // 
            this.ReDrawTimer.Enabled = true;
            this.ReDrawTimer.Interval = 15;
            this.ReDrawTimer.Tick += new System.EventHandler(this.ReDrawTimer_Tick);
            // 
            // Clr_Dlg_Add_Region
            // 
            this.Clr_Dlg_Add_Region.FullOpen = true;
            // 
            // Control_Risk_Analysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Pnl_Risk_Analysis);
            this.Name = "Control_Risk_Analysis";
            this.Size = new System.Drawing.Size(1800, 1074);
            this.Load += new System.EventHandler(this.Control_Risk_Analysis_Load);
            this.Resize += new System.EventHandler(this.Control_Risk_Analysis_Resize);
            this.Pnl_Risk_Analysis.ResumeLayout(false);
            this.Splt_Cntr_View.Panel1.ResumeLayout(false);
            this.Splt_Cntr_View.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Splt_Cntr_View)).EndInit();
            this.Splt_Cntr_View.ResumeLayout(false);
            this.Splt_Contr_Brush.Panel1.ResumeLayout(false);
            this.Splt_Contr_Brush.Panel1.PerformLayout();
            this.Splt_Contr_Brush.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Splt_Contr_Brush)).EndInit();
            this.Splt_Contr_Brush.ResumeLayout(false);
            this.Pnl_ScatterInteraction.ResumeLayout(false);
            this.Pnl_ScatterInteraction.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NmrcUpDown_NumBins)).EndInit();
            this.Pnl_StentSelectionBottom.ResumeLayout(false);
            this.Pnl_BEP_Parameters.ResumeLayout(false);
            this.Pnl_View_Map.ResumeLayout(false);
            this.Splt_Contr_Analysis.Panel1.ResumeLayout(false);
            this.Splt_Contr_Analysis.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Splt_Contr_Analysis)).EndInit();
            this.Splt_Contr_Analysis.ResumeLayout(false);
            this.Timespan_GrpBx.ResumeLayout(false);
            this.Timespan_GrpBx.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Chrt_Time)).EndInit();
            this.Pnl_View3D.ResumeLayout(false);
            this.Pnl_Region_Brushing.ResumeLayout(false);
            this.Pnl_Region_Brushing.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NmrUpDown_BrushSize)).EndInit();
            this.Pnl_3D_Interaction.ResumeLayout(false);
            this.Pnl_3D_Interaction.PerformLayout();
            this.Grp_Bx_Snd_Color_Scale.ResumeLayout(false);
            this.Grp_Bx_Snd_Color_Scale.PerformLayout();
            this.Grp_Bx_Fst_Color_Scale.ResumeLayout(false);
            this.Grp_Bx_Fst_Color_Scale.PerformLayout();
            this.Pnl_Map_Interaction.ResumeLayout(false);
            this.Pnl_Map_Interaction.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NmrcUpDown_Grid_Res_Y)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NmrcUpDown_Grid_Res_X)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Pnl_Risk_Analysis;
        private System.Windows.Forms.SplitContainer Splt_Cntr_View;
        private System.Windows.Forms.SplitContainer Splt_Contr_Brush;
        private System.Windows.Forms.SplitContainer Splt_Contr_Analysis;
        private System.Windows.Forms.Timer FPSTimer;
        private System.Windows.Forms.Timer ReDrawTimer;
        private System.Windows.Forms.GroupBox GrpBx_ParameterRow;
        private System.Windows.Forms.GroupBox GrpBx_ParameterColumn;
        private System.Windows.Forms.GroupBox Timespan_GrpBx;
        private GradientControls.ColorTrackBar TrckBr_CurrentTimeSlider;
        private System.Windows.Forms.Panel Pnl_View3D;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chrt_Time;
        private System.Windows.Forms.CheckBox Chck_Bx_Stop_Animation;
        private System.Windows.Forms.CheckBox Chck_Bx_Peak_Systole;
        private System.Windows.Forms.Button Btn_Equalize_SP;
        private System.Windows.Forms.Button Btn_Clear_Brushing;
        private System.Windows.Forms.RadioButton Rd_Btn_Local_Scat;
        private System.Windows.Forms.RadioButton RdBtn_Global_Scat;
        private System.Windows.Forms.TextBox Txt_Bx_FPS;
        private GradientControls.ColorTrackBar TrckBr_FocusValueSlider;
        private System.Windows.Forms.ComboBox Cmb_Bx_StentSelectionTop;
        private System.Windows.Forms.Panel Pnl_ScatterInteraction;
        private System.Windows.Forms.Panel Pnl_Map_Interaction;
        private System.Windows.Forms.Panel Pnl_View_Map;
        private System.Windows.Forms.RadioButton RdBtn_Hatching;
        private System.Windows.Forms.RadioButton RdBtn_Chessboard;
        private System.Windows.Forms.NumericUpDown NmrcUpDown_NumBins;
        private GradientControls.ColorTrackBar TrckBr_ScalVal;
        private System.Windows.Forms.Panel Pnl_StentSelectionBottom;
        private System.Windows.Forms.ComboBox Cmb_Bx_StentSelectionBottom;
        private System.Windows.Forms.Panel Pnl_Scatterplot;
        private System.Windows.Forms.GroupBox Grp_Bx_Snd_Color_Scale;
        private System.Windows.Forms.GroupBox Grp_Bx_Fst_Color_Scale;
        public System.Windows.Forms.Label Lbl_Col4_Fst_Scale;
        public System.Windows.Forms.Label Lbl_Col3_Fst_Scale;
        public System.Windows.Forms.Label Lbl_Col0_Fst_Scale;
        public System.Windows.Forms.Label Lbl_Col2_Fst_Scale;
        public System.Windows.Forms.Label Lbl_Col1_Fst_Scale;
        public System.Windows.Forms.Label Lbl_Col4_Snd_Scale;
        public System.Windows.Forms.Label Lbl_Col0_Snd_Scale;
        public System.Windows.Forms.Label Lbl_Col1_Snd_Scale;
        public System.Windows.Forms.Label Lbl_Col3_Snd_Scale;
        public System.Windows.Forms.Label Lbl_Col2_Snd_Scale;
        private System.Windows.Forms.Panel Pnl_3D_Interaction;
        private System.Windows.Forms.Label Lbl_Opacity;
        private GradientControls.ColorTrackBar TrckBr_Mesh_Opacity;
        private System.Windows.Forms.Label Lbl_Grid_Res_X;
        private System.Windows.Forms.NumericUpDown NmrcUpDown_Grid_Res_X;
        private System.Windows.Forms.Label Lbl_Grid_Res_Y;
        private System.Windows.Forms.NumericUpDown NmrcUpDown_Grid_Res_Y;
        private System.Windows.Forms.Button Btn_Mesh_Clustering;
        private System.Windows.Forms.CheckBox Chck_Bx_ShowClustering;
        private System.Windows.Forms.Panel Pnl_ColorLeg_1;
        private System.Windows.Forms.Panel Pnl_ColorLeg_2;
        private System.Windows.Forms.CheckBox Chck_Bx_Substract;
        private System.Windows.Forms.CheckBox Chck_Bx_InvertScatter;
        private System.Windows.Forms.Button Btn_Analysis;
        private System.Windows.Forms.Panel Pnl_View_MapGlyph;
        private System.Windows.Forms.CheckBox ChckBx_Glyphs;
        private System.Windows.Forms.Panel Pnl_BEP_Parameters;
        private System.Windows.Forms.Button Btn_BEP_Parameters;
        private System.Windows.Forms.Panel Pnl_LegendView;
        private System.Windows.Forms.Panel Pnl_Region_Brushing;
        private System.Windows.Forms.Button Btn_Add_Region;
        private System.Windows.Forms.ColorDialog Clr_Dlg_Add_Region;
        private System.Windows.Forms.ListView Lst_Vw_Regions;
        private System.Windows.Forms.Label Lbl_Brush_Size;
        private System.Windows.Forms.NumericUpDown NmrUpDown_BrushSize;
        private System.Windows.Forms.Button Btn_Reset_Brushing;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox Chck_Bx_Show_Regions;

    }
}
